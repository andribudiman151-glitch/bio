import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', aiConfigured: Boolean(getGeminiClient()) });
  });

  app.post('/api/grade', async (req, res) => {
    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY tidak tersedia di server. Menggunakan penilaian cadangan.',
        fallbackRequired: true,
      });
    }

    const { missionTitle, mainQuestion, questions, answers, rubricNotes } = req.body ?? {};
    if (
      typeof missionTitle !== 'string' ||
      !Array.isArray(questions) ||
      !answers ||
      typeof answers !== 'object'
    ) {
      return res.status(400).json({ error: 'Payload penilaian tidak valid.' });
    }

    const qaPairs = questions
      .map((q: { id: string; prompt: string; expectedConcepts?: string[] }, idx: number) => {
        const studentText = typeof answers[q.id] === 'string' ? answers[q.id].trim() : '';
        const keywords = Array.isArray(q.expectedConcepts) ? q.expectedConcepts.join(', ') : '-';
        return `${idx + 1}. Pertanyaan: ${q.prompt}\n   Konsep Kunci: ${keywords}\n   Jawaban Siswa: ${studentText || '(Tidak dijawab)'}`;
      })
      .join('\n\n');

    const prompt = `Anda adalah Guru Biologi SMA Kelas XII profesional yang menilai LKPD materi Mutasi.
Nilai jawaban siswa secara objektif, mendidik, ramah, dan akurat sesuai konsep Biologi SMA (Kurikulum Merdeka / K-13).

Misi: ${missionTitle}
Pertanyaan Utama: ${mainQuestion || '-'}
Catatan Rubrik Tambahan: ${rubricNotes || '-'}

Bobot Rubrik Penilaian (Total 0-100):
1. Ketepatan konsep Biologi (40%)
2. Kelengkapan penjelasan (25%)
3. Kualitas argumentasi & hubungan sebab-akibat (25%)
4. Relevansi jawaban terhadap pertanyaan (10%)

Berikut pertanyaan dan jawaban siswa:
${qaPairs}

Berikan hasil evaluasi dalam format JSON terstruktur sesuai skema.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          systemInstruction:
            'Anda adalah penilai Biologi SMA Kelas XII yang objektif. Selalu gunakan bahasa Indonesia baku yang membimbing dan akurat secara ilmiah.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              score: {
                type: Type.INTEGER,
                description: 'Nilai akhir siswa dari 0 sampai 100 berdasarkan bobot rubrik.',
              },
              correctConcepts: {
                type: Type.STRING,
                description: 'Ringkasan konsep Biologi yang sudah dijawab dengan benar oleh siswa.',
              },
              needsImprovement: {
                type: Type.STRING,
                description: 'Bagian konsep atau argumentasi yang masih kurang tepat atau belum lengkap.',
              },
              improvementSuggestions: {
                type: Type.STRING,
                description: 'Saran perbaikan spesifik agar jawaban siswa lebih ilmiah dan lengkap.',
              },
              learningNotes: {
                type: Type.STRING,
                description: 'Catatan penguatan materi Biologi singkat untuk siswa.',
              },
            },
            required: [
              'score',
              'correctConcepts',
              'needsImprovement',
              'improvementSuggestions',
              'learningNotes',
            ],
          },
        },
      });

      const rawText = (response.text ?? '').trim();
      const parsed = JSON.parse(rawText);
      const boundedScore = Math.max(0, Math.min(100, Math.round(Number(parsed.score) || 0)));

      return res.json({
        score: boundedScore,
        correctConcepts: String(parsed.correctConcepts || ''),
        needsImprovement: String(parsed.needsImprovement || ''),
        improvementSuggestions: String(parsed.improvementSuggestions || ''),
        learningNotes: String(parsed.learningNotes || ''),
        source: 'gemini',
      });
    } catch (err) {
      console.error('Gemini grading error:', err);
      return res.status(502).json({
        error: 'Layanan AI Gemini sedang tidak dapat dijangkau.',
        fallbackRequired: true,
      });
    }
  });

  if (isProd) {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BIOLEARN server running at http://localhost:${PORT}`);
  });
}

createServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
