import React, { useState } from 'react';
import { BiolearnProvider, useBiolearn } from './context/BiolearnContext';
import { LandingView } from './components/LandingView';
import { StudentLoginView, TeacherLoginView } from './components/AuthViews';
import { StudentShell } from './components/StudentShell';
import { StudentDashboard } from './components/StudentDashboard';
import { LearningMaterialView } from './components/LearningMaterialView';
import { LkpdMissionsView } from './components/LkpdMissionsView';
import { LeaderboardView } from './components/LeaderboardView';
import { TeacherDashboard } from './components/TeacherDashboard';
import type { MissionId } from './types/biolearn';

function BiolearnRouter() {
  const { loading, route, session } = useBiolearn();
  const [lkpdTab, setLkpdTab] = useState<MissionId | 'refleksi'>('misi-1');

  if (loading) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-[#F8FAF9] text-emerald-900">
        <div className="text-center space-y-2">
          <div className="mx-auto h-8 w-8 animate-spin rounded-full border-4 border-emerald-200 border-t-emerald-900" />
          <p className="text-sm font-semibold">Memuat BIOLEARN...</p>
        </div>
      </div>
    );
  }

  if (route === 'login-student') {
    return <StudentLoginView />;
  }

  if (route === 'login-teacher') {
    return <TeacherLoginView />;
  }

  if (route === 'teacher-dashboard' && session.role === 'teacher') {
    return <TeacherDashboard />;
  }

  if (session.role === 'student') {
    return (
      <StudentShell>
        {route === 'student-material' ? (
          <LearningMaterialView />
        ) : route === 'student-lkpd' ? (
          <LkpdMissionsView activeTab={lkpdTab} setActiveTab={setLkpdTab} />
        ) : route === 'student-leaderboard' ? (
          <LeaderboardView />
        ) : (
          <StudentDashboard onOpenMission={(t) => setLkpdTab(t)} />
        )}
      </StudentShell>
    );
  }

  return <LandingView />;
}

export default function App() {
  return (
    <BiolearnProvider>
      <BiolearnRouter />
    </BiolearnProvider>
  );
}
