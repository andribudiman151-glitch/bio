import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { biolearnRepository } from '../db/repository';
import { MATERIAL_CHAPTERS } from '../data/curriculum';
import { maskNim, sha256Hex } from '../utils/crypto';
import {
  computeStudentStats,
  evaluateFallbackGrading,
  evaluateMultipleChoiceGrading,
  filterRealLeaderboardEntries,
  sortLeaderboardEntries,
} from '../utils/grading';
import {
  calculateRemainingSeconds,
  normalizeStudentName,
  validateStudentLoginFields,
} from '../utils/validation';
import type {
  ActiveSession,
  AppSettings,
  AssignmentMission,
  DatabaseSchema,
  GradingResultRecord,
  LeaderboardEntry,
  MissionId,
  QuestionItem,
  StudentAnswerRecord,
  StudentComputedStats,
  StudentRecord,
  StructuredFeedback,
} from '../types/biolearn';

export type AppRoute =
  | 'landing'
  | 'login-student'
  | 'login-teacher'
  | 'student-dashboard'
  | 'student-material'
  | 'student-lkpd'
  | 'student-leaderboard'
  | 'teacher-dashboard';

interface BiolearnContextValue {
  db: DatabaseSchema | null;
  loading: boolean;
  session: ActiveSession;
  route: AppRoute;
  setRoute: (r: AppRoute) => void;
  activeStudent: StudentRecord | null;
  activeStudentStats: StudentComputedStats | null;
  remainingSeconds: number;
  allStudentStats: Map<string, StudentComputedStats>;
  allRankedStudents: LeaderboardEntry[];
  leaderboard: LeaderboardEntry[];
  gradingBusyMission: MissionId | null;
  lkpdCompletedCelebration: number;
  justFinishedLkpd: boolean;
  clearLkpdCelebrationBurst: () => void;
  loginStudent: (params: {
    fullName: string;
    nim: string;
    classId: string;
  }) => Promise<{ ok: boolean; error?: string }>;
  loginTeacher: (params: {
    email: string;
    password: string;
  }) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
  markChapterRead: (chapterId: string) => void;
  saveMissionDraft: (params: {
    missionId: MissionId;
    answers: Record<string, string>;
    sortingAssignments?: Record<string, 'mutasi-gen' | 'mutasi-kromosom'>;
    sortingScore?: number;
  }) => void;
  submitAndGradeMission: (params: {
    missionId: MissionId;
    answers: Record<string, string>;
    sortingAssignments?: Record<string, 'mutasi-gen' | 'mutasi-kromosom'>;
    sortingScore?: number;
  }) => Promise<{ ok: boolean; grading?: GradingResultRecord; error?: string }>;
  submitReflection: (params: { newThingLearned: string; curiousQuestion: string }) => void;
  overrideStudentGrade: (params: {
    studentId: string;
    missionId: MissionId;
    score: number;
    comment: string;
  }) => void;
  updateSettings: (partial: Partial<AppSettings>) => void;
  addClassRoom: (name: string) => { ok: boolean; error?: string };
  deleteClassRoom: (classId: string) => { ok: boolean; error?: string };
  deleteStudent: (studentId: string) => void;
  updateQuestion: (question: QuestionItem) => void;
  updateMissionMeta: (mission: AssignmentMission) => void;
  loadDemoData: () => Promise<void>;
  resetDemoData: () => Promise<void>;
}

const BiolearnContext = createContext<BiolearnContextValue | null>(null);
const SESSION_STORAGE_KEY = 'biolearn_session_v1';

export const BiolearnProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [db, setDb] = useState<DatabaseSchema | null>(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<ActiveSession>({ role: 'none' });
  const [route, setRoute] = useState<AppRoute>('landing');
  const [remainingSeconds, setRemainingSeconds] = useState<number>(10 * 60);
  const [gradingBusyMission, setGradingBusyMission] = useState<MissionId | null>(null);
  const [lkpdCompletedCelebration, setLkpdCompletedCelebration] = useState<number>(0);
  const [justFinishedLkpd, setJustFinishedLkpd] = useState<boolean>(false);
  const prevRouteRef = useRef<AppRoute>('landing');

  useEffect(() => {
    if (prevRouteRef.current === 'student-leaderboard' && route !== 'student-leaderboard') {
      setJustFinishedLkpd(false);
      setLkpdCompletedCelebration(0);
    }
    prevRouteRef.current = route;
  }, [route]);

  const clearLkpdCelebrationBurst = useCallback(() => {
    setLkpdCompletedCelebration(0);
  }, []);

  const dbRef = useRef<DatabaseSchema | null>(null);
  dbRef.current = db;

  const commitDb = useCallback((updater: (prev: DatabaseSchema) => DatabaseSchema) => {
    setDb((prev) => {
      if (!prev) return prev;
      const next = updater(prev);
      void biolearnRepository.saveDatabase(next);
      return next;
    });
  }, []);

  useEffect(() => {
    let active = true;
    (async () => {
      const loaded = await biolearnRepository.loadDatabase();
      if (!active) return;
      setDb(loaded);

      // Restore active session if valid
      try {
        const savedSessionRaw = window.sessionStorage.getItem(SESSION_STORAGE_KEY);
        if (savedSessionRaw) {
          const parsed = JSON.parse(savedSessionRaw) as ActiveSession;
          if (parsed.role === 'student') {
            const exists = loaded.students.some((s) => s.id === parsed.studentId);
            if (exists) {
              setSession(parsed);
              setRoute('student-dashboard');
            }
          } else if (parsed.role === 'teacher') {
            const exists = loaded.teachers.some((t) => t.id === parsed.teacherId);
            if (exists) {
              setSession(parsed);
              setRoute('teacher-dashboard');
            }
          }
        }
      } catch {
        // Ignore session restore error
      }

      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (loading) return;
    try {
      window.sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    } catch {
      // Ignore
    }
  }, [session, loading]);

  const activeStudent = useMemo(() => {
    if (!db || session.role !== 'student') return null;
    return db.students.find((s) => s.id === session.studentId) ?? null;
  }, [db, session]);

  const allStudentStats = useMemo(() => {
    const map = new Map<string, StudentComputedStats>();
    if (!db) return map;
    for (const student of db.students) {
      const stuAnswers = db.student_answers.filter((a) => a.studentId === student.id);
      const stuGradings = db.grading_results.filter((g) => g.studentId === student.id);
      const stuReflection = db.reflections.find((r) => r.studentId === student.id);
      const stats = computeStudentStats({
        student,
        answers: stuAnswers,
        gradings: stuGradings,
        reflection: stuReflection,
        weights: db.settings.pointWeights,
        totalMaterialChapters: MATERIAL_CHAPTERS.length,
      });
      map.set(student.id, stats);
    }
    return map;
  }, [db]);

  const activeStudentStats = useMemo(() => {
    if (!activeStudent) return null;
    return allStudentStats.get(activeStudent.id) ?? null;
  }, [activeStudent, allStudentStats]);

  const allRankedStudents = useMemo(() => {
    if (!db) return [];
    const items = db.students.map((student) => {
      const stats =
        allStudentStats.get(student.id) ??
        computeStudentStats({
          student,
          answers: [],
          gradings: [],
          reflection: undefined,
          weights: db.settings.pointWeights,
          totalMaterialChapters: MATERIAL_CHAPTERS.length,
        });
      const badges = db.badges.filter((b) => stats.earnedBadgeIds.includes(b.id));
      return { student, stats, badges };
    });
    return sortLeaderboardEntries(items);
  }, [db, allStudentStats]);

  // Leaderboard strictly uses real field students (non-demo) who have completed work
  const leaderboard = useMemo(() => {
    return filterRealLeaderboardEntries(allRankedStudents);
  }, [allRankedStudents]);

  // Sync earned badges into student_badges table whenever stats change
  useEffect(() => {
    if (!db || !activeStudent || !activeStudentStats) return;
    const existingIds = new Set(
      db.student_badges
        .filter((sb) => sb.studentId === activeStudent.id)
        .map((sb) => sb.badgeId),
    );
    const missing = activeStudentStats.earnedBadgeIds.filter((b) => !existingIds.has(b));
    if (missing.length > 0) {
      const nowIso = new Date().toISOString();
      commitDb((prev) => ({
        ...prev,
        student_badges: [
          ...prev.student_badges,
          ...missing.map((badgeId) => ({
            id: `${activeStudent.id}-${badgeId}`,
            studentId: activeStudent.id,
            badgeId,
            earnedAt: nowIso,
          })),
        ],
      }));
    }
  }, [db, activeStudent, activeStudentStats, commitDb]);

  // Auto-submit draft answers when timer reaches 0
  const handleAutoExpireSubmit = useCallback(
    (student: StudentRecord) => {
      const currentDb = dbRef.current;
      if (!currentDb) return;
      const nowIso = new Date().toISOString();

      commitDb((prev) => {
        const updatedStudents = prev.students.map((s) =>
          s.id === student.id
            ? {
                ...s,
                timeExpiredLocked: prev.settings.lockOnTimeExpired,
                timerFinishedAt: s.timerFinishedAt ?? nowIso,
                lastActiveAt: nowIso,
              }
            : s,
        );

        const draftsToSubmit = prev.student_answers.filter(
          (a) => a.studentId === student.id && a.status === 'draft',
        );
        if (draftsToSubmit.length === 0) {
          return { ...prev, students: updatedStudents };
        }

        const newGradings: GradingResultRecord[] = [...prev.grading_results];
        const updatedAnswers: StudentAnswerRecord[] = prev.student_answers.map((ans) => {
          if (ans.studentId !== student.id || ans.status !== 'draft') return ans;
          const mission = prev.assignments.find((m) => m.id === ans.missionId);
          const questions = prev.questions.filter((q) => q.missionId === ans.missionId);
          const hasAnyAnswer = Object.values(ans.answers).some((v) => v.trim().length > 0);
          if (!hasAnyAnswer && !ans.sortingAssignments) {
            return ans;
          }
          const fb = evaluateFallbackGrading({
            missionTitle: mission?.title ?? ans.missionId,
            questions,
            answers: ans.answers,
            sortingScore: ans.sortingScore,
          });
          const existingGradeIdx = newGradings.findIndex(
            (g) => g.studentId === student.id && g.missionId === ans.missionId,
          );
          const newGrade: GradingResultRecord = {
            id: `${student.id}-grade-${ans.missionId}`,
            studentId: student.id,
            missionId: ans.missionId,
            aiScore: fb.score,
            aiFeedback: fb,
            teacherScoreOverride:
              existingGradeIdx >= 0 ? newGradings[existingGradeIdx].teacherScoreOverride : null,
            teacherComment:
              existingGradeIdx >= 0 ? newGradings[existingGradeIdx].teacherComment : '',
            finalScore:
              existingGradeIdx >= 0 && newGradings[existingGradeIdx].teacherScoreOverride !== null
                ? newGradings[existingGradeIdx].teacherScoreOverride!
                : fb.score,
            gradedAt: nowIso,
            overriddenAt:
              existingGradeIdx >= 0 ? newGradings[existingGradeIdx].overriddenAt : null,
          };
          if (existingGradeIdx >= 0) {
            newGradings[existingGradeIdx] = newGrade;
          } else {
            newGradings.push(newGrade);
          }

          return {
            ...ans,
            status: 'graded',
            submittedAt: nowIso,
            updatedAt: nowIso,
          };
        });

        return {
          ...prev,
          students: updatedStudents,
          student_answers: updatedAnswers,
          grading_results: newGradings,
        };
      });
    },
    [commitDb],
  );

  // Start LKPD timer only when the student actually enters the LKPD view
  useEffect(() => {
    if (!db || !activeStudent) return;
    if (!db.settings.timerEnabled) return;
    if (route === 'student-lkpd' && !activeStudent.timerStartedAt) {
      const nowIso = new Date().toISOString();
      commitDb((prev) => ({
        ...prev,
        students: prev.students.map((s) =>
          s.id === activeStudent.id
            ? { ...s, timerStartedAt: s.timerStartedAt ?? nowIso, lastActiveAt: nowIso }
            : s,
        ),
      }));
    }
  }, [db, activeStudent, route, commitDb]);

  // Live timer countdown effect (ticks & triggers expiry only after LKPD timer has started)
  useEffect(() => {
    if (!db || !activeStudent) return;
    const { timerEnabled, timerDurationMinutes } = db.settings;

    const updateTick = () => {
      const rem = calculateRemainingSeconds({
        timerEnabled,
        timerDurationMinutes,
        timerStartedAt: activeStudent.timerStartedAt,
      });
      setRemainingSeconds(rem);
      if (
        timerEnabled &&
        route === 'student-lkpd' &&
        activeStudent.timerStartedAt &&
        rem === 0 &&
        !activeStudent.timerFinishedAt
      ) {
        handleAutoExpireSubmit(activeStudent);
        setLkpdCompletedCelebration((c) => c + 1);
        setJustFinishedLkpd(true);
        setRoute('student-leaderboard');
      }
    };

    updateTick();
    if (!timerEnabled || !activeStudent.timerStartedAt || route !== 'student-lkpd') return;
    const interval = window.setInterval(updateTick, 1000);
    return () => window.clearInterval(interval);
  }, [db, activeStudent, route, handleAutoExpireSubmit]);

  const loginStudent = useCallback(
    async (params: {
      fullName: string;
      nim: string;
      classId: string;
    }): Promise<{ ok: boolean; error?: string }> => {
      const check = validateStudentLoginFields(params);
      if (!check.valid) {
        return { ok: false, error: check.error };
      }

      const currentDb = dbRef.current;
      if (!currentDb) {
        return { ok: false, error: 'Database belum siap.' };
      }

      const selectedClass = currentDb.classes.find((c) => c.id === params.classId);
      if (!selectedClass) {
        return { ok: false, error: 'Kelas yang dipilih tidak ditemukan.' };
      }

      const nimHash = await sha256Hex(params.nim.trim());
      const nowIso = new Date().toISOString();
      const existing = currentDb.students.find((s) => s.nimHash === nimHash);

      if (existing) {
        const nameMatches =
          normalizeStudentName(existing.fullName) === normalizeStudentName(params.fullName);
        const classMatches = existing.classId === params.classId;
        if (!nameMatches || !classMatches) {
          return {
            ok: false,
            error:
              'NIM/NIS ini sudah terdaftar atas nama atau kelas siswa lain. Periksa kembali Nama Lengkap, NIM, dan Kelas Anda.',
          };
        }

        commitDb((prev) => ({
          ...prev,
          students: prev.students.map((s) =>
            s.id === existing.id
              ? {
                  ...s,
                  lastActiveAt: nowIso,
                }
              : s,
          ),
        }));
        setSession({ role: 'student', studentId: existing.id });
        setRoute('student-dashboard');
        return { ok: true };
      }

      const newStudent: StudentRecord = {
        id: `stu-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        fullName: params.fullName.trim().replace(/\s+/g, ' '),
        nimHash,
        nimDisplay: maskNim(params.nim),
        classId: selectedClass.id,
        className: selectedClass.name,
        isDemo: false,
        readChapters: [],
        timerStartedAt: null,
        timerFinishedAt: null,
        timeExpiredLocked: false,
        createdAt: nowIso,
        lastActiveAt: nowIso,
      };

      commitDb((prev) => ({
        ...prev,
        students: [...prev.students, newStudent],
      }));
      setSession({ role: 'student', studentId: newStudent.id });
      setRoute('student-dashboard');
      return { ok: true };
    },
    [commitDb],
  );

  const loginTeacher = useCallback(
    async (params: {
      email: string;
      password: string;
    }): Promise<{ ok: boolean; error?: string }> => {
      const currentDb = dbRef.current;
      if (!currentDb) return { ok: false, error: 'Database belum siap.' };
      const cleanEmail = params.email.trim().toLowerCase();
      const teacher = currentDb.teachers.find((t) => t.email.toLowerCase() === cleanEmail);
      if (!teacher) {
        return { ok: false, error: 'Username admin guru tidak terdaftar.' };
      }
      const passHash = await sha256Hex(params.password);
      if (passHash !== teacher.passwordHash) {
        return { ok: false, error: 'Password guru salah. Silakan coba kembali.' };
      }
      setSession({
        role: 'teacher',
        teacherId: teacher.id,
        email: teacher.email,
        name: teacher.name,
      });
      setRoute('teacher-dashboard');
      return { ok: true };
    },
    [],
  );

  const logout = useCallback(() => {
    setSession({ role: 'none' });
    setJustFinishedLkpd(false);
    setLkpdCompletedCelebration(0);
    setRoute('landing');
  }, []);

  const markChapterRead = useCallback(
    (chapterId: string) => {
      if (!activeStudent) return;
      if (activeStudent.readChapters.includes(chapterId)) return;
      const nowIso = new Date().toISOString();
      commitDb((prev) => ({
        ...prev,
        students: prev.students.map((s) =>
          s.id === activeStudent.id
            ? {
                ...s,
                readChapters: [...s.readChapters, chapterId],
                lastActiveAt: nowIso,
              }
            : s,
        ),
      }));
    },
    [activeStudent, commitDb],
  );

  const saveMissionDraft = useCallback(
    (params: {
      missionId: MissionId;
      answers: Record<string, string>;
      sortingAssignments?: Record<string, 'mutasi-gen' | 'mutasi-kromosom'>;
      sortingScore?: number;
    }) => {
      if (!activeStudent) return;
      const nowIso = new Date().toISOString();
      commitDb((prev) => {
        const idx = prev.student_answers.findIndex(
          (a) => a.studentId === activeStudent.id && a.missionId === params.missionId,
        );
        if (idx >= 0) {
          const existing = prev.student_answers[idx];
          const nextAnswers = [...prev.student_answers];
          nextAnswers[idx] = {
            ...existing,
            answers: params.answers,
            sortingAssignments: params.sortingAssignments ?? existing.sortingAssignments,
            sortingScore: params.sortingScore ?? existing.sortingScore,
            updatedAt: nowIso,
          };
          return { ...prev, student_answers: nextAnswers };
        }
        const created: StudentAnswerRecord = {
          id: `${activeStudent.id}-${params.missionId}`,
          studentId: activeStudent.id,
          missionId: params.missionId,
          answers: params.answers,
          sortingAssignments: params.sortingAssignments,
          sortingScore: params.sortingScore,
          status: 'draft',
          updatedAt: nowIso,
          submittedAt: null,
        };
        return {
          ...prev,
          student_answers: [...prev.student_answers, created],
        };
      });
    },
    [activeStudent, commitDb],
  );

  const submitAndGradeMission = useCallback(
    async (params: {
      missionId: MissionId;
      answers: Record<string, string>;
      sortingAssignments?: Record<string, 'mutasi-gen' | 'mutasi-kromosom'>;
      sortingScore?: number;
    }): Promise<{ ok: boolean; grading?: GradingResultRecord; error?: string }> => {
      const currentDb = dbRef.current;
      if (!currentDb || !activeStudent) {
        return { ok: false, error: 'Sesi siswa tidak ditemukan.' };
      }

      if (currentDb.settings.timerEnabled && currentDb.settings.lockOnTimeExpired && activeStudent.timeExpiredLocked) {
        return { ok: false, error: 'Waktu pengerjaan telah habis dan terkunci oleh pengaturan guru.' };
      }

      const isMissionDone = (mId: MissionId) =>
        currentDb.student_answers.some(
          (a) =>
            a.studentId === activeStudent.id &&
            a.missionId === mId &&
            (a.status === 'submitted' || a.status === 'graded'),
        );
      if (params.missionId === 'misi-2' && !isMissionDone('misi-1')) {
        return { ok: false, error: 'Selesaikan dan kirim Misi 1 terlebih dahulu sebelum Misi 2.' };
      }
      if (params.missionId === 'misi-3' && !isMissionDone('misi-2')) {
        return { ok: false, error: 'Selesaikan dan kirim Misi 2 terlebih dahulu sebelum Misi 3.' };
      }

      const mission = currentDb.assignments.find((m) => m.id === params.missionId);
      const questions = currentDb.questions.filter((q) => q.missionId === params.missionId);
      if (!mission) {
        return { ok: false, error: 'Data misi tidak ditemukan.' };
      }

      setGradingBusyMission(params.missionId);

      let feedback: StructuredFeedback;
      const isMultipleChoiceMission =
        questions.length > 0 &&
        questions.every((q) => Array.isArray(q.options) && q.options.length > 0);

      if (isMultipleChoiceMission) {
        feedback = evaluateMultipleChoiceGrading({
          missionTitle: mission.title,
          questions,
          answers: params.answers,
          sortingScore: params.sortingScore,
        });
      } else {
        try {
          const res = await fetch('/api/grade', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              missionTitle: mission.title,
              mainQuestion: mission.mainQuestion,
              rubricNotes: mission.rubricNotes,
              questions,
              answers: params.answers,
            }),
          });

          if (res.ok) {
            const data = await res.json();
            let finalAiScore = Number(data.score) || 0;
            if (typeof params.sortingScore === 'number') {
              finalAiScore = Math.round(finalAiScore * 0.7 + params.sortingScore * 0.3);
            }
            feedback = {
              score: Math.max(0, Math.min(100, finalAiScore)),
              correctConcepts: String(data.correctConcepts || ''),
              needsImprovement: String(data.needsImprovement || ''),
              improvementSuggestions: String(data.improvementSuggestions || ''),
              learningNotes: String(data.learningNotes || ''),
              source: 'gemini',
            };
          } else {
            feedback = evaluateFallbackGrading({
              missionTitle: mission.title,
              questions,
              answers: params.answers,
              sortingScore: params.sortingScore,
            });
          }
        } catch {
          feedback = evaluateFallbackGrading({
            missionTitle: mission.title,
            questions,
            answers: params.answers,
            sortingScore: params.sortingScore,
          });
        }
      }

      const nowIso = new Date().toISOString();
      let savedGrade!: GradingResultRecord;

      commitDb((prev) => {
        const existingGrade = prev.grading_results.find(
          (g) => g.studentId === activeStudent.id && g.missionId === params.missionId,
        );
        const finalScore =
          existingGrade && existingGrade.teacherScoreOverride !== null
            ? existingGrade.teacherScoreOverride
            : feedback.score;

        savedGrade = {
          id: `${activeStudent.id}-grade-${params.missionId}`,
          studentId: activeStudent.id,
          missionId: params.missionId,
          aiScore: feedback.score,
          aiFeedback: feedback,
          teacherScoreOverride: existingGrade?.teacherScoreOverride ?? null,
          teacherComment: existingGrade?.teacherComment ?? '',
          finalScore,
          gradedAt: nowIso,
          overriddenAt: existingGrade?.overriddenAt ?? null,
        };

        const filteredGrades = prev.grading_results.filter(
          (g) => !(g.studentId === activeStudent.id && g.missionId === params.missionId),
        );

        const existingAns = prev.student_answers.find(
          (a) => a.studentId === activeStudent.id && a.missionId === params.missionId,
        );
        const updatedAns: StudentAnswerRecord = {
          id: existingAns?.id ?? `${activeStudent.id}-${params.missionId}`,
          studentId: activeStudent.id,
          missionId: params.missionId,
          answers: params.answers,
          sortingAssignments: params.sortingAssignments ?? existingAns?.sortingAssignments,
          sortingScore: params.sortingScore ?? existingAns?.sortingScore,
          status: 'graded',
          updatedAt: nowIso,
          submittedAt: existingAns?.submittedAt ?? nowIso,
        };
        const filteredAns = prev.student_answers.filter(
          (a) => !(a.studentId === activeStudent.id && a.missionId === params.missionId),
        );

        const nextStudents = prev.students.map((s) =>
          s.id === activeStudent.id ? { ...s, lastActiveAt: nowIso } : s,
        );

        return {
          ...prev,
          students: nextStudents,
          student_answers: [...filteredAns, updatedAns],
          grading_results: [...filteredGrades, savedGrade],
        };
      });

      setGradingBusyMission(null);
      return { ok: true, grading: savedGrade };
    },
    [activeStudent, commitDb],
  );

  const submitReflection = useCallback(
    (params: { newThingLearned: string; curiousQuestion: string }) => {
      if (!activeStudent) return;
      const currentDb = dbRef.current;
      if (currentDb) {
        const m3Done = currentDb.student_answers.some(
          (a) =>
            a.studentId === activeStudent.id &&
            a.missionId === 'misi-3' &&
            (a.status === 'submitted' || a.status === 'graded'),
        );
        if (!m3Done) return;
      }
      const nowIso = new Date().toISOString();
      commitDb((prev) => {
        const filtered = prev.reflections.filter((r) => r.studentId !== activeStudent.id);
        const allMissionsDone = (['misi-1', 'misi-2', 'misi-3'] as MissionId[]).every((mId) =>
          prev.student_answers.some(
            (a) =>
              a.studentId === activeStudent.id &&
              a.missionId === mId &&
              (a.status === 'submitted' || a.status === 'graded'),
          ),
        );

        return {
          ...prev,
          reflections: [
            ...filtered,
            {
              id: `${activeStudent.id}-ref`,
              studentId: activeStudent.id,
              newThingLearned: params.newThingLearned.trim(),
              curiousQuestion: params.curiousQuestion.trim(),
              submittedAt: nowIso,
            },
          ],
          students: prev.students.map((s) =>
            s.id === activeStudent.id
              ? {
                  ...s,
                  timerFinishedAt: allMissionsDone ? (s.timerFinishedAt ?? nowIso) : s.timerFinishedAt,
                  lastActiveAt: nowIso,
                }
              : s,
          ),
        };
      });
      setLkpdCompletedCelebration((c) => c + 1);
      setJustFinishedLkpd(true);
    },
    [activeStudent, commitDb],
  );

  const overrideStudentGrade = useCallback(
    (params: { studentId: string; missionId: MissionId; score: number; comment: string }) => {
      const nowIso = new Date().toISOString();
      const clampedScore = Math.max(0, Math.min(100, Math.round(params.score)));
      commitDb((prev) => {
        const idx = prev.grading_results.findIndex(
          (g) => g.studentId === params.studentId && g.missionId === params.missionId,
        );
        const nextGrades = [...prev.grading_results];
        if (idx >= 0) {
          nextGrades[idx] = {
            ...nextGrades[idx],
            teacherScoreOverride: clampedScore,
            teacherComment: params.comment.trim(),
            finalScore: clampedScore,
            overriddenAt: nowIso,
          };
        } else {
          nextGrades.push({
            id: `${params.studentId}-grade-${params.missionId}`,
            studentId: params.studentId,
            missionId: params.missionId,
            aiScore: clampedScore,
            aiFeedback: {
              score: clampedScore,
              correctConcepts: 'Dinilai langsung oleh Guru.',
              needsImprovement: '-',
              improvementSuggestions: params.comment.trim() || '-',
              learningNotes: 'Penilaian manual guru.',
              source: 'fallback',
            },
            teacherScoreOverride: clampedScore,
            teacherComment: params.comment.trim(),
            finalScore: clampedScore,
            gradedAt: nowIso,
            overriddenAt: nowIso,
          });
        }
        return { ...prev, grading_results: nextGrades };
      });
    },
    [commitDb],
  );

  const updateSettings = useCallback(
    (partial: Partial<AppSettings>) => {
      commitDb((prev) => ({
        ...prev,
        settings: {
          ...prev.settings,
          ...partial,
          pointWeights: partial.pointWeights
            ? { ...prev.settings.pointWeights, ...partial.pointWeights }
            : prev.settings.pointWeights,
          updatedAt: new Date().toISOString(),
        },
      }));
    },
    [commitDb],
  );

  const addClassRoom = useCallback(
    (name: string): { ok: boolean; error?: string } => {
      const clean = name.trim();
      if (!clean) return { ok: false, error: 'Nama kelas tidak boleh kosong.' };
      const currentDb = dbRef.current;
      if (!currentDb) return { ok: false, error: 'Database belum siap.' };
      if (currentDb.classes.some((c) => c.name.toLowerCase() === clean.toLowerCase())) {
        return { ok: false, error: 'Nama kelas sudah ada.' };
      }
      commitDb((prev) => ({
        ...prev,
        classes: [
          ...prev.classes,
          {
            id: `class-${Date.now()}`,
            name: clean,
            createdAt: new Date().toISOString(),
          },
        ],
      }));
      return { ok: true };
    },
    [commitDb],
  );

  const deleteClassRoom = useCallback(
    (classId: string): { ok: boolean; error?: string } => {
      const currentDb = dbRef.current;
      if (!currentDb) return { ok: false, error: 'Database belum siap.' };
      if (currentDb.classes.length <= 1) {
        return { ok: false, error: 'Minimal harus ada 1 kelas aktif.' };
      }
      const hasStudents = currentDb.students.some((s) => s.classId === classId);
      if (hasStudents) {
        return {
          ok: false,
          error: 'Tidak dapat menghapus kelas yang masih memiliki data siswa terdaftar.',
        };
      }
      commitDb((prev) => ({
        ...prev,
        classes: prev.classes.filter((c) => c.id !== classId),
      }));
      return { ok: true };
    },
    [commitDb],
  );

  const deleteStudent = useCallback(
    (studentId: string) => {
      commitDb((prev) => ({
        ...prev,
        students: prev.students.filter((s) => s.id !== studentId),
        student_answers: prev.student_answers.filter((a) => a.studentId !== studentId),
        grading_results: prev.grading_results.filter((g) => g.studentId !== studentId),
        reflections: prev.reflections.filter((r) => r.studentId !== studentId),
        student_badges: prev.student_badges.filter((b) => b.studentId !== studentId),
      }));
    },
    [commitDb],
  );

  const updateQuestion = useCallback(
    (question: QuestionItem) => {
      commitDb((prev) => ({
        ...prev,
        questions: prev.questions.map((q) => (q.id === question.id ? question : q)),
      }));
    },
    [commitDb],
  );

  const updateMissionMeta = useCallback(
    (mission: AssignmentMission) => {
      commitDb((prev) => ({
        ...prev,
        assignments: prev.assignments.map((m) => (m.id === mission.id ? mission : m)),
      }));
    },
    [commitDb],
  );

  const loadDemoData = useCallback(async () => {
    const current = dbRef.current;
    if (!current) return;
    const next = await biolearnRepository.loadDemoData(current);
    setDb(next);
  }, []);

  const resetDemoData = useCallback(async () => {
    const current = dbRef.current;
    if (!current) return;
    const next = await biolearnRepository.resetDemoData(current);
    setDb(next);
  }, []);

  const value: BiolearnContextValue = {
    db,
    loading,
    session,
    route,
    setRoute,
    activeStudent,
    activeStudentStats,
    remainingSeconds,
    allStudentStats,
    allRankedStudents,
    leaderboard,
    gradingBusyMission,
    lkpdCompletedCelebration,
    justFinishedLkpd,
    clearLkpdCelebrationBurst,
    loginStudent,
    loginTeacher,
    logout,
    markChapterRead,
    saveMissionDraft,
    submitAndGradeMission,
    submitReflection,
    overrideStudentGrade,
    updateSettings,
    addClassRoom,
    deleteClassRoom,
    deleteStudent,
    updateQuestion,
    updateMissionMeta,
    loadDemoData,
    resetDemoData,
  };

  return <BiolearnContext.Provider value={value}>{children}</BiolearnContext.Provider>;
};

export function useBiolearn() {
  const ctx = useContext(BiolearnContext);
  if (!ctx) throw new Error('useBiolearn must be used within BiolearnProvider');
  return ctx;
}
