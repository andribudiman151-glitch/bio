import React, { useState } from 'react';
import { Dna, GraduationCap, Microscope, Award, ArrowRight, ShieldCheck } from 'lucide-react';
import { useBiolearn } from '../context/BiolearnContext';

const HERO_IMAGE_PATH = '/src/assets/images/hero_biolearn_dna_1795616022889.jpg';

export const LandingView: React.FC = () => {
  const { setRoute } = useBiolearn();
  const [imgError, setImgError] = useState(false);

  return (
    <div className="min-h-[100dvh] w-full overflow-x-hidden bg-gradient-to-b from-emerald-50/90 via-[#F4FAF6] to-orange-50/40 text-slate-900">
      {/* Top Bar Contract: 3 zones */}
      <header className="sticky top-0 z-30 border-b border-emerald-200/80 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <button
            type="button"
            onClick={() => setRoute('landing')}
            className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 min-h-[44px]"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-800 to-emerald-600 text-white shadow-sm">
              <Dna className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="font-display text-lg font-extrabold tracking-tight text-emerald-950">
              BIOLEARN
            </span>
          </button>

          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600">
            <a href="#misi-pembelajaran" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              Misi Belajar
            </a>
            <a href="#fitur-utama" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              Metode LKPD
            </a>
            <a href="#peran-pengguna" className="hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0">
              Akses Kelas
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setRoute('login-student')}
              className="min-h-[44px] rounded-xl bg-emerald-800 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-emerald-900 whitespace-nowrap shrink-0"
            >
              Masuk Siswa
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:py-12">
        {/* Hero Split */}
        <section id="misi-pembelajaran" className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12">
          <div className="flex flex-col justify-center space-y-5 lg:col-span-6">
            <p className="text-xs font-bold tracking-wide text-emerald-800">
              Biologi Kelas XII SMA · Materi Mutasi Genetik
            </p>
            <h1 className="font-display text-3xl font-extrabold leading-tight tracking-tight text-emerald-950 text-balance sm:text-4xl lg:text-5xl">
              Explore, Discover, and Understand{' '}
              <span className="text-emerald-700">Biology!</span>
            </h1>
            <p className="max-w-xl text-base leading-relaxed text-slate-700 sm:text-lg">
              Jadilah Detektif Biologi dalam misi interaktif mengungkap rahasia mutasi gen dan
              kromosom—mulai dari misteri semangka tanpa biji triploid hingga analisis kariotipe
              dengan umpan balik evaluasi otomatis.
            </p>

            {/* Primary Mobile-First CTAs: Green for Student, Orange for Teacher */}
            <div id="peran-pengguna" className="flex flex-col gap-3 pt-2 sm:flex-row">
              <button
                type="button"
                onClick={() => setRoute('login-student')}
                className="flex min-h-[52px] flex-1 items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r from-emerald-900 to-emerald-700 px-5 py-3.5 text-base font-bold text-white shadow-sm transition-all hover:from-emerald-800 hover:to-emerald-600 active:scale-[0.99] whitespace-nowrap"
              >
                <GraduationCap className="h-5 w-5 shrink-0" aria-hidden="true" />
                <span>Masuk sebagai Siswa</span>
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={() => setRoute('login-teacher')}
                className="flex min-h-[52px] flex-1 items-center justify-center gap-2.5 rounded-2xl border-2 border-orange-500 bg-orange-50 px-5 py-3.5 text-base font-bold text-orange-800 transition-all hover:bg-orange-100 active:scale-[0.99] whitespace-nowrap"
              >
                <ShieldCheck className="h-5 w-5 shrink-0 text-orange-600" aria-hidden="true" />
                <span>Masuk sebagai Guru</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full overflow-hidden rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-100/70 via-white to-orange-50/70 p-3 shadow-sm">
              {!imgError ? (
                <img
                  src={HERO_IMAGE_PATH}
                  alt="Ilustrasi DNA untai ganda, kromosom, dan botani Biologi BIOLEARN"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="aspect-[4/3] w-full rounded-2xl object-cover lg:h-full"
                />
              ) : (
                <div className="flex aspect-[4/3] w-full flex-col items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-emerald-600 p-6 text-white lg:h-full">
                  <Dna className="mb-3 h-16 w-16 text-orange-400" aria-hidden="true" />
                  <p className="font-display text-xl font-bold">Laboratorium Mutasi BIOLEARN</p>
                  <p className="mt-1 text-center text-sm text-emerald-100">
                    Eksplorasi DNA, Kode Genetik, dan Kariotipe Kromosom
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Feature Overview Strip: 3 Distinct Color-Coded Pillars */}
        <section id="fitur-utama" className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-3">
          <article className="overflow-hidden rounded-2xl border border-emerald-200 bg-gradient-to-b from-emerald-50/80 to-white shadow-sm">
            <div className="h-1.5 w-full bg-emerald-600" />
            <div className="p-5">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-600 text-white">
                <Microscope className="h-5 w-5" aria-hidden="true" />
              </div>
              <h2 className="font-display text-lg font-bold text-emerald-950">
                01. Materi & Simulator Mutasi
              </h2>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
                Pelajari mutasi gen (substitusi, frameshift) dan aberasi kromosom melalui simulator
                interaktif DNA, ploidi semangka, serta pembanding kariotipe.
              </p>
            </div>
          </article>

          <article className="overflow-hidden rounded-2xl border border-orange-200 bg-gradient-to-b from-orange-50/80 to-white shadow-sm">
            <div className="h-1.5 w-full bg-orange-500" />
            <div className="p-5">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-orange-500 text-white">
                <Dna className="h-5 w-5" aria-hidden="true" />
              </div>
              <h2 className="font-display text-lg font-bold text-orange-950">
                02. 3 Misi Detektif &amp; Evaluasi
              </h2>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
                Pecahkan kasus investigasi LKPD secara bertahap lewat soal pilihan ganda interaktif,
                kartu konsep sentuh, dan pembahasan otomatis terstruktur.
              </p>
            </div>
          </article>

          <article className="overflow-hidden rounded-2xl border border-teal-200 bg-gradient-to-b from-teal-50/80 to-white shadow-sm">
            <div className="h-1.5 w-full bg-teal-600" />
            <div className="p-5">
              <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-teal-600 text-white">
                <Award className="h-5 w-5" aria-hidden="true" />
              </div>
              <h2 className="font-display text-lg font-bold text-teal-950">
                03. Gamifikasi & Panel Guru
              </h2>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
                Kumpulkan 6 badge digital, bersaing di Podium Top 10 real kelas, dan pantau hasil
                belajar lengkap dengan ekspor Excel, PDF, serta CSV.
              </p>
            </div>
          </article>
        </section>
      </main>
    </div>
  );
};
