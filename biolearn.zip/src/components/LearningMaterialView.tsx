import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  FlaskConical,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { MATERIAL_CHAPTERS } from '../data/curriculum';
import { useBiolearn } from '../context/BiolearnContext';
import {
  ChromosomeAberrationDiagram,
  DnaMutationSimulator,
  WatermelonPloidyDiagram,
} from './BioVisuals';

export const LearningMaterialView: React.FC = () => {
  const { activeStudent, markChapterRead, setRoute } = useBiolearn();
  const [activeIdx, setActiveIdx] = useState(0);
  const [selectedMutagenTab, setSelectedMutagenTab] = useState<'fisika' | 'kimia' | 'biologi'>(
    'fisika',
  );
  const [quickAnswers, setQuickAnswers] = useState<Record<string, number>>({});

  const chapter = MATERIAL_CHAPTERS[activeIdx];
  const readChapters = activeStudent?.readChapters ?? [];
  const isCurrentRead = readChapters.includes(chapter.id);
  const pickedOption = quickAnswers[chapter.id];

  useEffect(() => {
    if (chapter && activeStudent && !activeStudent.readChapters.includes(chapter.id)) {
      const timer = window.setTimeout(() => {
        markChapterRead(chapter.id);
      }, 600);
      return () => window.clearTimeout(timer);
    }
  }, [chapter, activeStudent, markChapterRead]);

  const mutagenDetails = {
    fisika: {
      title: 'Mutagen Fisika',
      agents: 'Sinar UV, Sinar-X, Sinar Gamma',
      mechanism: 'Memutus untai DNA atau memicu dimer timin (T=T).',
    },
    kimia: {
      title: 'Mutagen Kimia',
      agents: 'Kolkisin, Asam Nitrit, Benzopiren',
      mechanism: 'Kolkisin menahan benang spindel (memicu sel poliploid 4n).',
    },
    biologi: {
      title: 'Mutagen Biologi',
      agents: 'Virus (HPV, Retrovirus), Transposon',
      mechanism: 'Menyisipkan materi genetik asing ke DNA sel inang.',
    },
  };

  const chapterThemes = [
    {
      banner: 'from-emerald-900 via-emerald-800 to-teal-700',
      cardBg: 'border-emerald-200 bg-emerald-50/60',
      termText: 'text-emerald-950',
    },
    {
      banner: 'from-teal-900 via-teal-800 to-emerald-700',
      cardBg: 'border-teal-200 bg-teal-50/60',
      termText: 'text-teal-950',
    },
    {
      banner: 'from-orange-700 via-orange-600 to-amber-600',
      cardBg: 'border-orange-200 bg-orange-50/55',
      termText: 'text-orange-950',
    },
    {
      banner: 'from-emerald-950 via-emerald-800 to-green-700',
      cardBg: 'border-amber-200 bg-amber-50/55',
      termText: 'text-amber-950',
    },
  ];
  const theme = chapterThemes[activeIdx % chapterThemes.length];

  return (
    <div className="space-y-4">
      {/* Chapter Selector */}
      <section className="rounded-3xl border border-emerald-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
            <BookOpen className="h-4 w-4 text-emerald-600" aria-hidden="true" />
            <span>Materi Ringkas · Bab Mutasi</span>
          </div>
          <span className="text-xs font-semibold text-emerald-800 tabular-nums">
            {readChapters.length}/{MATERIAL_CHAPTERS.length} Selesai Dibaca
          </span>
        </div>

        <div
          role="tablist"
          aria-label="Sub-materi Mutasi"
          className="mt-3 flex gap-2 overflow-x-auto pb-1"
        >
          {MATERIAL_CHAPTERS.map((item, idx) => {
            const active = idx === activeIdx;
            const read = readChapters.includes(item.id);
            return (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveIdx(idx)}
                className={`flex min-h-[44px] items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold whitespace-nowrap shrink-0 transition-colors sm:text-sm ${
                  active
                    ? 'bg-emerald-900 text-white shadow-sm'
                    : read
                      ? 'border border-emerald-200 bg-emerald-50/70 text-emerald-950 hover:bg-emerald-100'
                      : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-emerald-50'
                }`}
              >
                <span>
                  {item.order}. {item.shortTitle}
                </span>
                {read && (
                  <CheckCircle2
                    className={`h-3.5 w-3.5 ${active ? 'text-emerald-300' : 'text-emerald-600'}`}
                    aria-hidden="true"
                  />
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* Main Chapter Card */}
      <article className="overflow-hidden rounded-3xl border border-emerald-200 bg-white shadow-sm">
        <header className={`bg-gradient-to-r ${theme.banner} p-5 text-white sm:p-6 space-y-2.5`}>
          <div className="flex items-center justify-between gap-2 text-xs font-semibold">
            <span className="text-orange-200">
              Bab 0{chapter.order} dari {MATERIAL_CHAPTERS.length}
            </span>
            {isCurrentRead && (
              <span className="inline-flex items-center gap-1 text-emerald-200">
                <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                Terbaca
              </span>
            )}
          </div>
          <h1 className="font-display text-xl font-extrabold sm:text-2xl">
            {chapter.title}
          </h1>
          <p className="text-sm leading-relaxed text-white/90 sm:text-base">{chapter.lead}</p>
        </header>

        <div className="space-y-5 p-4 sm:p-6">
          {/* Fun Fact Callout */}
          <div className="flex items-start gap-2.5 rounded-2xl border border-amber-200 bg-gradient-to-r from-amber-50 to-orange-50/80 p-3.5 text-xs leading-relaxed text-amber-950 sm:text-sm">
            <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-orange-600" aria-hidden="true" />
            <div>
              <strong className="font-bold text-orange-900">Tahukah Kamu? </strong>
              <span>{chapter.funFact}</span>
            </div>
          </div>

        {/* Interactive Simulator First for Visual Engagement */}
        {chapter.interactiveType === 'mutagen' && (
          <div className="rounded-2xl border border-emerald-200 bg-[#F8FAF9] p-4">
            <div className="mb-3 flex items-center gap-2">
              <FlaskConical className="h-5 w-5 text-emerald-800" aria-hidden="true" />
              <h2 className="font-display text-sm font-bold text-emerald-950 sm:text-base">
                Lab Mini: Cek Agen Mutagen
              </h2>
            </div>
            <div className="mb-3 grid grid-cols-3 gap-2">
              {(['fisika', 'kimia', 'biologi'] as const).map((mKey) => (
                <button
                  key={mKey}
                  type="button"
                  onClick={() => setSelectedMutagenTab(mKey)}
                  className={`min-h-[44px] rounded-xl px-2 py-2 text-xs font-bold capitalize transition-colors sm:text-sm ${
                    selectedMutagenTab === mKey
                      ? 'bg-emerald-900 text-white'
                      : 'border border-slate-200 bg-white text-slate-700 hover:bg-emerald-50'
                  }`}
                >
                  {mKey}
                </button>
              ))}
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-3.5 space-y-1">
              <div className="text-sm font-bold text-emerald-950">
                {mutagenDetails[selectedMutagenTab].title}
              </div>
              <div className="text-xs font-semibold text-orange-700">
                Contoh: {mutagenDetails[selectedMutagenTab].agents}
              </div>
              <p className="text-sm text-slate-700">
                {mutagenDetails[selectedMutagenTab].mechanism}
              </p>
            </div>
          </div>
        )}

        {chapter.interactiveType === 'dna-point' && <DnaMutationSimulator />}
        {chapter.interactiveType === 'chromosome-aberration' && <ChromosomeAberrationDiagram />}
        {chapter.interactiveType === 'impact-ploidy' && <WatermelonPloidyDiagram />}

        {/* Scannable Flash Concept Grid */}
        <div className="space-y-4">
          {chapter.sections.map((sec) => (
            <section key={sec.title} className="space-y-2.5">
              <div>
                <h2 className="font-display text-base font-bold text-emerald-950">
                  {sec.title}
                </h2>
                <p className="text-xs text-slate-600 sm:text-sm">{sec.summary}</p>
              </div>
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {sec.cards.map((card) => (
                  <div
                    key={card.term}
                    className={`rounded-2xl border p-3.5 ${theme.cardBg}`}
                  >
                    <div className={`text-sm font-bold ${theme.termText}`}>{card.term}</div>
                    <p className="mt-1 text-xs leading-relaxed text-slate-700 sm:text-sm">
                      {card.brief}
                    </p>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>

        {/* Interactive Quick Concept Check */}
        <section className="rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50/70 to-emerald-50/40 p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-950 sm:text-sm">
            <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-orange-500 text-white shrink-0">
              <HelpCircle className="h-3.5 w-3.5" aria-hidden="true" />
            </span>
            <span>Kuis Kilat: Uji Pahammu!</span>
          </div>
          <p className="text-sm font-semibold text-slate-900">{chapter.quickCheck.question}</p>
          <div className="grid grid-cols-1 gap-2">
            {chapter.quickCheck.options.map((opt, idx) => {
              const isPicked = pickedOption === idx;
              const isCorrect = idx === chapter.quickCheck.correctIndex;
              return (
                <button
                  key={opt}
                  type="button"
                  onClick={() =>
                    setQuickAnswers((prev) => ({ ...prev, [chapter.id]: idx }))
                  }
                  className={`min-h-[44px] rounded-xl border px-3.5 py-2.5 text-left text-xs font-semibold sm:text-sm ${
                    isPicked
                      ? isCorrect
                        ? 'border-emerald-900 bg-emerald-900 text-white'
                        : 'border-red-500 bg-red-50 text-red-900'
                      : 'border-slate-200 bg-white text-slate-800 hover:border-emerald-300 hover:bg-emerald-50'
                  }`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
          {pickedOption !== undefined && (
            <p
              className={`text-xs font-semibold sm:text-sm ${
                pickedOption === chapter.quickCheck.correctIndex
                  ? 'text-emerald-800'
                  : 'text-orange-800'
              }`}
            >
              {pickedOption === chapter.quickCheck.correctIndex
                ? chapter.quickCheck.feedback
                : 'Belum tepat, coba cek lagi pilihan satunya ya!'}
            </p>
          )}
        </section>

        {/* Bottom Prev / Next Chapter Navigation */}
        <footer className="flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <button
            type="button"
            disabled={activeIdx === 0}
            onClick={() => setActiveIdx((prev) => Math.max(0, prev - 1))}
            className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden="true" />
            <span>Materi Sebelumnya</span>
          </button>

          {activeIdx < MATERIAL_CHAPTERS.length - 1 ? (
            <button
              type="button"
              onClick={() => {
                markChapterRead(chapter.id);
                setActiveIdx((prev) => Math.min(MATERIAL_CHAPTERS.length - 1, prev + 1));
              }}
              className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-emerald-900 px-5 py-2.5 text-sm font-bold text-white hover:bg-emerald-800"
            >
              <span>Lanjut Bab Berikutnya</span>
              <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                markChapterRead(chapter.id);
                setRoute('student-lkpd');
              }}
              className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-bold text-white hover:bg-orange-600"
            >
              <span>Mulai LKPD Misi Detektif</span>
              <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </button>
          )}
        </footer>
        </div>
      </article>
    </div>
  );
};
