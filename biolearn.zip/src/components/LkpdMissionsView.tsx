import React, { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  Send,
  Sparkles,
  AlertCircle,
  AlertTriangle,
  Clock,
  RotateCcw,
  Check,
  Loader2,
  MessageSquare,
  Lock,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useBiolearn } from '../context/BiolearnContext';
import { MISI_1_HINTS, MISI_2_SORTING_CARDS } from '../data/curriculum';
import { KaryotypeExplorer, WatermelonPloidyDiagram } from './BioVisuals';
import { ConfettiBurst } from './ConfettiBurst';
import { formatCountdown } from '../utils/validation';
import type { GradingResultRecord, MissionId } from '../types/biolearn';

interface LkpdMissionsViewProps {
  activeTab: MissionId | 'refleksi';
  setActiveTab: (t: MissionId | 'refleksi') => void;
}

const missionPanelVariants = {
  initial: (dir: number) => ({
    opacity: 0,
    x: dir * 28,
    y: 6,
  }),
  animate: {
    opacity: 1,
    x: 0,
    y: 0,
  },
  exit: (dir: number) => ({
    opacity: 0,
    x: dir * -24,
    y: -4,
  }),
};

function FeedbackCard({ grading }: { grading: GradingResultRecord }) {
  const fb = grading.aiFeedback;
  const hasOverride = grading.teacherScoreOverride !== null;

  return (
    <div className="overflow-hidden rounded-2xl border border-emerald-200 bg-white shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 bg-gradient-to-r from-emerald-900 to-teal-800 px-4 py-3.5 text-white sm:px-5">
        <div>
          <div className="text-xs font-semibold text-emerald-100">
            {hasOverride
              ? 'Penilaian Resmi Guru (Final)'
              : fb.source === 'gemini'
                ? 'Evaluasi AI Gemini'
                : 'Evaluasi Otomatis Pilihan Ganda'}
          </div>
          <div className="font-display text-2xl font-extrabold tabular-nums">
            NILAI: {grading.finalScore}/100
          </div>
        </div>
        {hasOverride && (
          <div className="text-xs font-medium text-orange-200 tabular-nums">
            Nilai AI awal: {grading.aiScore}/100
          </div>
        )}
      </div>

      <div className="space-y-2.5 p-4 text-sm leading-relaxed text-slate-800 sm:p-5">
        <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-3">
          <div className="text-xs font-bold text-emerald-900">KONSEP YANG SUDAH BENAR</div>
          <p className="mt-0.5 text-slate-800">{fb.correctConcepts}</p>
        </div>
        <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-3">
          <div className="text-xs font-bold text-amber-900">BAGIAN YANG PERLU DIPERBAIKI</div>
          <p className="mt-0.5 text-slate-800">{fb.needsImprovement}</p>
        </div>
        <div className="rounded-xl border border-teal-200 bg-teal-50/70 p-3">
          <div className="text-xs font-bold text-teal-900">SARAN PERBAIKAN</div>
          <p className="mt-0.5 text-slate-800">{fb.improvementSuggestions}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
          <div className="text-xs font-bold text-slate-800">CATATAN PEMBELAJARAN</div>
          <p className="mt-0.5 text-slate-700">{fb.learningNotes}</p>
        </div>
        {grading.teacherComment.trim().length > 0 && (
          <div className="rounded-xl border border-orange-300 bg-orange-50/70 p-3">
            <div className="mb-1 flex items-center gap-1.5 text-xs font-bold text-orange-800">
              <MessageSquare className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Komentar Resmi Guru</span>
            </div>
            <p className="text-sm text-slate-900">{grading.teacherComment}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export const LkpdMissionsView: React.FC<LkpdMissionsViewProps> = ({
  activeTab,
  setActiveTab,
}) => {
  const {
    db,
    activeStudent,
    remainingSeconds,
    gradingBusyMission,
    saveMissionDraft,
    submitAndGradeMission,
    submitReflection,
    setRoute,
  } = useBiolearn();

  const [openHints, setOpenHints] = useState<string[]>(['hint-1']);
  const [localAnswers, setLocalAnswers] = useState<Record<string, string>>({});
  const [sortingMap, setSortingMap] = useState<Record<string, 'mutasi-gen' | 'mutasi-kromosom'>>({});
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [sortingChecked, setSortingChecked] = useState(false);

  const [refLearned, setRefLearned] = useState('');
  const [refCurious, setRefCurious] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confettiKey, setConfettiKey] = useState(0);
  const [slideDirection, setSlideDirection] = useState<1 | -1>(1);
  const prevTabRef = useRef<MissionId | 'refleksi'>(activeTab);
  const sectionTopRef = useRef<HTMLDivElement | null>(null);

  const m1Done = Boolean(
    db &&
      activeStudent &&
      db.student_answers.some(
        (x) =>
          x.studentId === activeStudent.id &&
          x.missionId === 'misi-1' &&
          (x.status === 'submitted' || x.status === 'graded'),
      ),
  );
  const m2Done = Boolean(
    db &&
      activeStudent &&
      db.student_answers.some(
        (x) =>
          x.studentId === activeStudent.id &&
          x.missionId === 'misi-2' &&
          (x.status === 'submitted' || x.status === 'graded'),
      ),
  );
  const m3Done = Boolean(
    db &&
      activeStudent &&
      db.student_answers.some(
        (x) =>
          x.studentId === activeStudent.id &&
          x.missionId === 'misi-3' &&
          (x.status === 'submitted' || x.status === 'graded'),
      ),
  );

  const isTabUnlocked = (tabId: MissionId | 'refleksi'): boolean => {
    if (tabId === 'misi-1') return true;
    if (tabId === 'misi-2') return m1Done;
    if (tabId === 'misi-3') return m1Done && m2Done;
    return m1Done && m2Done && m3Done;
  };

  const effectiveTab: MissionId | 'refleksi' = isTabUnlocked(activeTab)
    ? activeTab
    : !m1Done
      ? 'misi-1'
      : !m2Done
        ? 'misi-2'
        : 'misi-3';

  // Keep parent activeTab aligned if a locked tab was requested
  useEffect(() => {
    if (activeTab !== effectiveTab) {
      setActiveTab(effectiveTab);
    }
  }, [activeTab, effectiveTab, setActiveTab]);

  // Compute slide direction whenever effectiveTab changes
  useEffect(() => {
    const order: (MissionId | 'refleksi')[] = ['misi-1', 'misi-2', 'misi-3', 'refleksi'];
    const prevIdx = order.indexOf(prevTabRef.current);
    const nextIdx = order.indexOf(effectiveTab);
    if (prevIdx !== -1 && nextIdx !== -1 && prevIdx !== nextIdx) {
      setSlideDirection(nextIdx > prevIdx ? 1 : -1);
    }
    prevTabRef.current = effectiveTab;
  }, [effectiveTab]);

  const navigateMissionTab = (nextTab: MissionId | 'refleksi', scrollToTop = false) => {
    const order: (MissionId | 'refleksi')[] = ['misi-1', 'misi-2', 'misi-3', 'refleksi'];
    const curIdx = order.indexOf(effectiveTab);
    const nextIdx = order.indexOf(nextTab);
    setSlideDirection(nextIdx >= curIdx ? 1 : -1);
    setActiveTab(nextTab);
    if (scrollToTop && sectionTopRef.current) {
      sectionTopRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Sync local form state only when switching effective tabs or student (never on every db auto-save)
  useEffect(() => {
    if (!db || !activeStudent) return;
    setErrorMsg(null);
    setStatusMessage(null);

    if (effectiveTab === 'refleksi') {
      const ref = db.reflections.find((r) => r.studentId === activeStudent.id);
      setRefLearned(ref?.newThingLearned ?? '');
      setRefCurious(ref?.curiousQuestion ?? '');
      return;
    }

    const ans = db.student_answers.find(
      (a) => a.studentId === activeStudent.id && a.missionId === effectiveTab,
    );
    setLocalAnswers(ans?.answers ?? {});
    if (effectiveTab === 'misi-2') {
      setSortingMap(ans?.sortingAssignments ?? {});
      setSortingChecked(typeof ans?.sortingScore === 'number');
      setSelectedCardId(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveTab, activeStudent?.id]);

  if (!db || !activeStudent) return null;

  const isLockedByExpiry =
    db.settings.timerEnabled && db.settings.lockOnTimeExpired && activeStudent.timeExpiredLocked;

  const getMissionDone = (mId: MissionId) => {
    if (mId === 'misi-1') return m1Done;
    if (mId === 'misi-2') return m2Done;
    return m3Done;
  };

  const computeSortingScore = (map: Record<string, 'mutasi-gen' | 'mutasi-kromosom'>) => {
    let correct = 0;
    for (const card of MISI_2_SORTING_CARDS) {
      if (map[card.id] === card.correctCategory) correct += 1;
    }
    return Math.round((correct / MISI_2_SORTING_CARDS.length) * 100);
  };

  const handleAnswerChange = (missionId: MissionId, qId: string, val: string) => {
    if (isLockedByExpiry) return;
    const next = { ...localAnswers, [qId]: val };
    setLocalAnswers(next);
    saveMissionDraft({
      missionId,
      answers: next,
      sortingAssignments: missionId === 'misi-2' ? sortingMap : undefined,
      sortingScore: missionId === 'misi-2' && sortingChecked ? computeSortingScore(sortingMap) : undefined,
    });
  };

  const assignCardCategory = (
    cardId: string,
    category: 'mutasi-gen' | 'mutasi-kromosom',
  ) => {
    if (isLockedByExpiry) return;
    const nextMap = { ...sortingMap, [cardId]: category };
    setSortingMap(nextMap);
    setSelectedCardId(null);
    setSortingChecked(false);
    saveMissionDraft({
      missionId: 'misi-2',
      answers: localAnswers,
      sortingAssignments: nextMap,
    });
  };

  const handleCheckSorting = () => {
    const score = computeSortingScore(sortingMap);
    setSortingChecked(true);
    saveMissionDraft({
      missionId: 'misi-2',
      answers: localAnswers,
      sortingAssignments: sortingMap,
      sortingScore: score,
    });
  };

  const handleSubmitMission = async (missionId: MissionId) => {
    setErrorMsg(null);
    setStatusMessage(null);
    const questions = db.questions.filter((q) => q.missionId === missionId);
    const allAnswered = questions.every((q) => (localAnswers[q.id] ?? '').trim().length > 0);
    if (!allAnswered) {
      setErrorMsg('Harap pilih jawaban (A, B, C, atau D) untuk seluruh soal sebelum mengirim.');
      return;
    }

    let sortingScore: number | undefined;
    if (missionId === 'misi-2') {
      if (Object.keys(sortingMap).length < MISI_2_SORTING_CARDS.length) {
        setErrorMsg('Kelompokkan seluruh 10 kartu konsep terlebih dahulu sebelum mengirim Misi 2.');
        return;
      }
      sortingScore = computeSortingScore(sortingMap);
      setSortingChecked(true);
    }

    const res = await submitAndGradeMission({
      missionId,
      answers: localAnswers,
      sortingAssignments: missionId === 'misi-2' ? sortingMap : undefined,
      sortingScore,
    });

    if (!res.ok) {
      setErrorMsg(res.error ?? 'Gagal menilai misi.');
      return;
    }

    setConfettiKey((prev) => prev + 1);
    setStatusMessage('Selamat! Misi berhasil diselesaikan dan dinilai. Poin serta badge telah diperbarui.');
  };

  const handleSubmitReflection = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (refLearned.trim().length < 5 || refCurious.trim().length < 5) {
      setErrorMsg('Mohon isi kedua bagian refleksi dengan kalimat yang jelas.');
      return;
    }
    submitReflection({ newThingLearned: refLearned, curiousQuestion: refCurious });
    setRoute('student-leaderboard');
  };

  const activeMission =
    effectiveTab !== 'refleksi' ? db.assignments.find((m) => m.id === effectiveTab) : undefined;
  const activeQuestions =
    effectiveTab !== 'refleksi'
      ? db.questions.filter((q) => q.missionId === effectiveTab).sort((a, b) => a.order - b.order)
      : [];
  const activeGrading =
    effectiveTab !== 'refleksi'
      ? db.grading_results.find(
          (g) => g.studentId === activeStudent.id && g.missionId === effectiveTab,
        )
      : undefined;

  const unassignedCards = MISI_2_SORTING_CARDS.filter((c) => !sortingMap[c.id]);
  const genCards = MISI_2_SORTING_CARDS.filter((c) => sortingMap[c.id] === 'mutasi-gen');
  const kromCards = MISI_2_SORTING_CARDS.filter((c) => sortingMap[c.id] === 'mutasi-kromosom');
  const correctSortCount = MISI_2_SORTING_CARDS.filter(
    (c) => sortingMap[c.id] === c.correctCategory,
  ).length;

  const timerEnabled = db.settings.timerEnabled;
  const totalDurationSeconds = Math.max(60, db.settings.timerDurationMinutes * 60);
  const timeProgressPercent = Math.max(
    0,
    Math.min(100, Math.round((remainingSeconds / totalDurationSeconds) * 100)),
  );
  const allMissionsCompleted = m1Done && m2Done && m3Done;
  const isTimeCritical = timerEnabled && !allMissionsCompleted && remainingSeconds > 0 && remainingSeconds <= 60;
  const isTimeWarning =
    timerEnabled && !allMissionsCompleted && remainingSeconds > 60 && remainingSeconds <= 180;
  const isTimeExpired = timerEnabled && !allMissionsCompleted && remainingSeconds === 0;

  return (
    <div ref={sectionTopRef} className="space-y-5 overflow-x-hidden">
      <ConfettiBurst triggerKey={confettiKey} onComplete={() => setConfettiKey(0)} />

      {/* LKPD Pressure Timer Banner (shown exclusively inside LKPD) */}
      {timerEnabled && (
        <section
          aria-label="Timer Pengerjaan LKPD"
          className={`rounded-2xl border p-3.5 shadow-sm transition-colors sm:px-5 sm:py-4 ${
            allMissionsCompleted
              ? 'border-emerald-300 bg-gradient-to-r from-emerald-50 to-teal-50'
              : isTimeExpired || isTimeCritical
                ? 'border-red-300 bg-gradient-to-r from-red-50 to-orange-50'
                : isTimeWarning
                  ? 'border-orange-300 bg-gradient-to-r from-orange-50 to-amber-50'
                  : 'border-emerald-800/30 bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-800 text-white'
          }`}
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-2.5">
              <div
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                  allMissionsCompleted
                    ? 'bg-emerald-600 text-white'
                    : isTimeExpired || isTimeCritical
                      ? 'bg-red-600 text-white'
                      : isTimeWarning
                        ? 'bg-orange-500 text-white'
                        : 'bg-white/15 text-orange-300'
                }`}
              >
                <Clock className="h-5 w-5" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <div
                  className={`text-xs font-extrabold sm:text-sm ${
                    allMissionsCompleted
                      ? 'text-emerald-950'
                      : isTimeExpired || isTimeCritical
                        ? 'text-red-950'
                        : isTimeWarning
                          ? 'text-orange-950'
                          : 'text-white'
                  }`}
                >
                  {allMissionsCompleted
                    ? 'Seluruh Misi LKPD Selesai!'
                    : isTimeExpired
                      ? 'Waktu Pengerjaan LKPD Habis!'
                      : isTimeCritical
                        ? 'Waktu Hampir Habis! Segera Kirim Jawaban!'
                        : isTimeWarning
                          ? 'Ayo Kejar Waktu! Sisa kurang dari 3 menit'
                          : `Timer Pengerjaan LKPD (${db.settings.timerDurationMinutes} Menit)`}
                </div>
                <p
                  className={`text-[11px] sm:text-xs ${
                    allMissionsCompleted
                      ? 'text-emerald-800'
                      : isTimeExpired || isTimeCritical
                        ? 'text-red-800'
                        : isTimeWarning
                          ? 'text-orange-800'
                          : 'text-emerald-100'
                  }`}
                >
                  {allMissionsCompleted
                    ? 'Kerja bagus! Kamu berhasil menuntaskan Misi 1–3 tepat waktu.'
                    : isTimeExpired
                      ? 'Jawaban tersimpan sudah dikumpulkan otomatis saat waktu berakhir.'
                      : 'Selesaikan Misi 1–3 sebelum hitung mundur mencapai 00:00.'}
                </p>
              </div>
            </div>

            <div
              data-testid="lkpd-timer-countdown"
              className={`shrink-0 rounded-xl px-3 py-1.5 font-mono text-lg font-extrabold tracking-tight tabular-nums sm:text-xl ${
                allMissionsCompleted
                  ? 'bg-emerald-100 text-emerald-900'
                  : isTimeExpired || isTimeCritical
                    ? 'bg-red-600 text-white shadow-sm'
                    : isTimeWarning
                      ? 'bg-orange-500 text-white shadow-sm'
                      : 'bg-white text-emerald-950 shadow-sm'
              }`}
            >
              {formatCountdown(remainingSeconds)}
            </div>
          </div>

          {!allMissionsCompleted && (
            <div className="mt-2.5 h-2 w-full overflow-hidden rounded-full bg-black/15">
              <div
                className={`h-full rounded-full transition-all duration-700 ${
                  isTimeExpired || isTimeCritical
                    ? 'bg-red-600'
                    : isTimeWarning
                      ? 'bg-orange-500'
                      : 'bg-orange-400'
                }`}
                style={{ width: `${timeProgressPercent}%` }}
              />
            </div>
          )}
        </section>
      )}

      {isTimeExpired && (
        <div
          role="status"
          className="flex items-start gap-2.5 rounded-2xl border border-red-300 bg-red-50 p-3.5 text-xs font-semibold text-red-900 sm:text-sm"
        >
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
          <span>
            {db.settings.lockOnTimeExpired
              ? 'Waktu pengerjaan 10 menit telah berakhir dan LKPD dikunci otomatis.'
              : 'Waktu pengerjaan 10 menit telah habis. Jawabanmu tetap tersimpan dan bisa ditinjau.'}
          </span>
        </div>
      )}

      {/* Mission Selector Tabs */}
      <section className="rounded-3xl border border-emerald-200 bg-white p-4 shadow-sm sm:p-5">
        <h1 className="font-display text-lg font-extrabold text-emerald-950 sm:text-xl">
          LKPD Interaktif: Misi Detektif Mengungkap Rahasia Mutasi
        </h1>
        <p className="mt-1 text-xs text-slate-600 sm:text-sm">
          Misi dibuka secara bertahap: selesaikan dan kirim Misi 1 untuk membuka Misi 2, lalu Misi 3 dan Refleksi.
        </p>

        <div className="mt-4 flex gap-1.5 overflow-x-auto pb-1 sm:gap-2" role="tablist">
          {(['misi-1', 'misi-2', 'misi-3', 'refleksi'] as const).map((tabId, idx) => {
            const unlocked = isTabUnlocked(tabId);
            const active = effectiveTab === tabId;
            const done =
              tabId === 'refleksi'
                ? db.reflections.some((r) => r.studentId === activeStudent.id)
                : getMissionDone(tabId);
            const label = tabId === 'refleksi' ? 'Refleksi' : `Misi ${idx + 1}`;
            return (
              <motion.button
                key={tabId}
                type="button"
                role="tab"
                disabled={!unlocked}
                aria-selected={active}
                whileTap={unlocked ? { scale: 0.96 } : undefined}
                onClick={() => {
                  if (unlocked) navigateMissionTab(tabId);
                }}
                className={`relative flex min-h-[44px] items-center gap-1 rounded-xl px-2.5 py-2 text-xs font-bold whitespace-nowrap shrink-0 transition-colors sm:gap-1.5 sm:px-4 sm:text-sm ${
                  !unlocked
                    ? 'cursor-not-allowed border border-slate-200 bg-slate-100 text-slate-400'
                    : active
                      ? 'bg-emerald-900 text-white shadow-sm'
                      : done
                        ? 'border border-emerald-300 bg-emerald-50 text-emerald-900 hover:bg-emerald-100'
                        : 'border border-orange-300 bg-orange-50 text-orange-900 hover:bg-orange-100'
                }`}
              >
                {!unlocked && <Lock className="h-3.5 w-3.5" aria-hidden="true" />}
                <span>{label}</span>
                {done && (
                  <CheckCircle2
                    className={`h-3.5 w-3.5 ${active ? 'text-emerald-300' : 'text-emerald-600'}`}
                    aria-hidden="true"
                  />
                )}
              </motion.button>
            );
          })}
        </div>
      </section>

      {errorMsg && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-800"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
          <span>{errorMsg}</span>
        </div>
      )}

      <AnimatePresence>
        {statusMessage && (
          <motion.div
            key={statusMessage}
            role="status"
            initial={{ opacity: 0, y: -10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="flex items-start gap-2.5 rounded-2xl border border-emerald-300 bg-gradient-to-r from-emerald-50 to-teal-50 p-4 text-sm font-semibold text-emerald-900 shadow-sm"
          >
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" aria-hidden="true" />
            <span>{statusMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ANIMATED MISSION / REFLECTION PANEL TRANSITION */}
      <AnimatePresence mode="wait" custom={slideDirection}>
        <motion.div
          key={effectiveTab}
          custom={slideDirection}
          variants={missionPanelVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          transition={{ duration: 0.26, ease: [0.22, 1, 0.36, 1] }}
        >
          {/* MISSION 1, 2, or 3 BODY */}
          {effectiveTab !== 'refleksi' && activeMission && (
            <div className="space-y-5">
              {/* Case Brief */}
              <section className="rounded-3xl border border-emerald-200 bg-white p-5 shadow-sm sm:p-6 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-bold text-orange-600">
                {activeMission.subtitle}
              </span>
              <span className="text-xs font-semibold text-emerald-800">
                Maks. {activeMission.maxAccuracyPoints + activeMission.completionPoints} Poin
              </span>
            </div>
            <h2 className="font-display text-xl font-extrabold text-emerald-950">
              {activeMission.title}
            </h2>
            <div className="rounded-2xl bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-800 p-4 text-white">
              <div className="text-xs font-semibold text-orange-200">Pertanyaan Utama Investigasi</div>
              <div className="mt-1 font-display text-base font-bold sm:text-lg">
                &ldquo;{activeMission.mainQuestion}&rdquo;
              </div>
            </div>
            <p className="text-sm leading-relaxed text-slate-700">{activeMission.caseSummary}</p>
          </section>

          {/* Misi 1 Interactive Assets & Hint Cards */}
          {effectiveTab === 'misi-1' && (
            <>
              <WatermelonPloidyDiagram />

              <section className="rounded-3xl border border-amber-200 bg-gradient-to-b from-amber-50/70 to-white p-5 shadow-sm space-y-3">
                <div className="flex items-center gap-2">
                  <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-orange-500 text-white shrink-0">
                    <Lightbulb className="h-4 w-4" aria-hidden="true" />
                  </span>
                  <h3 className="font-display text-base font-bold text-amber-950">
                    Kartu Petunjuk Detektif (Buka Bertahap)
                  </h3>
                </div>
                <div className="space-y-2.5">
                  {MISI_1_HINTS.map((hint) => {
                    const isOpen = openHints.includes(hint.id);
                    return (
                      <div key={hint.id} className="overflow-hidden rounded-2xl border border-amber-200 bg-white">
                        <button
                          type="button"
                          aria-expanded={isOpen}
                          onClick={() =>
                            setOpenHints((prev) =>
                              prev.includes(hint.id)
                                ? prev.filter((x) => x !== hint.id)
                                : [...prev, hint.id],
                            )
                          }
                          className="flex min-h-[48px] w-full items-center justify-between gap-3 bg-amber-50/70 px-4 py-3 text-left text-sm font-bold text-amber-950 hover:bg-amber-100/70"
                        >
                          <span>{hint.title}</span>
                          {isOpen ? (
                            <ChevronUp className="h-4 w-4 shrink-0 text-orange-600" aria-hidden="true" />
                          ) : (
                            <ChevronDown className="h-4 w-4 shrink-0 text-orange-600" aria-hidden="true" />
                          )}
                        </button>
                        {isOpen && (
                          <div className="bg-white p-4 text-sm leading-relaxed text-slate-700">
                            {hint.content}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </section>
            </>
          )}

          {/* Misi 2 Tap-to-Assign & Drag-and-Drop Hybrid Sorting */}
          {effectiveTab === 'misi-2' && (
            <section className="rounded-3xl border border-slate-200 bg-white p-4 sm:p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="font-display text-base font-bold text-emerald-950 sm:text-lg">
                    Aktivitas Pengelompokan Konsep (Tap / Drag-and-Drop)
                  </h3>
                  <p className="text-xs text-slate-600 sm:text-sm">
                    Di HP: ketuk kartu lalu ketuk kategori tujuan (atau tekan langsung tombol kategori di kartu). Di laptop: dapat juga diseret (drag).
                  </p>
                </div>
                <button
                  type="button"
                  disabled={isLockedByExpiry}
                  onClick={() => {
                    setSortingMap({});
                    setSortingChecked(false);
                    setSelectedCardId(null);
                  }}
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Reset Kartu</span>
                </button>
              </div>

              {/* Unassigned Pool */}
              <div className="rounded-2xl border border-slate-200 bg-[#F8FAF9] p-3.5 space-y-2.5">
                <div className="text-xs font-bold text-slate-600">
                  Kartu Konsep Belum Dikelompokkan ({unassignedCards.length}/{MISI_2_SORTING_CARDS.length})
                </div>
                {unassignedCards.length === 0 ? (
                  <p className="py-2 text-center text-xs font-semibold text-emerald-700">
                    Semua kartu sudah dimasukkan ke kategori! Tekan &ldquo;Periksa Pengelompokan&rdquo; di bawah.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    {unassignedCards.map((card) => {
                      const isSelected = selectedCardId === card.id;
                      return (
                        <div
                          key={card.id}
                          draggable={!isLockedByExpiry}
                          onDragStart={(e) => {
                            e.dataTransfer.setData('text/plain', card.id);
                          }}
                          className={`rounded-xl border p-3 transition-all ${
                            isSelected
                              ? 'border-orange-500 bg-orange-50 ring-2 ring-orange-500/20'
                              : 'border-slate-200 bg-white'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() =>
                              setSelectedCardId((prev) => (prev === card.id ? null : card.id))
                            }
                            className="w-full text-left"
                          >
                            <div className="text-sm font-bold text-emerald-950">{card.label}</div>
                            <p className="mt-0.5 text-xs text-slate-600">{card.detail}</p>
                          </button>

                          <div className="mt-2.5 grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              disabled={isLockedByExpiry}
                              onClick={() => assignCardCategory(card.id, 'mutasi-gen')}
                              className="min-h-[44px] rounded-lg border border-emerald-300 bg-emerald-50 px-2 py-1.5 text-xs font-bold text-emerald-900 hover:bg-emerald-100"
                            >
                              + Mutasi Gen
                            </button>
                            <button
                              type="button"
                              disabled={isLockedByExpiry}
                              onClick={() => assignCardCategory(card.id, 'mutasi-kromosom')}
                              className="min-h-[44px] rounded-lg border border-orange-300 bg-orange-50 px-2 py-1.5 text-xs font-bold text-orange-900 hover:bg-orange-100"
                            >
                              + Mutasi Kromosom
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Two Target Category Buckets */}
              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                {/* Mutasi Gen Bucket */}
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const cid = e.dataTransfer.getData('text/plain');
                    if (cid) assignCardCategory(cid, 'mutasi-gen');
                  }}
                  className={`rounded-2xl border-2 p-4 transition-colors ${
                    selectedCardId
                      ? 'border-emerald-500 bg-emerald-50/60'
                      : 'border-emerald-200 bg-emerald-50/30'
                  }`}
                >
                  <div className="mb-3 flex items-center justify-between gap-2">
                    <h4 className="font-display text-sm font-extrabold text-emerald-950">
                      Kategori: Mutasi Gen ({genCards.length})
                    </h4>
                    {selectedCardId && (
                      <button
                        type="button"
                        onClick={() => assignCardCategory(selectedCardId, 'mutasi-gen')}
                        className="min-h-[36px] rounded-lg bg-emerald-900 px-3 py-1 text-xs font-bold text-white"
                      >
                        Taruh di Sini
                      </button>
                    )}
                  </div>
                  <div className="space-y-2">
                    {genCards.map((card) => {
                      const isCorrect = card.correctCategory === 'mutasi-gen';
                      return (
                        <div
                          key={card.id}
                          className={`flex items-center justify-between gap-2 rounded-xl border p-2.5 text-xs ${
                            sortingChecked
                              ? isCorrect
                                ? 'border-emerald-400 bg-white'
                                : 'border-red-400 bg-red-50'
                              : 'border-emerald-200 bg-white'
                          }`}
                        >
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900">{card.label}</div>
                            {sortingChecked && (
                              <div className={isCorrect ? 'text-emerald-700 font-semibold' : 'text-red-700 font-semibold'}>
                                {isCorrect ? 'Benar' : 'Kurang tepat (Seharusnya Mutasi Kromosom)'}
                              </div>
                            )}
                          </div>
                          {!isLockedByExpiry && (
                            <button
                              type="button"
                              aria-label={`Keluarkan ${card.label}`}
                              onClick={() => {
                                const next = { ...sortingMap };
                                delete next[card.id];
                                setSortingMap(next);
                                setSortingChecked(false);
                              }}
                              className="min-h-[36px] shrink-0 rounded-lg px-2 text-xs font-semibold text-slate-500 hover:bg-slate-100"
                            >
                              Ubah
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Mutasi Kromosom Bucket */}
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const cid = e.dataTransfer.getData('text/plain');
                    if (cid) assignCardCategory(cid, 'mutasi-kromosom');
                  }}
                  className={`rounded-2xl border-2 p-4 transition-colors ${
                    selectedCardId
                      ? 'border-orange-500 bg-orange-50/60'
                      : 'border-orange-200 bg-orange-50/30'
                  }`}
                >
                  <div className="mb-3 flex items-center justify-between gap-2">
                    <h4 className="font-display text-sm font-extrabold text-orange-950">
                      Kategori: Mutasi Kromosom ({kromCards.length})
                    </h4>
                    {selectedCardId && (
                      <button
                        type="button"
                        onClick={() => assignCardCategory(selectedCardId, 'mutasi-kromosom')}
                        className="min-h-[36px] rounded-lg bg-orange-600 px-3 py-1 text-xs font-bold text-white"
                      >
                        Taruh di Sini
                      </button>
                    )}
                  </div>
                  <div className="space-y-2">
                    {kromCards.map((card) => {
                      const isCorrect = card.correctCategory === 'mutasi-kromosom';
                      return (
                        <div
                          key={card.id}
                          className={`flex items-center justify-between gap-2 rounded-xl border p-2.5 text-xs ${
                            sortingChecked
                              ? isCorrect
                                ? 'border-emerald-400 bg-white'
                                : 'border-red-400 bg-red-50'
                              : 'border-orange-200 bg-white'
                          }`}
                        >
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900">{card.label}</div>
                            {sortingChecked && (
                              <div className={isCorrect ? 'text-emerald-700 font-semibold' : 'text-red-700 font-semibold'}>
                                {isCorrect ? 'Benar' : 'Kurang tepat (Seharusnya Mutasi Gen)'}
                              </div>
                            )}
                          </div>
                          {!isLockedByExpiry && (
                            <button
                              type="button"
                              aria-label={`Keluarkan ${card.label}`}
                              onClick={() => {
                                const next = { ...sortingMap };
                                delete next[card.id];
                                setSortingMap(next);
                                setSortingChecked(false);
                              }}
                              className="min-h-[36px] shrink-0 rounded-lg px-2 text-xs font-semibold text-slate-500 hover:bg-slate-100"
                            >
                              Ubah
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleCheckSorting}
                  className="inline-flex min-h-[46px] items-center gap-2 rounded-xl bg-emerald-800 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-900"
                >
                  <Check className="h-4 w-4" aria-hidden="true" />
                  <span>Periksa Pengelompokan</span>
                </button>
                {sortingChecked && (
                  <div className="text-sm font-bold text-emerald-900 tabular-nums">
                    Ketepatan Pengelompokan: {correctSortCount}/{MISI_2_SORTING_CARDS.length} kartu benar (
                    {computeSortingScore(sortingMap)}%)
                  </div>
                )}
              </div>
            </section>
          )}

          {/* Misi 3 Karyotype Explorer */}
          {effectiveTab === 'misi-3' && <KaryotypeExplorer />}

          {/* Multiple Choice Questions Form (Pilihan Ganda) */}
          <section className="overflow-hidden rounded-3xl border border-emerald-200 bg-white shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-100 bg-emerald-50/70 px-5 py-4 sm:px-6">
              <div>
                <h3 className="font-display text-base font-bold text-emerald-950 sm:text-lg">
                  Soal Pilihan Ganda Investigasi
                </h3>
                <p className="text-xs text-emerald-800">
                  Pilih satu jawaban yang paling tepat (A–D) · Pilihan tersimpan otomatis
                </p>
              </div>
              <span className="font-mono text-xs font-bold text-emerald-900 tabular-nums">
                {activeQuestions.filter((q) => Boolean(localAnswers[q.id])).length}/{activeQuestions.length} Terjawab
              </span>
            </div>

            <div className="space-y-4 p-4 sm:p-6">
              {activeQuestions.map((q, qIdx) => {
                const selectedOptId = (localAnswers[q.id] ?? '').trim();
                const isGraded = Boolean(activeGrading);
                const isQuestionCorrect =
                  isGraded && selectedOptId.toUpperCase() === q.correctOptionId.toUpperCase();

                return (
                  <div
                    key={q.id}
                    className={`space-y-3 rounded-2xl border p-4 transition-colors ${
                      isGraded
                        ? isQuestionCorrect
                          ? 'border-emerald-300 bg-emerald-50/30'
                          : 'border-amber-300 bg-amber-50/30'
                        : 'border-slate-200 bg-slate-50/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-start gap-2.5 text-sm font-bold text-slate-900 sm:text-base">
                        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-emerald-800 font-mono text-xs font-bold text-white tabular-nums">
                          {qIdx + 1}
                        </span>
                        <span className="pt-0.5 leading-snug">{q.prompt}</span>
                      </div>
                      {isGraded && (
                        <span
                          className={`shrink-0 rounded-lg px-2 py-1 text-xs font-bold ${
                            isQuestionCorrect
                              ? 'bg-emerald-100 text-emerald-900'
                              : 'bg-amber-100 text-amber-900'
                          }`}
                        >
                          {isQuestionCorrect ? 'Benar ✓' : `Kunci: ${q.correctOptionId}`}
                        </span>
                      )}
                    </div>

                    <div role="radiogroup" aria-label={`Soal ${qIdx + 1}`} className="space-y-2">
                      {(q.options ?? []).map((opt) => {
                        const isSelected = selectedOptId === opt.id;
                        const isCorrectOpt = opt.id === q.correctOptionId;

                        let cardClasses =
                          'border-slate-200 bg-white text-slate-800 hover:border-emerald-400 hover:bg-emerald-50/40';
                        let letterClasses = 'bg-slate-100 text-slate-700 border-slate-300';

                        if (isGraded) {
                          if (isCorrectOpt) {
                            cardClasses =
                              'border-emerald-500 bg-emerald-50 text-emerald-950 ring-1 ring-emerald-500/30';
                            letterClasses = 'bg-emerald-700 text-white border-emerald-700';
                          } else if (isSelected && !isCorrectOpt) {
                            cardClasses = 'border-red-400 bg-red-50 text-red-950';
                            letterClasses = 'bg-red-600 text-white border-red-600';
                          }
                        } else if (isSelected) {
                          cardClasses =
                            'border-emerald-600 bg-emerald-50 text-emerald-950 ring-2 ring-emerald-500/20';
                          letterClasses = 'bg-emerald-800 text-white border-emerald-800';
                        }

                        return (
                          <button
                            key={opt.id}
                            type="button"
                            role="radio"
                            aria-checked={isSelected}
                            disabled={isLockedByExpiry}
                            onClick={() => handleAnswerChange(activeMission.id, q.id, opt.id)}
                            className={`flex min-h-[50px] w-full items-start gap-3 rounded-xl border p-3 text-left text-sm transition-all disabled:cursor-not-allowed sm:items-center ${cardClasses}`}
                          >
                            <span
                              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border font-mono text-xs font-extrabold ${letterClasses}`}
                            >
                              {opt.id}
                            </span>
                            <span className="flex-1 leading-relaxed font-medium">{opt.text}</span>
                          </button>
                        );
                      })}
                    </div>

                    {isGraded && q.explanation && (
                      <div className="rounded-xl border border-teal-200 bg-teal-50/70 p-3 text-xs leading-relaxed text-teal-950 sm:text-sm">
                        <span className="font-bold">Pembahasan: </span>
                        {q.explanation}
                      </div>
                    )}
                  </div>
                );
              })}

            <div className="flex flex-col gap-3 pt-2 sm:flex-row sm:items-center sm:justify-between">
              <button
                type="button"
                disabled={isLockedByExpiry || gradingBusyMission === activeMission.id}
                onClick={() => handleSubmitMission(activeMission.id)}
                className="flex min-h-[50px] items-center justify-center gap-2 rounded-2xl bg-orange-500 px-6 py-3 text-base font-bold text-white shadow-sm transition-colors hover:bg-orange-600 disabled:opacity-50"
              >
                {gradingBusyMission === activeMission.id ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
                    <span>Memeriksa Jawaban...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" aria-hidden="true" />
                    <span>
                      {activeGrading
                        ? 'Perbarui Jawaban & Cek Nilai'
                        : `Kirim & Periksa ${activeMission.title.split(':')[0]}`}
                    </span>
                  </>
                )}
              </button>

              {effectiveTab === 'misi-1' && activeGrading && (
                <motion.button
                  type="button"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.25 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => navigateMissionTab('misi-2', true)}
                  className="min-h-[46px] rounded-xl border border-emerald-400 bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-900 hover:bg-emerald-100"
                >
                  Lanjut ke Misi 2 →
                </motion.button>
              )}
              {effectiveTab === 'misi-2' && activeGrading && (
                <motion.button
                  type="button"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.25 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => navigateMissionTab('misi-3', true)}
                  className="min-h-[46px] rounded-xl border border-emerald-400 bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-900 hover:bg-emerald-100"
                >
                  Lanjut ke Misi 3 →
                </motion.button>
              )}
              {effectiveTab === 'misi-3' && activeGrading && (
                <motion.button
                  type="button"
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.25 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => navigateMissionTab('refleksi', true)}
                  className="min-h-[46px] rounded-xl border border-emerald-400 bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-900 hover:bg-emerald-100"
                >
                  Lanjut ke Refleksi →
                </motion.button>
              )}
            </div>
            </div>
          </section>

          {activeGrading && (
            <motion.div
              initial={{ opacity: 0, y: 14, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
            >
              <FeedbackCard grading={activeGrading} />
            </motion.div>
          )}
        </div>
      )}

      {/* REFLEKSI PEMBELAJARAN */}
      {effectiveTab === 'refleksi' && (
        <section className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-900 text-white">
              <Sparkles className="h-5 w-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-lg font-extrabold text-emerald-950">
                Refleksi Pembelajaran Mutasi
              </h2>
              <p className="text-xs text-slate-600">
                Melengkapi refleksi membuka tambahan poin keaktifan dan badge Peneliti Hebat.
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmitReflection} className="space-y-4">
            <div>
              <label htmlFor="ref-learned" className="mb-1.5 block text-sm font-bold text-slate-800">
                1. Satu hal baru yang kamu pelajari hari ini
              </label>
              <textarea
                id="ref-learned"
                rows={4}
                required
                disabled={isLockedByExpiry}
                value={refLearned}
                onChange={(e) => setRefLearned(e.target.value)}
                placeholder="Tuliskan pemahaman baru paling berkesan yang kamu temukan dari misi hari ini..."
                className="w-full rounded-2xl border border-slate-300 bg-white p-3.5 text-base text-slate-900 focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div>
              <label htmlFor="ref-curious" className="mb-1.5 block text-sm font-bold text-slate-800">
                2. Satu pertanyaan yang masih membuatmu penasaran
              </label>
              <textarea
                id="ref-curious"
                rows={4}
                required
                disabled={isLockedByExpiry}
                value={refCurious}
                onChange={(e) => setRefCurious(e.target.value)}
                placeholder="Tuliskan hal yang masih ingin kamu gali lebih dalam tentang mutasi genetik..."
                className="w-full rounded-2xl border border-slate-300 bg-white p-3.5 text-base text-slate-900 focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">
              <button
                type="submit"
                disabled={isLockedByExpiry}
                className="flex min-h-[50px] items-center justify-center gap-2 rounded-2xl bg-emerald-900 px-6 py-3 text-base font-bold text-white hover:bg-emerald-800"
              >
                <CheckCircle2 className="h-5 w-5" aria-hidden="true" />
                <span>Selesai &amp; Lihat Peringkat</span>
              </button>
              <button
                type="button"
                onClick={() => setRoute('student-leaderboard')}
                className="flex min-h-[50px] items-center justify-center rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-bold text-slate-700 hover:bg-slate-50"
              >
                Lihat Peringkat Kelas
              </button>
            </div>
          </form>
        </section>
      )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
