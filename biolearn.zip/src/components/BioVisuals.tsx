import React, { useState } from 'react';

/* 1. Interactive DNA Point Mutation Simulator (Used in Material Chapter 2 & Mutagen Chapter 1) */
type DnaSimMode = 'normal' | 'silent' | 'missense' | 'nonsense' | 'frameshift';

const DNA_SIM_DATA: Record<
  DnaSimMode,
  {
    label: string;
    dnaCodons: [string, string, string];
    mrnaCodons: [string, string, string];
    aminoAcids: [string, string, string];
    changedIndex: number | null;
    explanation: string;
  }
> = {
  normal: {
    label: 'Normal',
    dnaCodons: ['TAC', 'CTT', 'GAA'],
    mrnaCodons: ['AUG', 'GAA', 'CUU'],
    aminoAcids: ['Met (Start)', 'Glu', 'Leu'],
    changedIndex: null,
    explanation:
      'Untai DNA template normal ditranskripsi menjadi mRNA AUG-GAA-CUU dan menghasilkan rantai asam amino Metionin – Glutamat – Leusin.',
  },
  silent: {
    label: 'Silent Mutation',
    dnaCodons: ['TAC', 'CTC', 'GAA'],
    mrnaCodons: ['AUG', 'GAG', 'CUU'],
    aminoAcids: ['Met (Start)', 'Glu', 'Leu'],
    changedIndex: 1,
    explanation:
      'Basa ke-6 berubah (T → C, transisi). Kodon mRNA berubah dari GAA menjadi GAG, tetapi keduanya tetap mengkodekan asam amino Glutamat (Glu).',
  },
  missense: {
    label: 'Missense (Sel Sabit)',
    dnaCodons: ['TAC', 'CAT', 'GAA'],
    mrnaCodons: ['AUG', 'GUA', 'CUU'],
    aminoAcids: ['Met (Start)', 'Val', 'Leu'],
    changedIndex: 1,
    explanation:
      'Transversi T → A mengubah kodon GAA menjadi GUA. Asam amino Glutamat berubah menjadi Valin, memicu kelainan hemoglobin anemia sel sabit.',
  },
  nonsense: {
    label: 'Nonsense Mutation',
    dnaCodons: ['TAC', 'ATT', 'GAA'],
    mrnaCodons: ['AUG', 'UAA', 'CUU'],
    aminoAcids: ['Met (Start)', 'STOP', '—'],
    changedIndex: 1,
    explanation:
      'Substitusi C → A pada kodon kedua membentuk kodon stop UAA sehingga translasi berhenti terlalu dini dan protein gagal terbentuk utuh.',
  },
  frameshift: {
    label: 'Frameshift (Insersi)',
    dnaCodons: ['TAC', 'ACT', 'TGA'],
    mrnaCodons: ['AUG', 'UGA', 'ACU'],
    aminoAcids: ['Met (Start)', 'STOP / Bergeser', 'Thr'],
    changedIndex: 1,
    explanation:
      'Penyisipan satu basa Adenin (A) sebelum CTT menggeser seluruh kerangka pembacaan triplet ke kanan sehingga semua kodon berikutnya berubah.',
  },
};

export const DnaMutationSimulator: React.FC = () => {
  const [mode, setMode] = useState<DnaSimMode>('normal');
  const current = DNA_SIM_DATA[mode];

  return (
    <div className="rounded-2xl border border-emerald-200 bg-white p-4 sm:p-5">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-bold text-emerald-950 sm:text-base">
            Simulator Mutasi Titik DNA → mRNA → Protein
          </h4>
          <p className="text-xs text-slate-600">
            Ketuk salah satu jenis mutasi untuk mengamati perubahan kodon dan asam amino.
          </p>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {(Object.keys(DNA_SIM_DATA) as DnaSimMode[]).map((key) => {
          const active = mode === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => setMode(key)}
              className={`min-h-[44px] rounded-xl px-3 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors sm:text-sm ${
                active
                  ? 'bg-emerald-900 text-white'
                  : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-emerald-50'
              }`}
            >
              {DNA_SIM_DATA[key].label}
            </button>
          );
        })}
      </div>

      <div>
        <svg
          viewBox="0 0 600 185"
          className="h-auto w-full"
          role="img"
          aria-label={`Visualisasi ${current.label}`}
        >
          <rect x="0" y="0" width="600" height="185" rx="14" fill="#F8FAF9" />
          <text x="18" y="34" fontSize="12" fontWeight="700" fill="#14532D">
            DNA 3&apos;-5&apos;
          </text>
          <text x="18" y="92" fontSize="12" fontWeight="700" fill="#0F766E">
            mRNA 5&apos;-3&apos;
          </text>
          <text x="18" y="150" fontSize="12" fontWeight="700" fill="#C2410C">
            Asam Amino
          </text>

          {[0, 1, 2].map((idx) => {
            const x = 120 + idx * 155;
            const isChanged = current.changedIndex === idx;
            const boxFill = isChanged ? '#FFF7ED' : '#FFFFFF';
            const boxStroke = isChanged ? '#F97316' : '#CBD5E1';

            return (
              <g key={idx}>
                <rect
                  x={x}
                  y="14"
                  width="130"
                  height="32"
                  rx="8"
                  fill={boxFill}
                  stroke={boxStroke}
                  strokeWidth={isChanged ? 2 : 1.5}
                />
                <text
                  x={x + 65}
                  y="35"
                  textAnchor="middle"
                  fontSize="15"
                  fontFamily="monospace"
                  fontWeight="700"
                  fill={isChanged ? '#C2410C' : '#0F172A'}
                >
                  {current.dnaCodons[idx]}
                </text>

                <line x1={x + 65} y1="46" x2={x + 65} y2="70" stroke="#94A3B8" strokeWidth="1.5" />
                <polygon points={`${x + 61},66 ${x + 69},66 ${x + 65},72`} fill="#94A3B8" />

                <rect
                  x={x}
                  y="72"
                  width="130"
                  height="32"
                  rx="8"
                  fill={isChanged ? '#FFF7ED' : '#ECFDF5'}
                  stroke={isChanged ? '#F97316' : '#86EFAC'}
                  strokeWidth={isChanged ? 2 : 1.5}
                />
                <text
                  x={x + 65}
                  y="93"
                  textAnchor="middle"
                  fontSize="15"
                  fontFamily="monospace"
                  fontWeight="700"
                  fill={isChanged ? '#C2410C' : '#14532D'}
                >
                  {current.mrnaCodons[idx]}
                </text>

                <line x1={x + 65} y1="104" x2={x + 65} y2="128" stroke="#94A3B8" strokeWidth="1.5" />
                <polygon points={`${x + 61},124 ${x + 69},124 ${x + 65},130`} fill="#94A3B8" />

                <rect
                  x={x}
                  y="130"
                  width="130"
                  height="34"
                  rx="8"
                  fill={isChanged ? '#F97316' : '#14532D'}
                />
                <text
                  x={x + 65}
                  y="152"
                  textAnchor="middle"
                  fontSize="13"
                  fontWeight="700"
                  fill="#FFFFFF"
                >
                  {current.aminoAcids[idx]}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      <p className="mt-3 rounded-xl bg-emerald-50/80 p-3 text-sm leading-relaxed text-slate-700">
        {current.explanation}
      </p>
    </div>
  );
};

/* 2. Interactive Chromosome Structural Aberration Diagram */
type AberrationType = 'delesi' | 'duplikasi' | 'inversi' | 'translokasi';

const ABERRATION_INFO: Record<
  AberrationType,
  {
    title: string;
    before: string[];
    after: string[];
    note: string;
  }
> = {
  delesi: {
    title: 'Delesi (Hilangnya Segmen)',
    before: ['A', 'B', 'C', 'D', 'E', 'F'],
    after: ['A', 'B', 'E', 'F'],
    note: 'Segmen C–D patah dan hilang, sehingga kromosom menjadi lebih pendek dan kehilangan gen.',
  },
  duplikasi: {
    title: 'Duplikasi (Penggandaan Segmen)',
    before: ['A', 'B', 'C', 'D', 'E', 'F'],
    after: ['A', 'B', 'C', 'B', 'C', 'D', 'E', 'F'],
    note: 'Segmen B–C mengalami penggandaan berulang akibat pindah silang yang tidak seimbang.',
  },
  inversi: {
    title: 'Inversi (Pembalikan 180°)',
    before: ['A', 'B', 'C', 'D', 'E', 'F'],
    after: ['A', 'D', 'C', 'B', 'E', 'F'],
    note: 'Segmen B–C–D patah, berputar 180° menjadi D–C–B, lalu menyambung kembali (parasentrik/perisentrik).',
  },
  translokasi: {
    title: 'Translokasi (Pindah ke Non-Homolog)',
    before: ['A', 'B', 'C', 'D', 'E', 'F'],
    after: ['A', 'B', 'C', 'X', 'Y'],
    note: 'Segmen D–E–F berpindah ke kromosom non-homolog dan digantikan segmen X–Y dari kromosom lain.',
  },
};

export const ChromosomeAberrationDiagram: React.FC = () => {
  const [selected, setSelected] = useState<AberrationType>('delesi');
  const info = ABERRATION_INFO[selected];

  return (
    <div className="rounded-2xl border border-emerald-200 bg-white p-4 sm:p-5">
      <h4 className="mb-1 text-sm font-bold text-emerald-950 sm:text-base">
        Visualisasi Perubahan Struktur Kromosom
      </h4>
      <p className="mb-3 text-xs text-slate-600">
        Pilih tipe aberasi untuk membandingkan susunan gen sebelum dan sesudah mutasi.
      </p>

      <div className="mb-4 flex flex-wrap gap-2">
        {(Object.keys(ABERRATION_INFO) as AberrationType[]).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setSelected(key)}
            className={`min-h-[44px] rounded-xl px-3 py-2 text-xs font-semibold capitalize whitespace-nowrap shrink-0 transition-colors sm:text-sm ${
              selected === key
                ? 'bg-emerald-900 text-white'
                : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-emerald-50'
            }`}
          >
            {key}
          </button>
        ))}
      </div>

      <svg viewBox="0 0 600 135" className="h-auto w-full" role="img" aria-label={info.title}>
        <rect x="0" y="0" width="600" height="135" rx="14" fill="#F8FAF9" />
        <text x="16" y="38" fontSize="12" fontWeight="700" fill="#475569">
          Normal
        </text>
        <text x="16" y="98" fontSize="12" fontWeight="700" fill="#C2410C">
          Mutasi
        </text>

        {info.before.map((seg, i) => {
          const x = 100 + i * 54;
          return (
            <g key={`b-${i}`}>
              <rect
                x={x}
                y="18"
                width="48"
                height="30"
                rx="6"
                fill="#14532D"
              />
              <text x={x + 24} y="38" textAnchor="middle" fontSize="14" fontWeight="700" fill="#FFF">
                {seg}
              </text>
            </g>
          );
        })}

        {info.after.map((seg, i) => {
          const x = 100 + i * 54;
          const isForeign = seg === 'X' || seg === 'Y';
          const isAltered =
            isForeign ||
            (selected === 'inversi' && (seg === 'D' || seg === 'B')) ||
            (selected === 'duplikasi' && i >= 3 && i <= 4);
          return (
            <g key={`a-${i}`}>
              <rect
                x={x}
                y="78"
                width="48"
                height="30"
                rx="6"
                fill={isForeign ? '#F97316' : isAltered ? '#EA580C' : '#22C55E'}
              />
              <text x={x + 24} y="98" textAnchor="middle" fontSize="14" fontWeight="700" fill="#FFF">
                {seg}
              </text>
            </g>
          );
        })}
      </svg>

      <p className="mt-3 rounded-xl bg-emerald-50/80 p-3 text-sm leading-relaxed text-slate-700">
        <strong className="text-emerald-950">{info.title}: </strong>
        {info.note}
      </p>
    </div>
  );
};

/* 3. Interactive Watermelon Ploidy Diagram (Misi 1 & Material Chapter 4) */
export const WatermelonPloidyDiagram: React.FC = () => {
  const [stage, setStage] = useState<'2n' | '4n' | '3n'>('3n');

  const stages = {
    '2n': {
      title: 'Semangka Diploid Normal (2n)',
      gamete: 'Gamet (n)',
      seedStatus: 'Berbiji Normal (Fertil)',
      chromosomes: 2,
      color: '#22C55E',
      desc: 'Memiliki 2 set kromosom homolog. Saat meiosis, kromosom berpasangan sempurna sehingga menghasilkan biji hitam fertil.',
    },
    '4n': {
      title: 'Induk Tetraploid Induksi Kolkisin (4n)',
      gamete: 'Gamet (2n)',
      seedStatus: 'Berbiji (Induk Betina)',
      chromosomes: 4,
      color: '#0D9488',
      desc: 'Kolkisin menghambat benang spindel saat mitosis sehingga sel menggandakan kromosom dari 2n menjadi 4n.',
    },
    '3n': {
      title: 'Semangka Triploid Tanpa Biji (3n)',
      gamete: 'Meiosis Gagal (Steril)',
      seedStatus: 'Tanpa Biji (Partenokarpi / Mandul)',
      chromosomes: 3,
      color: '#F97316',
      desc: 'Hasil persilangan induk 4n (gamet 2n) × induk 2n (gamet n) menghasilkan 3n. Kromosom ganjil tidak dapat berpasangan merata saat meiosis sehingga biji tidak terbentuk.',
    },
  };

  const active = stages[stage];

  return (
    <div className="rounded-2xl border border-emerald-200 bg-white p-4 sm:p-5">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-bold text-emerald-950 sm:text-base">
            Laboratorium Ploidi: Perbandingan Sel Semangka 2n, 4n, dan 3n
          </h4>
          <p className="text-xs text-slate-600">
            Ketuk tiap tahap untuk melihat jumlah set kromosom dan kondisi biji buahnya.
          </p>
        </div>
      </div>

      <div className="mb-4 grid grid-cols-3 gap-2">
        {(['2n', '4n', '3n'] as const).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setStage(key)}
            className={`min-h-[44px] rounded-xl px-2 py-2 text-xs font-bold transition-colors sm:text-sm ${
              stage === key
                ? 'bg-emerald-900 text-white'
                : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-emerald-50'
            }`}
          >
            {key === '2n' ? 'Diploid (2n)' : key === '4n' ? 'Tetraploid (4n)' : 'Triploid (3n)'}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 items-center gap-4 rounded-xl bg-[#F8FAF9] p-4 sm:grid-cols-2">
        <svg viewBox="0 0 260 155" className="mx-auto h-auto w-full max-w-[260px]" role="img" aria-label={active.title}>
          {/* Cell Circle with Chromosome Sets */}
          <circle cx="70" cy="78" r="56" fill="#FFFFFF" stroke={active.color} strokeWidth="3" />
          <text x="70" y="148" textAnchor="middle" fontSize="11" fontWeight="700" fill="#334155">
            Set Kromosom ({stage})
          </text>
          {Array.from({ length: active.chromosomes }).map((_, i) => {
            const xOff = 42 + i * (active.chromosomes === 4 ? 17 : active.chromosomes === 3 ? 25 : 44);
            return (
              <g key={i}>
                <path
                  d={`M ${xOff} 52 Q ${xOff + 6} 78 ${xOff} 104`}
                  stroke={active.color}
                  strokeWidth="5"
                  strokeLinecap="round"
                  fill="none"
                />
                <path
                  d={`M ${xOff + 8} 52 Q ${xOff + 2} 78 ${xOff + 8} 104`}
                  stroke="#14532D"
                  strokeWidth="4"
                  strokeLinecap="round"
                  fill="none"
                />
              </g>
            );
          })}

          {/* Watermelon Slice */}
          <path d="M 145 96 A 52 52 0 0 0 245 96 Z" fill="#14532D" />
          <path d="M 152 96 A 45 45 0 0 0 238 96 Z" fill="#EF4444" />
          {stage !== '3n' && (
            <g fill="#1E293B">
              <ellipse cx="175" cy="112" rx="2.5" ry="4" />
              <ellipse cx="195" cy="122" rx="2.5" ry="4" />
              <ellipse cx="215" cy="112" rx="2.5" ry="4" />
              <ellipse cx="186" cy="108" rx="2.5" ry="4" />
              <ellipse cx="205" cy="108" rx="2.5" ry="4" />
            </g>
          )}
          {stage === '3n' && (
            <g fill="#FEF2F2" opacity="0.65">
              <circle cx="182" cy="112" r="1.5" />
              <circle cx="206" cy="115" r="1.5" />
            </g>
          )}
          <text x="195" y="148" textAnchor="middle" fontSize="11" fontWeight="700" fill="#334155">
            {stage === '3n' ? 'Tanpa Biji' : 'Berbiji'}
          </text>
        </svg>

        <div className="space-y-2">
          <div className="text-base font-bold text-emerald-950">{active.title}</div>
          <div className="text-xs font-medium text-slate-600">
            Status Gamet: <span className="font-semibold text-slate-900">{active.gamete}</span>
          </div>
          <div className="text-xs font-medium text-slate-600">
            Karakter Buah: <span className="font-semibold text-orange-700">{active.seedStatus}</span>
          </div>
          <p className="text-sm leading-relaxed text-slate-700">{active.desc}</p>
        </div>
      </div>
    </div>
  );
};

/* 4. Interactive Karyotype Explorer (Misi 3) */
type KaryotypeCaseId = 'normal' | 'down' | 'turner' | 'klinefelter' | 'triploid';

const KARYOTYPE_CASES: Record<
  KaryotypeCaseId,
  {
    label: string;
    formula: string;
    totalChromosomes: string;
    organism: string;
    mechanism: string;
    impact: string;
    highlightPair: number;
    pairCount: number;
  }
> = {
  normal: {
    label: 'Normal (2n)',
    formula: '46, XX atau 46, XY',
    totalChromosomes: '46 kromosom (23 pasang)',
    organism: 'Manusia (Normal)',
    mechanism: 'Meiosis berjalan seimbang; setiap pasangan homolog berpisah normal.',
    impact: 'Ekspresi genetik seimbang, perkembangan fisik dan fertilitas normal.',
    highlightPair: -1,
    pairCount: 2,
  },
  down: {
    label: 'Sindrom Down',
    formula: '47, XX/XY + 21 (Trisomi 21)',
    totalChromosomes: '47 kromosom (2n + 1)',
    organism: 'Manusia (Aneuploidi Autosom)',
    mechanism: 'Nondisjunction pada kromosom nomor 21 saat meiosis sehingga sel memiliki 3 salinan kromosom 21.',
    impact: 'Ciri fisik khas, keterlambatan perkembangan kognitif, dan risiko kelainan jantung bawaan.',
    highlightPair: 20,
    pairCount: 3,
  },
  turner: {
    label: 'Sindrom Turner',
    formula: '45, XO (Monosomi X)',
    totalChromosomes: '45 kromosom (2n − 1)',
    organism: 'Manusia (Aneuploidi Gonosom)',
    mechanism: 'Gagal berpisah menyebabkan zigot hanya mewarisi satu kromosom seks X tanpa Y atau X kedua.',
    impact: 'Perempuan bertubuh pendek, ovarium tidak berkembang optimal (steril), dan ciri seks sekunder terhambat.',
    highlightPair: 22,
    pairCount: 1,
  },
  klinefelter: {
    label: 'Sindrom Klinefelter',
    formula: '47, XXY (Trisomi Gonosom)',
    totalChromosomes: '47 kromosom (2n + 1)',
    organism: 'Manusia (Aneuploidi Gonosom)',
    mechanism: 'Kelebihan satu kromosom X pada individu laki-laki akibat nondisjunction gamet.',
    impact: 'Laki-laki bertubuh tinggi, testis kecil (infertilitas), dan kecenderungan ginekomastia.',
    highlightPair: 22,
    pairCount: 3,
  },
  triploid: {
    label: 'Tanaman Triploid (3n)',
    formula: '3n (Euploidi / Poliploidi)',
    totalChromosomes: '3 set lengkap genom (3n)',
    organism: 'Tumbuhan (Semangka / Pisang)',
    mechanism: 'Persilangan individu 4n dengan 2n menghasilkan 3 set kromosom lengkap pada setiap pasangan.',
    impact: 'Tumbuhan tetap hidup subur secara vegetatif dengan buah besar, namun steril/tanpa biji.',
    highlightPair: 99,
    pairCount: 3,
  },
};

export const KaryotypeExplorer: React.FC = () => {
  const [caseId, setCaseId] = useState<KaryotypeCaseId>('down');
  const current = KARYOTYPE_CASES[caseId];

  return (
    <div className="rounded-2xl border border-emerald-200 bg-white p-4 sm:p-5">
      <h4 className="mb-1 text-sm font-bold text-emerald-950 sm:text-base">
        Pembanding Kariotipe & Jumlah Kromosom
      </h4>
      <p className="mb-3 text-xs text-slate-600">
        Pilih kasus kariotipe untuk melihat letak kelainan jumlah kromosom dan dampaknya.
      </p>

      <div className="mb-4 flex flex-wrap gap-2">
        {(Object.keys(KARYOTYPE_CASES) as KaryotypeCaseId[]).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setCaseId(key)}
            className={`min-h-[44px] rounded-xl px-3 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors sm:text-sm ${
              caseId === key
                ? 'bg-emerald-900 text-white'
                : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-emerald-50'
            }`}
          >
            {KARYOTYPE_CASES[key].label}
          </button>
        ))}
      </div>

      <div className="rounded-xl bg-[#F8FAF9] p-4">
        {/* Stylized representative chromosome pairs: Pasangan 1, 5, 21, dan Gonosom (23) */}
        <svg viewBox="0 0 540 120" className="mb-3 h-auto w-full" role="img" aria-label={current.label}>
          <rect x="0" y="0" width="540" height="120" rx="12" fill="#FFFFFF" stroke="#E2E8F0" />
          {[
            { label: 'Pasangan 1', idx: 0 },
            { label: 'Pasangan 5', idx: 4 },
            { label: 'Pasangan 18', idx: 17 },
            { label: 'Kromosom 21', idx: 20 },
            { label: 'Gonosom (23)', idx: 22 },
          ].map((slot, sIdx) => {
            const cx = 56 + sIdx * 105;
            const isTarget =
              current.highlightPair === 99 || current.highlightPair === slot.idx;
            const count = isTarget ? current.pairCount : 2;
            const barColor = isTarget ? '#F97316' : '#14532D';

            return (
              <g key={slot.label}>
                {isTarget && (
                  <rect
                    x={cx - 34}
                    y="12"
                    width="68"
                    height="72"
                    rx="10"
                    fill="#FFF7ED"
                    stroke="#F97316"
                    strokeDasharray="4 2"
                  />
                )}
                {Array.from({ length: count }).map((_, k) => {
                  const xPos = cx - (count - 1) * 7 + k * 14;
                  return (
                    <rect
                      key={k}
                      x={xPos - 3}
                      y="24"
                      width="6"
                      height="46"
                      rx="3"
                      fill={barColor}
                    />
                  );
                })}
                <text x={cx} y="102" textAnchor="middle" fontSize="10" fontWeight="600" fill="#475569">
                  {slot.label}
                </text>
              </g>
            );
          })}
        </svg>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <div className="text-xs font-medium text-slate-500">Formula & Jumlah</div>
            <div className="font-mono text-sm font-bold text-emerald-950">{current.formula}</div>
            <div className="text-xs font-semibold text-orange-700">{current.totalChromosomes}</div>
          </div>
          <div>
            <div className="text-xs font-medium text-slate-500">Kategori Organisme</div>
            <div className="text-sm font-semibold text-slate-900">{current.organism}</div>
          </div>
          <div className="sm:col-span-2">
            <div className="text-xs font-medium text-slate-500">Mekanisme & Dampak</div>
            <p className="text-sm leading-relaxed text-slate-700">
              {current.mechanism} {current.impact}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
