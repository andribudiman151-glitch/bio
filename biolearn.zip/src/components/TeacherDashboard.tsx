import React, { useMemo, useState } from 'react';
import {
  BarChart3,
  Users,
  Settings,
  Download,
  LogOut,
  Dna,
  X,
  Plus,
  Trash2,
  CheckCircle2,
  FileSpreadsheet,
  FileText,
  RefreshCw,
  Edit3,
  Trophy,
} from 'lucide-react';
import { useBiolearn } from '../context/BiolearnContext';
import {
  buildExportRows,
  exportRowsToCsv,
  exportRowsToExcel,
  exportRowsToPdf,
  type ExportFilterOptions,
} from '../utils/exportData';
import type { MissionId, StudentRecord } from '../types/biolearn';
import { LeaderboardView } from './LeaderboardView';

type TeacherTab = 'overview' | 'students' | 'leaderboard' | 'settings' | 'export';

export const TeacherDashboard: React.FC = () => {
  const {
    db,
    session,
    allStudentStats,
    allRankedStudents,
    logout,
    overrideStudentGrade,
    updateSettings,
    addClassRoom,
    deleteClassRoom,
    deleteStudent,
    updateQuestion,
    loadDemoData,
    resetDemoData,
  } = useBiolearn();

  const [tab, setTab] = useState<TeacherTab>('overview');
  const [filterClassId, setFilterClassId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Student Detail & Manual Override Modal
  const [selectedStudent, setSelectedStudent] = useState<StudentRecord | null>(null);
  const [overrideScores, setOverrideScores] = useState<Record<MissionId, string>>({
    'misi-1': '',
    'misi-2': '',
    'misi-3': '',
  });
  const [overrideComments, setOverrideComments] = useState<Record<MissionId, string>>({
    'misi-1': '',
    'misi-2': '',
    'misi-3': '',
  });

  // Settings local states
  const [newClassName, setNewClassName] = useState('');
  const [settingsNotice, setSettingsNotice] = useState<string | null>(null);
  const [settingsError, setSettingsError] = useState<string | null>(null);

  // Export states
  const [exportFilter, setExportFilter] = useState<ExportFilterOptions>({
    mode: 'all',
    classId: db?.classes[0]?.id,
    studentId: db?.students[0]?.id,
    statusFilter: 'completed',
  });

  if (!db || session.role !== 'teacher') return null;

  const summary = useMemo(() => {
    const total = db.students.length;
    let completedAll = 0;
    let inProgress = 0;
    let notStarted = 0;
    let activeCount = 0;
    let sumAvgScore = 0;
    let scoredCount = 0;

    const brackets = [
      { label: '< 60', count: 0 },
      { label: '60–69', count: 0 },
      { label: '70–79', count: 0 },
      { label: '80–89', count: 0 },
      { label: '90–100', count: 0 },
    ];

    for (const stu of db.students) {
      const st = allStudentStats.get(stu.id);
      if (!st) continue;
      if (st.completedMissionsCount === 3) {
        completedAll += 1;
      } else if (st.completedMissionsCount > 0 || stu.readChapters.length > 0) {
        inProgress += 1;
      } else {
        notStarted += 1;
      }

      if (st.completedMissionsCount > 0 || stu.readChapters.length > 0) {
        activeCount += 1;
      }

      if (st.completedMissionsCount > 0) {
        sumAvgScore += st.averageAccuracyScore;
        scoredCount += 1;
        const sc = st.averageAccuracyScore;
        if (sc < 60) brackets[0].count += 1;
        else if (sc < 70) brackets[1].count += 1;
        else if (sc < 80) brackets[2].count += 1;
        else if (sc < 90) brackets[3].count += 1;
        else brackets[4].count += 1;
      }
    }

    const avgScore = scoredCount > 0 ? Math.round((sumAvgScore / scoredCount) * 10) / 10 : 0;
    const maxBracket = Math.max(1, ...brackets.map((b) => b.count));

    return {
      total,
      activeCount,
      completedAll,
      inProgress,
      notStarted,
      avgScore,
      brackets,
      maxBracket,
    };
  }, [db.students, allStudentStats]);

  const filteredLeaderboard = useMemo(() => {
    return allRankedStudents.filter((entry) => {
      if (filterClassId !== 'all' && entry.student.classId !== filterClassId) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        return (
          entry.student.fullName.toLowerCase().includes(q) ||
          entry.student.nimDisplay.toLowerCase().includes(q) ||
          entry.student.className.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [allRankedStudents, filterClassId, searchQuery]);

  const openStudentModal = (student: StudentRecord) => {
    setSelectedStudent(student);
    const nextScores: Record<MissionId, string> = { 'misi-1': '', 'misi-2': '', 'misi-3': '' };
    const nextComments: Record<MissionId, string> = { 'misi-1': '', 'misi-2': '', 'misi-3': '' };
    for (const mId of ['misi-1', 'misi-2', 'misi-3'] as MissionId[]) {
      const g = db.grading_results.find(
        (x) => x.studentId === student.id && x.missionId === mId,
      );
      if (g) {
        nextScores[mId] = String(g.finalScore);
        nextComments[mId] = g.teacherComment;
      }
    }
    setOverrideScores(nextScores);
    setOverrideComments(nextComments);
  };

  const handleSaveOverride = (missionId: MissionId) => {
    if (!selectedStudent) return;
    const num = Number(overrideScores[missionId]);
    if (Number.isNaN(num) || num < 0 || num > 100) return;
    overrideStudentGrade({
      studentId: selectedStudent.id,
      missionId,
      score: num,
      comment: overrideComments[missionId],
    });
    setSettingsNotice(`Nilai ${missionId.toUpperCase()} untuk ${selectedStudent.fullName} berhasil diperbarui.`);
  };

  const exportRows = useMemo(
    () => buildExportRows(db, allRankedStudents, exportFilter),
    [db, allRankedStudents, exportFilter],
  );

  const navTabs: Array<{ id: TeacherTab; label: string; icon: React.ReactNode }> = [
    { id: 'overview', label: 'Ringkasan', icon: <BarChart3 className="h-4 w-4" aria-hidden="true" /> },
    { id: 'students', label: 'Data Siswa', icon: <Users className="h-4 w-4" aria-hidden="true" /> },
    { id: 'leaderboard', label: 'Leaderboard', icon: <Trophy className="h-4 w-4" aria-hidden="true" /> },
    { id: 'settings', label: 'Pengaturan', icon: <Settings className="h-4 w-4" aria-hidden="true" /> },
    { id: 'export', label: 'Ekspor Hasil', icon: <Download className="h-4 w-4" aria-hidden="true" /> },
  ];

  const bracketColors = [
    'bg-red-500',
    'bg-orange-500',
    'bg-amber-500',
    'bg-emerald-500',
    'bg-emerald-700',
  ];

  return (
    <div className="min-h-[100dvh] w-full overflow-x-hidden bg-gradient-to-b from-emerald-50/70 via-[#F4FAF6] to-slate-50 text-slate-900">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 border-b border-emerald-200 bg-white/95 backdrop-blur-md">
        <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-900 text-white">
          <div className="mx-auto flex h-[56px] max-w-7xl items-center justify-between gap-3 px-4 sm:px-6">
            <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-500 text-white">
                <Dna className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <div className="font-display text-base font-extrabold">
                  BIOLEARN Admin
                </div>
                <div className="text-[11px] font-medium text-emerald-200">{session.email}</div>
              </div>
            </div>

            <button
              type="button"
              onClick={logout}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-white/25 bg-white/10 px-3.5 py-2 text-xs font-bold text-white hover:bg-red-500/80 whitespace-nowrap shrink-0"
            >
              <LogOut className="h-4 w-4" aria-hidden="true" />
              <span>Keluar</span>
            </button>
          </div>
        </div>

        {/* Sub-Nav Bar (scrollable on mobile) */}
        <div className="border-t border-emerald-100 bg-white">
          <div className="mx-auto flex max-w-7xl gap-1.5 overflow-x-auto px-4 py-2 sm:px-6">
            {navTabs.map((item) => {
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setSettingsNotice(null);
                    setSettingsError(null);
                    setTab(item.id);
                  }}
                  className={`flex min-h-[44px] items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold whitespace-nowrap shrink-0 transition-colors sm:text-sm ${
                    active
                      ? 'bg-emerald-900 text-white shadow-sm'
                      : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-900'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {settingsNotice && (
          <div
            role="status"
            className="mb-5 flex items-center justify-between gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 p-3.5 text-sm font-semibold text-emerald-900"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" aria-hidden="true" />
              <span>{settingsNotice}</span>
            </div>
            <button
              type="button"
              aria-label="Tutup notifikasi"
              onClick={() => setSettingsNotice(null)}
              className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg hover:bg-emerald-100"
            >
              <X className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        )}

        {settingsError && (
          <div
            role="alert"
            className="mb-5 rounded-2xl border border-red-200 bg-red-50 p-3.5 text-sm font-semibold text-red-800"
          >
            {settingsError}
          </div>
        )}

        {/* TAB 1: OVERVIEW & DISTRIBUTION CHART */}
        {tab === 'overview' && (
          <div className="space-y-6">
            <section className="grid grid-cols-2 gap-3 lg:grid-cols-5">
              <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
                <div className="text-xs font-semibold text-slate-600">Total Siswa</div>
                <div className="mt-1 font-display text-2xl font-extrabold text-emerald-950 tabular-nums">
                  {summary.total}
                </div>
              </div>
              <div className="rounded-2xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-white p-4 shadow-sm">
                <div className="text-xs font-semibold text-emerald-900">Siswa Aktif</div>
                <div className="mt-1 font-display text-2xl font-extrabold text-emerald-700 tabular-nums">
                  {summary.activeCount}
                </div>
              </div>
              <div className="rounded-2xl border border-teal-200 bg-gradient-to-br from-teal-50 to-white p-4 shadow-sm">
                <div className="text-xs font-semibold text-teal-900">Tuntas 3 Misi</div>
                <div className="mt-1 font-display text-2xl font-extrabold text-teal-800 tabular-nums">
                  {summary.completedAll}
                </div>
              </div>
              <div className="rounded-2xl border border-orange-200 bg-gradient-to-br from-orange-50 to-white p-4 shadow-sm">
                <div className="text-xs font-semibold text-orange-900">Belum Mengerjakan</div>
                <div className="mt-1 font-display text-2xl font-extrabold text-orange-600 tabular-nums">
                  {summary.notStarted}
                </div>
              </div>
              <div className="col-span-2 rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50 to-white p-4 shadow-sm lg:col-span-1">
                <div className="text-xs font-semibold text-amber-900">Rata-rata Nilai</div>
                <div className="mt-1 font-display text-2xl font-extrabold text-amber-950 tabular-nums">
                  {summary.avgScore}
                </div>
              </div>
            </section>

            {/* Score Distribution Bar Chart */}
            <section className="rounded-3xl border border-emerald-200 bg-white p-5 shadow-sm sm:p-6">
              <h2 className="font-display text-lg font-bold text-emerald-950">
                Distribusi Nilai Rata-rata Siswa
              </h2>
              <p className="mt-0.5 text-xs text-slate-600">
                Grafik sebaran nilai ketepatan jawaban LKPD pada seluruh kelas.
              </p>

              <div className="mt-6 grid grid-cols-5 items-end gap-3 h-48 border-b border-slate-200 pb-2">
                {summary.brackets.map((b, bIdx) => {
                  const pct = Math.round((b.count / summary.maxBracket) * 100);
                  return (
                    <div key={b.label} className="flex h-full flex-col items-center justify-end gap-2">
                      <span className="font-mono text-xs font-bold text-emerald-950 tabular-nums">
                        {b.count}
                      </span>
                      <div className="w-full max-w-[56px] flex-1 flex items-end">
                        <div
                          className={`w-full rounded-t-xl ${bracketColors[bIdx]} transition-all duration-300`}
                          style={{ height: `${Math.max(8, pct)}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-2 grid grid-cols-5 gap-3 text-center">
                {summary.brackets.map((b) => (
                  <div key={b.label} className="font-mono text-xs font-semibold text-slate-600">
                    {b.label}
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {/* TAB 2: STUDENT MANAGEMENT TABLE */}
        {tab === 'students' && (
          <div className="space-y-4">
            <section className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 sm:flex-row sm:items-center sm:justify-between">
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari nama siswa atau NIM..."
                aria-label="Cari siswa"
                className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3.5 py-2 text-base sm:max-w-xs"
              />
              <select
                value={filterClassId}
                onChange={(e) => setFilterClassId(e.target.value)}
                aria-label="Filter kelas"
                className="min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-base sm:w-52"
              >
                <option value="all">Semua Kelas</option>
                {db.classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </section>

            <section className="rounded-3xl border border-slate-200 bg-white overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[760px] text-left text-sm">
                  <thead className="border-b border-slate-200 bg-slate-50 text-xs font-bold text-slate-600">
                    <tr>
                      <th className="px-4 py-3.5">No</th>
                      <th className="px-4 py-3.5">Nama</th>
                      <th className="px-4 py-3.5">NIM (Tersamar)</th>
                      <th className="px-4 py-3.5">Kelas</th>
                      <th className="px-4 py-3.5">Progres</th>
                      <th className="px-4 py-3.5">Nilai</th>
                      <th className="px-4 py-3.5">Poin</th>
                      <th className="px-4 py-3.5">Peringkat</th>
                      <th className="px-4 py-3.5 text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredLeaderboard.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="px-4 py-8 text-center text-sm text-slate-500">
                          Tidak ada data siswa yang cocok dengan filter.
                        </td>
                      </tr>
                    ) : (
                      filteredLeaderboard.map((entry, idx) => (
                        <tr key={entry.student.id} className="hover:bg-slate-50/70">
                          <td className="px-4 py-3 font-mono text-xs text-slate-500 tabular-nums">
                            {idx + 1}
                          </td>
                          <td className="px-4 py-3 font-semibold text-emerald-950">
                            {entry.student.fullName}
                            {entry.student.isDemo && (
                              <span className="ml-2 text-[11px] font-medium text-orange-600">
                                (Demo)
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 font-mono text-xs text-slate-600 tabular-nums">
                            {entry.student.nimDisplay}
                          </td>
                          <td className="px-4 py-3 text-slate-700">{entry.student.className}</td>
                          <td className="px-4 py-3 font-mono text-xs font-semibold text-emerald-800 tabular-nums">
                            {entry.stats.completedMissionsCount}/3 Misi ({entry.stats.progressPercent}%)
                          </td>
                          <td className="px-4 py-3 font-mono font-bold text-slate-900 tabular-nums">
                            {entry.stats.averageAccuracyScore}
                          </td>
                          <td className="px-4 py-3 font-mono font-bold text-emerald-900 tabular-nums">
                            {entry.stats.totalPoints}
                          </td>
                          <td className="px-4 py-3 font-mono font-bold text-orange-600 tabular-nums">
                            #{entry.rank}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="inline-flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => openStudentModal(entry.student)}
                                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-emerald-900 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-800 whitespace-nowrap"
                              >
                                <Edit3 className="h-3.5 w-3.5" aria-hidden="true" />
                                <span>Detail &amp; Koreksi</span>
                              </button>
                              <button
                                type="button"
                                aria-label={`Hapus ${entry.student.fullName}`}
                                onClick={() => deleteStudent(entry.student.id)}
                                className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl border border-slate-200 text-slate-500 hover:bg-red-50 hover:text-red-700"
                              >
                                <Trash2 className="h-4 w-4" aria-hidden="true" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        )}

        {/* TAB 3: LEADERBOARD */}
        {tab === 'leaderboard' && <LeaderboardView />}

        {/* TAB 4: SETTINGS & CONTENT MANAGEMENT */}
        {tab === 'settings' && (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            {/* Timer & Visibility Settings */}
            <section className="rounded-3xl border border-slate-200 bg-white p-5 space-y-4">
              <h2 className="font-display text-lg font-bold text-emerald-950">
                Pengaturan Timer &amp; Leaderboard
              </h2>

              <label className="flex min-h-[44px] items-center justify-between gap-3 rounded-2xl border border-slate-200 p-3.5 cursor-pointer">
                <span className="text-sm font-semibold text-slate-800">Aktifkan Timer LKPD</span>
                <input
                  type="checkbox"
                  checked={db.settings.timerEnabled}
                  onChange={(e) => updateSettings({ timerEnabled: e.target.checked })}
                  className="h-5 w-5 accent-emerald-800"
                />
              </label>

              <div>
                <label htmlFor="timer-dur" className="mb-1 block text-sm font-semibold text-slate-800">
                  Durasi Pengerjaan (Menit)
                </label>
                <input
                  id="timer-dur"
                  type="number"
                  min={1}
                  max={180}
                  value={db.settings.timerDurationMinutes}
                  onChange={(e) =>
                    updateSettings({
                      timerDurationMinutes: Math.max(1, Number(e.target.value) || 10),
                    })
                  }
                  className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3.5 py-2 text-base"
                />
              </div>

              <label className="flex min-h-[44px] items-center justify-between gap-3 rounded-2xl border border-slate-200 p-3.5 cursor-pointer">
                <span className="text-sm font-semibold text-slate-800">
                  Kunci Otomatis Jika Waktu Habis
                </span>
                <input
                  type="checkbox"
                  checked={db.settings.lockOnTimeExpired}
                  onChange={(e) => updateSettings({ lockOnTimeExpired: e.target.checked })}
                  className="h-5 w-5 accent-emerald-800"
                />
              </label>

              <label className="flex min-h-[44px] items-center justify-between gap-3 rounded-2xl border border-slate-200 p-3.5 cursor-pointer">
                <span className="text-sm font-semibold text-slate-800">
                  Tampilkan Leaderboard ke Siswa
                </span>
                <input
                  type="checkbox"
                  checked={db.settings.leaderboardVisible}
                  onChange={(e) => updateSettings({ leaderboardVisible: e.target.checked })}
                  className="h-5 w-5 accent-emerald-800"
                />
              </label>
            </section>

            {/* Point Weights */}
            <section className="rounded-3xl border border-slate-200 bg-white p-5 space-y-4">
              <h2 className="font-display text-lg font-bold text-emerald-950">
                Bobot Poin Penilaian
              </h2>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Misi 1 Ketepatan
                  </label>
                  <input
                    type="number"
                    value={db.settings.pointWeights.mission1Accuracy}
                    onChange={(e) =>
                      updateSettings({
                        pointWeights: {
                          ...db.settings.pointWeights,
                          mission1Accuracy: Number(e.target.value) || 0,
                        },
                      })
                    }
                    className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-2 text-base"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Misi 1 Penyelesaian
                  </label>
                  <input
                    type="number"
                    value={db.settings.pointWeights.mission1Completion}
                    onChange={(e) =>
                      updateSettings({
                        pointWeights: {
                          ...db.settings.pointWeights,
                          mission1Completion: Number(e.target.value) || 0,
                        },
                      })
                    }
                    className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-2 text-base"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Misi 2 Ketepatan
                  </label>
                  <input
                    type="number"
                    value={db.settings.pointWeights.mission2Accuracy}
                    onChange={(e) =>
                      updateSettings({
                        pointWeights: {
                          ...db.settings.pointWeights,
                          mission2Accuracy: Number(e.target.value) || 0,
                        },
                      })
                    }
                    className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-2 text-base"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Misi 2 Penyelesaian
                  </label>
                  <input
                    type="number"
                    value={db.settings.pointWeights.mission2Completion}
                    onChange={(e) =>
                      updateSettings({
                        pointWeights: {
                          ...db.settings.pointWeights,
                          mission2Completion: Number(e.target.value) || 0,
                        },
                      })
                    }
                    className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-2 text-base"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Misi 3 Ketepatan
                  </label>
                  <input
                    type="number"
                    value={db.settings.pointWeights.mission3Accuracy}
                    onChange={(e) =>
                      updateSettings({
                        pointWeights: {
                          ...db.settings.pointWeights,
                          mission3Accuracy: Number(e.target.value) || 0,
                        },
                      })
                    }
                    className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-2 text-base"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-semibold text-slate-700">
                    Misi 3 Penyelesaian
                  </label>
                  <input
                    type="number"
                    value={db.settings.pointWeights.mission3Completion}
                    onChange={(e) =>
                      updateSettings({
                        pointWeights: {
                          ...db.settings.pointWeights,
                          mission3Completion: Number(e.target.value) || 0,
                        },
                      })
                    }
                    className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-2 text-base"
                  />
                </div>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-slate-700">
                  Keaktifan (Materi + Refleksi)
                </label>
                <input
                  type="number"
                  value={db.settings.pointWeights.activityMax}
                  onChange={(e) =>
                    updateSettings({
                      pointWeights: {
                        ...db.settings.pointWeights,
                        activityMax: Number(e.target.value) || 0,
                      },
                    })
                  }
                  className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-2 text-base"
                />
              </div>
            </section>

            {/* Class Management */}
            <section className="rounded-3xl border border-slate-200 bg-white p-5 space-y-4">
              <h2 className="font-display text-lg font-bold text-emerald-950">Kelola Daftar Kelas</h2>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  placeholder="Contoh: XII IPA 4"
                  className="min-h-[44px] flex-1 rounded-xl border border-slate-300 px-3.5 py-2 text-base"
                />
                <button
                  type="button"
                  onClick={() => {
                    setSettingsError(null);
                    const res = addClassRoom(newClassName);
                    if (!res.ok) {
                      setSettingsError(res.error ?? 'Gagal menambah kelas.');
                    } else {
                      setNewClassName('');
                      setSettingsNotice('Kelas baru berhasil ditambahkan.');
                    }
                  }}
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl bg-emerald-900 px-4 py-2 text-sm font-bold text-white hover:bg-emerald-800 shrink-0"
                >
                  <Plus className="h-4 w-4" aria-hidden="true" />
                  <span>Tambah</span>
                </button>
              </div>
              <div className="divide-y divide-slate-100">
                {db.classes.map((cls) => (
                  <div key={cls.id} className="flex items-center justify-between py-2.5">
                    <span className="text-sm font-semibold text-slate-800">{cls.name}</span>
                    <button
                      type="button"
                      aria-label={`Hapus kelas ${cls.name}`}
                      onClick={() => {
                        setSettingsError(null);
                        const res = deleteClassRoom(cls.id);
                        if (!res.ok) setSettingsError(res.error ?? 'Gagal menghapus kelas.');
                      }}
                      className="flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </div>
                ))}
              </div>
            </section>

            {/* Demo Data Controls */}
            <section className="rounded-3xl border border-slate-200 bg-white p-5 space-y-4">
              <h2 className="font-display text-lg font-bold text-emerald-950">
                Data Uji &amp; Simulasi Kelas
              </h2>
              <p className="text-sm leading-relaxed text-slate-600">
                Tombol ini hanya menambah atau menghapus data siswa demo untuk keperluan simulasi.
                Data akun dan jawaban siswa asli tidak akan terhapus.
              </p>
              <div className="flex flex-col gap-2.5 sm:flex-row">
                <button
                  type="button"
                  onClick={async () => {
                    await loadDemoData();
                    setSettingsNotice('Data demo siswa berhasil dimuat ulang.');
                  }}
                  className="flex min-h-[46px] flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-900 px-4 py-2.5 text-sm font-bold text-white hover:bg-emerald-800"
                >
                  <RefreshCw className="h-4 w-4" aria-hidden="true" />
                  <span>Muat Data Demo</span>
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    await resetDemoData();
                    setSettingsNotice('Data uji demo berhasil dibersihkan (siswa asli tetap aman).');
                  }}
                  className="flex min-h-[46px] flex-1 items-center justify-center gap-2 rounded-xl border border-red-300 bg-red-50 px-4 py-2.5 text-sm font-bold text-red-800 hover:bg-red-100"
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" />
                  <span>Reset Data Uji</span>
                </button>
              </div>
            </section>

            {/* Questions & Answer Key Editor (Pilihan Ganda) */}
            <section className="rounded-3xl border border-slate-200 bg-white p-5 space-y-4 lg:col-span-2">
              <h2 className="font-display text-lg font-bold text-emerald-950">
                Editor Soal Pilihan Ganda &amp; Kunci Jawaban LKPD
              </h2>
              <div className="space-y-4">
                {db.assignments.map((mission) => {
                  const qs = db.questions
                    .filter((q) => q.missionId === mission.id)
                    .sort((a, b) => a.order - b.order);
                  return (
                    <div key={mission.id} className="rounded-2xl border border-slate-200 p-4 space-y-4">
                      <div className="font-display text-base font-bold text-emerald-950">
                        {mission.title}
                      </div>
                      <div className="space-y-4">
                        {qs.map((q) => (
                          <div
                            key={q.id}
                            className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 space-y-2.5"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <label className="text-xs font-bold text-emerald-900">
                                Soal Pilihan Ganda {q.order}
                              </label>
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-semibold text-slate-600">Kunci:</span>
                                <select
                                  value={q.correctOptionId}
                                  onChange={(e) =>
                                    updateQuestion({ ...q, correctOptionId: e.target.value })
                                  }
                                  className="min-h-[36px] rounded-lg border border-emerald-300 bg-white px-2.5 py-1 text-xs font-bold text-emerald-950"
                                >
                                  {(q.options ?? []).map((opt) => (
                                    <option key={opt.id} value={opt.id}>
                                      {opt.id}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            <input
                              type="text"
                              value={q.prompt}
                              onChange={(e) => updateQuestion({ ...q, prompt: e.target.value })}
                              className="min-h-[44px] w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-base"
                            />

                            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                              {(q.options ?? []).map((opt) => (
                                <div key={opt.id} className="flex items-center gap-2">
                                  <span
                                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg font-mono text-xs font-bold ${
                                      opt.id === q.correctOptionId
                                        ? 'bg-emerald-700 text-white'
                                        : 'bg-slate-200 text-slate-700'
                                    }`}
                                  >
                                    {opt.id}
                                  </span>
                                  <input
                                    type="text"
                                    value={opt.text}
                                    onChange={(e) =>
                                      updateQuestion({
                                        ...q,
                                        options: q.options.map((o) =>
                                          o.id === opt.id ? { ...o, text: e.target.value } : o,
                                        ),
                                      })
                                    }
                                    className="min-h-[40px] w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-sm"
                                  />
                                </div>
                              ))}
                            </div>

                            <div>
                              <label className="mb-1 block text-xs font-semibold text-slate-600">
                                Pembahasan Singkat
                              </label>
                              <input
                                type="text"
                                value={q.explanation}
                                onChange={(e) =>
                                  updateQuestion({ ...q, explanation: e.target.value })
                                }
                                className="min-h-[40px] w-full rounded-xl border border-slate-300 bg-white px-3 py-1.5 text-sm"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          </div>
        )}

        {/* TAB 5: EXPORT CENTER */}
        {tab === 'export' && (
          <section className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-7 space-y-5">
            <div>
              <h2 className="font-display text-lg font-extrabold text-emerald-950">
                Ekspor Hasil Pembelajaran &amp; LKPD
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Unduh rekap lengkap berisi Nama, NIM, Kelas, Jawaban &amp; Nilai Misi 1–3, Refleksi,
                Total Nilai, Poin, Peringkat, Badge, Waktu, Umpan Balik AI, dan Komentar Guru.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-slate-800">
                  Filter Data Ekspor
                </label>
                <select
                  value={exportFilter.mode}
                  onChange={(e) =>
                    setExportFilter((prev) => ({
                      ...prev,
                      mode: e.target.value as ExportFilterOptions['mode'],
                    }))
                  }
                  className="min-h-[46px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-base"
                >
                  <option value="all">Semua Data Siswa</option>
                  <option value="class">Per Kelas</option>
                  <option value="student">Siswa Tertentu</option>
                  <option value="status">Berdasarkan Status Pengerjaan</option>
                </select>
              </div>

              {exportFilter.mode === 'class' && (
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-800">
                    Pilih Kelas
                  </label>
                  <select
                    value={exportFilter.classId ?? ''}
                    onChange={(e) =>
                      setExportFilter((prev) => ({ ...prev, classId: e.target.value }))
                    }
                    className="min-h-[46px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-base"
                  >
                    {db.classes.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {exportFilter.mode === 'student' && (
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-800">
                    Pilih Siswa
                  </label>
                  <select
                    value={exportFilter.studentId ?? ''}
                    onChange={(e) =>
                      setExportFilter((prev) => ({ ...prev, studentId: e.target.value }))
                    }
                    className="min-h-[46px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-base"
                  >
                    {db.students.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.fullName} ({s.className})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {exportFilter.mode === 'status' && (
                <div>
                  <label className="mb-1.5 block text-sm font-semibold text-slate-800">
                    Status Pengerjaan
                  </label>
                  <select
                    value={exportFilter.statusFilter ?? 'completed'}
                    onChange={(e) =>
                      setExportFilter((prev) => ({
                        ...prev,
                        statusFilter: e.target.value as ExportFilterOptions['statusFilter'],
                      }))
                    }
                    className="min-h-[46px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-base"
                  >
                    <option value="completed">Sudah Tuntas (3 Misi + Refleksi)</option>
                    <option value="in-progress">Sedang Mengerjakan</option>
                    <option value="not-started">Belum Mengerjakan</option>
                  </select>
                </div>
              )}
            </div>

            <div className="rounded-2xl bg-[#F8FAF9] p-4 text-sm font-semibold text-slate-700 tabular-nums">
              Jumlah baris siap ekspor: {exportRows.length} siswa
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <button
                type="button"
                disabled={exportRows.length === 0}
                onClick={() => exportRowsToExcel(exportRows)}
                className="flex min-h-[50px] items-center justify-center gap-2 rounded-2xl bg-emerald-900 px-4 py-3 text-sm font-bold text-white hover:bg-emerald-800 disabled:opacity-40"
              >
                <FileSpreadsheet className="h-5 w-5" aria-hidden="true" />
                <span>Ekspor Excel (.xlsx)</span>
              </button>

              <button
                type="button"
                disabled={exportRows.length === 0}
                onClick={() => exportRowsToPdf(exportRows)}
                className="flex min-h-[50px] items-center justify-center gap-2 rounded-2xl bg-orange-500 px-4 py-3 text-sm font-bold text-white hover:bg-orange-600 disabled:opacity-40"
              >
                <FileText className="h-5 w-5" aria-hidden="true" />
                <span>Ekspor PDF (.pdf)</span>
              </button>

              <button
                type="button"
                disabled={exportRows.length === 0}
                onClick={() => exportRowsToCsv(exportRows)}
                className="flex min-h-[50px] items-center justify-center gap-2 rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm font-bold text-slate-800 hover:bg-slate-50 disabled:opacity-40"
              >
                <Download className="h-5 w-5" aria-hidden="true" />
                <span>Ekspor CSV (.csv)</span>
              </button>
            </div>
          </section>
        )}
      </main>

      {/* STUDENT DETAIL & MANUAL OVERRIDE MODAL */}
      {selectedStudent && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`Detail jawaban ${selectedStudent.fullName}`}
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 backdrop-blur-sm sm:items-center sm:p-4"
        >
          <div className="max-h-[90dvh] w-full max-w-3xl overflow-y-auto rounded-t-3xl bg-white p-5 shadow-xl sm:rounded-3xl sm:p-6">
            <div className="flex items-start justify-between gap-3 border-b border-slate-200 pb-4">
              <div>
                <h2 className="font-display text-lg font-extrabold text-emerald-950">
                  {selectedStudent.fullName}
                </h2>
                <p className="text-xs text-slate-500 font-mono">
                  {selectedStudent.className} · NIM {selectedStudent.nimDisplay}
                </p>
              </div>
              <button
                type="button"
                aria-label="Tutup modal detail"
                onClick={() => setSelectedStudent(null)}
                className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            <div className="mt-4 space-y-5">
              {(['misi-1', 'misi-2', 'misi-3'] as MissionId[]).map((mId) => {
                const mission = db.assignments.find((m) => m.id === mId);
                const ans = db.student_answers.find(
                  (a) => a.studentId === selectedStudent.id && a.missionId === mId,
                );
                const grade = db.grading_results.find(
                  (g) => g.studentId === selectedStudent.id && g.missionId === mId,
                );
                const questions = db.questions.filter((q) => q.missionId === mId);

                return (
                  <div key={mId} className="rounded-2xl border border-slate-200 p-4 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="font-display text-sm font-extrabold text-emerald-950">
                        {mission?.title}
                      </h3>
                      <span className="font-mono text-xs font-bold text-emerald-800 tabular-nums">
                        Nilai Final: {grade?.finalScore ?? '-'} / 100
                      </span>
                    </div>

                    {ans ? (
                      <div className="space-y-2 text-xs text-slate-700">
                        {mId === 'misi-2' && typeof ans.sortingScore === 'number' && (
                          <div className="rounded-lg bg-emerald-50 p-2 font-semibold text-emerald-900">
                            Skor Pengelompokan Kartu: {ans.sortingScore}%
                          </div>
                        )}
                        {questions.map((q) => {
                          const chosenId = ans.answers[q.id] ?? '';
                          const chosenOpt = q.options?.find((o) => o.id === chosenId);
                          const isCorrect =
                            chosenId.toUpperCase() === (q.correctOptionId ?? '').toUpperCase();
                          return (
                            <div key={q.id} className="rounded-xl bg-slate-50 p-2.5">
                              <div className="flex items-start justify-between gap-2">
                                <div className="font-bold text-slate-800">
                                  {q.order}. {q.prompt}
                                </div>
                                {q.correctOptionId && (
                                  <span
                                    className={`shrink-0 rounded px-1.5 py-0.5 font-mono text-[11px] font-bold ${
                                      isCorrect
                                        ? 'bg-emerald-100 text-emerald-900'
                                        : 'bg-red-100 text-red-800'
                                    }`}
                                  >
                                    {isCorrect ? 'Benar ✓' : `Salah (Kunci ${q.correctOptionId})`}
                                  </span>
                                )}
                              </div>
                              <p className="mt-1 text-sm text-slate-700">
                                {chosenOpt
                                  ? `${chosenOpt.id}. ${chosenOpt.text}`
                                  : chosenId || '(Kosong)'}
                              </p>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500">Siswa belum mengerjakan misi ini.</p>
                    )}

                    {grade && (
                      <div className="rounded-xl bg-emerald-50/70 p-3 text-xs text-slate-700 space-y-1">
                        <div className="font-bold text-emerald-950">
                          Hasil Evaluasi Otomatis ({grade.aiScore}/100):
                        </div>
                        <p>Benar: {grade.aiFeedback.correctConcepts}</p>
                        <p>Perlu Ditinjau: {grade.aiFeedback.needsImprovement}</p>
                      </div>
                    )}

                    {/* Teacher Manual Override Controls */}
                    <div className="grid grid-cols-1 gap-2.5 border-t border-slate-100 pt-3 sm:grid-cols-12 sm:items-end">
                      <div className="sm:col-span-3">
                        <label className="mb-1 block text-xs font-bold text-slate-700">
                          Nilai Guru (0–100)
                        </label>
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={overrideScores[mId]}
                          onChange={(e) =>
                            setOverrideScores((prev) => ({ ...prev, [mId]: e.target.value }))
                          }
                          className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-1.5 text-base"
                        />
                      </div>
                      <div className="sm:col-span-6">
                        <label className="mb-1 block text-xs font-bold text-slate-700">
                          Komentar Resmi Guru
                        </label>
                        <input
                          type="text"
                          value={overrideComments[mId]}
                          onChange={(e) =>
                            setOverrideComments((prev) => ({ ...prev, [mId]: e.target.value }))
                          }
                          placeholder="Tambahkan catatan koreksi..."
                          className="min-h-[44px] w-full rounded-xl border border-slate-300 px-3 py-1.5 text-base"
                        />
                      </div>
                      <div className="sm:col-span-3">
                        <button
                          type="button"
                          onClick={() => handleSaveOverride(mId)}
                          className="min-h-[44px] w-full rounded-xl bg-orange-500 px-3 py-2 text-xs font-bold text-white hover:bg-orange-600"
                        >
                          Simpan Koreksi
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Reflection Display */}
              {(() => {
                const ref = db.reflections.find((r) => r.studentId === selectedStudent.id);
                return (
                  <div className="rounded-2xl border border-slate-200 p-4 space-y-2">
                    <h3 className="font-display text-sm font-extrabold text-emerald-950">
                      Refleksi Pembelajaran
                    </h3>
                    {ref ? (
                      <div className="space-y-2 text-sm text-slate-700">
                        <p>
                          <strong>Hal Baru:</strong> {ref.newThingLearned}
                        </p>
                        <p>
                          <strong>Pertanyaan Penasaran:</strong> {ref.curiousQuestion}
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs text-slate-500">Siswa belum mengisi refleksi.</p>
                    )}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
