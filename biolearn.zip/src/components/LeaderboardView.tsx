import React from 'react';
import { Trophy, Medal, EyeOff, Award, ClipboardList, Sparkles } from 'lucide-react';
import { useBiolearn } from '../context/BiolearnContext';
import { ConfettiBurst } from './ConfettiBurst';

export const LeaderboardView: React.FC = () => {
  const {
    db,
    activeStudent,
    leaderboard,
    setRoute,
    lkpdCompletedCelebration,
    justFinishedLkpd,
    clearLkpdCelebrationBurst,
  } = useBiolearn();
  if (!db) return null;

  if (!db.settings.leaderboardVisible) {
    return (
      <>
        <ConfettiBurst
          triggerKey={lkpdCompletedCelebration}
          onComplete={clearLkpdCelebrationBurst}
        />
        <section className="rounded-3xl border border-slate-200 bg-white p-8 text-center">
          <EyeOff className="mx-auto mb-3 h-10 w-10 text-slate-400" aria-hidden="true" />
          <h1 className="font-display text-lg font-bold text-emerald-950">
            Leaderboard Sedang Disembunyikan
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Guru menonaktifkan tampilan peringkat untuk sementara waktu.
          </p>
        </section>
      </>
    );
  }

  const top10 = leaderboard.slice(0, 10);
  const top3 = top10.slice(0, 3);
  const rest = top10.slice(3);
  const myEntry = activeStudent
    ? leaderboard.find((e) => e.student.id === activeStudent.id)
    : undefined;

  const formatDuration = (secs: number) => {
    if (!Number.isFinite(secs) || secs > 86400) return '—';
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s}d`;
  };

  const podiumOrder =
    top3.length >= 3
      ? [
          { entry: top3[1], place: 2 },
          { entry: top3[0], place: 1 },
          { entry: top3[2], place: 3 },
        ]
      : top3.map((entry, idx) => ({ entry, place: idx + 1 }));

  return (
    <div className="space-y-6">
      <ConfettiBurst
        triggerKey={lkpdCompletedCelebration}
        onComplete={clearLkpdCelebrationBurst}
      />

      {justFinishedLkpd && activeStudent && (
        <div
          role="status"
          className="flex items-start gap-3 rounded-2xl border border-emerald-300 bg-gradient-to-r from-emerald-50 via-teal-50 to-amber-50 p-4 text-emerald-950 shadow-sm"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-white">
            <Sparkles className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <div className="font-display text-sm font-extrabold sm:text-base">
              Selamat, {activeStudent.fullName}! Pengerjaan LKPD Selesai
            </div>
            <p className="mt-0.5 text-xs text-emerald-800 sm:text-sm">
              Kamu langsung diarahkan ke halaman Peringkat untuk melihat posisi dan skor akhirmu.
            </p>
          </div>
        </div>
      )}

      <section className="rounded-3xl border border-emerald-900/15 bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-800 p-5 text-white sm:p-7">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-orange-500 text-white shrink-0">
            <Trophy className="h-6 w-6" aria-hidden="true" />
          </div>
          <div>
            <h1 className="font-display text-xl font-extrabold sm:text-2xl">
              TOP 10 DETEKTIF BIOLOGI
            </h1>
            <p className="text-xs text-emerald-100 sm:text-sm">
              Berdasarkan data nyata siswa yang telah mengerjakan dan mengumpulkan misi LKPD
            </p>
          </div>
        </div>

        {/* Empty state when no real student has completed any mission yet */}
        {top10.length === 0 ? (
          <div className="mt-6 rounded-2xl border border-white/15 bg-white/10 p-6 text-center">
            <ClipboardList className="mx-auto mb-2.5 h-8 w-8 text-orange-300" aria-hidden="true" />
            <h2 className="font-display text-base font-bold text-white">
              Belum Ada Siswa yang Mengumpulkan Misi
            </h2>
            <p className="mt-1 text-xs text-emerald-100 sm:text-sm">
              Peringkat hanya menampilkan peserta lapangan yang sudah menyelesaikan minimal Misi 1.
            </p>
            {activeStudent && (
              <button
                type="button"
                onClick={() => setRoute('student-lkpd')}
                className="mt-4 inline-flex min-h-[44px] items-center justify-center rounded-xl bg-orange-500 px-5 py-2 text-sm font-bold text-white hover:bg-orange-600"
              >
                Kerjakan Misi 1 Sekarang
              </button>
            )}
          </div>
        ) : (
          <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3 sm:items-end">
            {podiumOrder.map(({ entry, place }) => {
              const isFirst = place === 1;
              const isMe = activeStudent?.id === entry.student.id;
              return (
                <div
                  key={entry.student.id}
                  className={`rounded-2xl border p-4 text-center transition-all ${
                    isFirst
                      ? 'border-orange-400 bg-white text-slate-900 sm:pb-7'
                      : 'border-white/20 bg-white/10 text-white'
                  } ${isMe ? 'ring-2 ring-orange-400' : ''}`}
                >
                  <div className="mb-2 flex items-center justify-center gap-1.5">
                    <Medal
                      className={`h-5 w-5 ${
                        place === 1
                          ? 'text-orange-500'
                          : place === 2
                            ? 'text-slate-200'
                            : 'text-amber-300'
                      }`}
                      aria-hidden="true"
                    />
                    <span className="font-display text-sm font-extrabold">Juara {place}</span>
                  </div>
                  <div className="truncate font-display text-base font-extrabold">
                    {entry.student.fullName}
                  </div>
                  <div
                    className={`text-xs ${
                      isFirst ? 'text-slate-500' : 'text-emerald-200'
                    }`}
                  >
                    {entry.student.className}
                  </div>
                  <div className="mt-2 font-mono text-2xl font-extrabold tabular-nums">
                    {entry.stats.totalPoints}
                    <span className="ml-1 text-xs font-medium">poin</span>
                  </div>
                  <div
                    className={`mt-1 text-[11px] tabular-nums ${
                      isFirst ? 'text-slate-500' : 'text-emerald-100'
                    }`}
                  >
                    Nilai {entry.stats.averageAccuracyScore} · {entry.badges.length} Badge
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Personal Rank Card */}
      {activeStudent && (
        <section className="rounded-2xl border-2 border-orange-300 bg-orange-50/70 p-4">
          {myEntry ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-orange-800">Posisi Peringkatmu Saat Ini</div>
                <div className="font-display text-base font-extrabold text-emerald-950">
                  #{myEntry.rank} · {myEntry.student.fullName} ({myEntry.student.className})
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono text-xl font-extrabold text-emerald-950 tabular-nums">
                  {myEntry.stats.totalPoints} Poin
                </div>
                <div className="text-xs text-slate-600 tabular-nums">
                  {myEntry.badges.length}/6 Badge · Nilai {myEntry.stats.averageAccuracyScore}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-orange-800">Status Peringkatmu</div>
                <div className="text-sm font-semibold text-emerald-950">
                  Selesaikan minimal Misi 1 agar namamu masuk ke daftar peringkat real kelas.
                </div>
              </div>
              <button
                type="button"
                onClick={() => setRoute('student-lkpd')}
                className="min-h-[44px] rounded-xl bg-emerald-900 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-800"
              >
                Buka LKPD
              </button>
            </div>
          )}
        </section>
      )}

      {/* Ranks 4–10 */}
      {rest.length > 0 && (
        <section className="rounded-3xl border border-slate-200 bg-white p-4 sm:p-6">
          <h2 className="mb-3 font-display text-base font-bold text-emerald-950">
            Peringkat 4 – 10
          </h2>
          <div className="divide-y divide-slate-100">
            {rest.map((entry) => {
              const isMe = activeStudent?.id === entry.student.id;
              return (
                <div
                  key={entry.student.id}
                  className={`flex items-center justify-between gap-3 py-3 px-2 rounded-xl ${
                    isMe ? 'bg-emerald-50' : ''
                  }`}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-100 font-mono text-sm font-bold text-slate-700 tabular-nums">
                      #{entry.rank}
                    </span>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold text-emerald-950">
                        {entry.student.fullName}
                        {isMe ? ' (Kamu)' : ''}
                      </div>
                      <div className="text-xs text-slate-500">
                        {entry.student.className} · Waktu {formatDuration(entry.stats.completionDurationSeconds)}
                      </div>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono text-sm font-extrabold text-emerald-900 tabular-nums">
                      {entry.stats.totalPoints} Poin
                    </div>
                    <div className="inline-flex items-center gap-1 text-xs text-slate-500 tabular-nums">
                      <Award className="h-3 w-3 text-orange-500" aria-hidden="true" />
                      {entry.badges.length} Badge
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
};
