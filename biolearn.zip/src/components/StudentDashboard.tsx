import React, { useState } from 'react';
import {
  Play,
  CheckCircle2,
  Clock,
  Lock,
  Trophy,
  Award,
  Search,
  Dna,
  Layers,
  Sparkles,
  BookOpen,
  ArrowRight,
  Medal,
  HelpCircle,
} from 'lucide-react';
import { useBiolearn } from '../context/BiolearnContext';
import { DetectiveGuideModal } from './DetectiveGuideModal';
import type { MissionId } from '../types/biolearn';

function BadgeIcon({ iconKey, unlocked }: { iconKey: string; unlocked: boolean }) {
  const cls = `h-6 w-6 ${unlocked ? 'text-orange-600' : 'text-slate-400'}`;
  switch (iconKey) {
    case 'search':
      return <Search className={cls} aria-hidden="true" />;
    case 'dna':
      return <Dna className={cls} aria-hidden="true" />;
    case 'layers':
      return <Layers className={cls} aria-hidden="true" />;
    case 'award':
      return <Award className={cls} aria-hidden="true" />;
    case 'sparkles':
      return <Sparkles className={cls} aria-hidden="true" />;
    default:
      return <Trophy className={cls} aria-hidden="true" />;
  }
}

export const StudentDashboard: React.FC<{
  onOpenMission: (missionTab: MissionId | 'refleksi') => void;
}> = ({ onOpenMission }) => {
  const { db, activeStudent, activeStudentStats, leaderboard, setRoute } = useBiolearn();
  const [guideOpen, setGuideOpen] = useState(false);
  if (!db || !activeStudent || !activeStudentStats) return null;

  const myRank = leaderboard.find((e) => e.student.id === activeStudent.id)?.rank ?? null;

  const getMissionStatus = (missionId: MissionId, prevMissionDone: boolean) => {
    const ans = db.student_answers.find(
      (a) => a.studentId === activeStudent.id && a.missionId === missionId,
    );
    const grade = db.grading_results.find(
      (g) => g.studentId === activeStudent.id && g.missionId === missionId,
    );
    if (ans?.status === 'graded' || ans?.status === 'submitted') {
      return { state: 'Selesai' as const, score: grade?.finalScore ?? null };
    }
    if (ans?.status === 'draft') {
      return { state: 'Sedang Dikerjakan' as const, score: null };
    }
    if (missionId === 'misi-1' || prevMissionDone) {
      return { state: 'Siap Dikerjakan' as const, score: null };
    }
    return { state: 'Terkunci' as const, score: null };
  };

  const m1Status = getMissionStatus('misi-1', true);
  const m2Status = getMissionStatus('misi-2', m1Status.state === 'Selesai');
  const m3Status = getMissionStatus('misi-3', m2Status.state === 'Selesai');
  const all3Done =
    m1Status.state === 'Selesai' && m2Status.state === 'Selesai' && m3Status.state === 'Selesai';
  const refStatus = activeStudentStats.hasReflection
    ? 'Selesai'
    : all3Done
      ? 'Siap Dikerjakan'
      : 'Terkunci';

  const handlePrimaryStart = () => {
    if (!activeStudentStats.hasCompletedAllMaterials) {
      setRoute('student-material');
      return;
    }
    if (m1Status.state !== 'Selesai') {
      onOpenMission('misi-1');
    } else if (m2Status.state !== 'Selesai') {
      onOpenMission('misi-2');
    } else if (m3Status.state !== 'Selesai') {
      onOpenMission('misi-3');
    } else {
      onOpenMission('refleksi');
    }
    setRoute('student-lkpd');
  };

  const missionCards: Array<{
    id: MissionId;
    title: string;
    subtitle: string;
    status: ReturnType<typeof getMissionStatus>;
  }> = [
    {
      id: 'misi-1',
      title: db.assignments[0]?.title ?? 'Misi 1: Rahasia Semangka Tanpa Biji',
      subtitle: db.assignments[0]?.mainQuestion ?? '',
      status: m1Status,
    },
    {
      id: 'misi-2',
      title: db.assignments[1]?.title ?? 'Misi 2: Kode Genetik',
      subtitle: db.assignments[1]?.mainQuestion ?? '',
      status: m2Status,
    },
    {
      id: 'misi-3',
      title: db.assignments[2]?.title ?? 'Misi 3: Misteri Jumlah Kromosom',
      subtitle: db.assignments[2]?.mainQuestion ?? '',
      status: m3Status,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Personal Greeting & Primary CTA */}
      <section className="rounded-3xl border border-emerald-900/15 bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-800 p-5 text-white shadow-sm sm:p-7">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="space-y-2">
            <p className="text-xs font-semibold text-emerald-200">
              {activeStudent.className} · Detektif Biologi Mutasi
            </p>
            <h1 className="font-display text-2xl font-extrabold tracking-tight sm:text-3xl">
              Halo, {activeStudent.fullName}!
            </h1>
            <p className="max-w-xl text-sm leading-relaxed text-emerald-100">
              Jelajahi konsep Mutasi Gen &amp; Kromosom, selesaikan 3 misi investigasi LKPD, dan
              kumpulkan poin serta badge terbaikmu.
            </p>
          </div>

          <div className="flex flex-col gap-2.5 lg:shrink-0">
            <button
              type="button"
              onClick={handlePrimaryStart}
              className="flex min-h-[48px] items-center justify-center gap-2 rounded-2xl bg-orange-500 px-5 py-3 text-sm font-bold text-white whitespace-nowrap shadow-sm transition-colors hover:bg-orange-600 sm:text-base"
            >
              <Play className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>
                {activeStudentStats.progressPercent > 0
                  ? 'Lanjutkan Pembelajaran'
                  : 'Mulai Pembelajaran'}
              </span>
            </button>
            <div className="grid grid-cols-2 gap-2.5 sm:flex sm:flex-wrap">
              <button
                type="button"
                onClick={() => setRoute('student-material')}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-2xl border border-emerald-300/40 bg-white/10 px-3.5 py-2.5 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-white/20 sm:px-4 sm:text-sm"
              >
                <BookOpen className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Materi ({activeStudent.readChapters.length}/4)</span>
              </button>
              <button
                type="button"
                onClick={() => setGuideOpen(true)}
                className="flex min-h-[46px] items-center justify-center gap-2 rounded-2xl border border-amber-300/45 bg-amber-400/15 px-3.5 py-2.5 text-xs font-semibold text-amber-100 whitespace-nowrap transition-colors hover:bg-amber-400/25 sm:px-4 sm:text-sm"
              >
                <HelpCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Panduan Misi</span>
              </button>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-5 rounded-2xl bg-black/20 p-3.5">
          <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-emerald-100">
            <span>Progres Penyelesaian Misi &amp; Refleksi</span>
            <span className="font-mono tabular-nums">{activeStudentStats.progressPercent}%</span>
          </div>
          <div className="h-2.5 w-full overflow-hidden rounded-full bg-white/20">
            <div
              className="h-full rounded-full bg-emerald-400 transition-all duration-300"
              style={{ width: `${activeStudentStats.progressPercent}%` }}
            />
          </div>
        </div>
      </section>

      {/* 4 Color-Coded Gamification Stat Cards */}
      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="rounded-2xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-white p-4 shadow-sm">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-emerald-900">Total Poin</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-600 text-white">
              <Trophy className="h-3.5 w-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-2 font-display text-2xl font-extrabold text-emerald-950 tabular-nums">
            {activeStudentStats.totalPoints}
            <span className="ml-1 text-xs font-medium text-emerald-700">/100</span>
          </div>
        </div>

        <div className="rounded-2xl border border-orange-200 bg-gradient-to-br from-orange-50 to-white p-4 shadow-sm">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-orange-900">Peringkat Kelas</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-orange-500 text-white">
              <Medal className="h-3.5 w-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-2 font-display text-2xl font-extrabold text-orange-700 tabular-nums">
            {myRank ? `#${myRank}` : '—'}
          </div>
          {!myRank && (
            <div className="mt-0.5 text-[11px] font-medium text-orange-800/80">
              Selesaikan Misi 1
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50 to-white p-4 shadow-sm">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-amber-900">Badge Diperoleh</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500 text-white">
              <Award className="h-3.5 w-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-2 font-display text-2xl font-extrabold text-amber-950 tabular-nums">
            {activeStudentStats.earnedBadgeIds.length}
            <span className="ml-1 text-xs font-medium text-amber-700">/6</span>
          </div>
        </div>

        <div className="rounded-2xl border border-teal-200 bg-gradient-to-br from-teal-50 to-white p-4 shadow-sm">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-teal-900">Rata-rata Nilai</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-600 text-white">
              <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
            </span>
          </div>
          <div className="mt-2 font-display text-2xl font-extrabold text-teal-950 tabular-nums">
            {activeStudentStats.averageAccuracyScore}
          </div>
        </div>
      </section>

      {/* 3 Missions + Reflection: Color-Coded by State */}
      <section className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-lg font-bold text-emerald-950">
            Daftar Misi Detektif &amp; Refleksi
          </h2>
          <div className="flex flex-wrap items-center gap-3 text-xs font-medium text-slate-600">
            <span className="text-orange-700">Oranye: Siap dikerjakan</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-700">Hijau: Selesai</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-500">Abu: Terkunci</span>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {missionCards.map((m) => {
            const isLocked = m.status.state === 'Terkunci';
            const isDone = m.status.state === 'Selesai';
            return (
              <button
                key={m.id}
                type="button"
                disabled={isLocked}
                onClick={() => {
                  onOpenMission(m.id);
                  setRoute('student-lkpd');
                }}
                className={`flex min-h-[92px] w-full items-center justify-between gap-4 rounded-2xl border p-4 text-left transition-all ${
                  isLocked
                    ? 'cursor-not-allowed border-slate-200 bg-slate-100/80 text-slate-500'
                    : isDone
                      ? 'border-emerald-300 bg-gradient-to-br from-emerald-50/90 to-white hover:border-emerald-500'
                      : 'border-orange-300 bg-gradient-to-br from-orange-50/90 to-white shadow-sm hover:border-orange-500'
                }`}
              >
                <div className="min-w-0 space-y-1">
                  <div
                    className={`font-display text-sm font-bold sm:text-base ${
                      isLocked ? 'text-slate-600' : 'text-emerald-950'
                    }`}
                  >
                    {m.title}
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2">{m.subtitle}</p>
                  <div className="flex items-center gap-2 pt-1 text-xs font-semibold">
                    {isDone ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700">
                        <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                        Selesai · Nilai {m.status.score ?? '-'} / 100
                      </span>
                    ) : isLocked ? (
                      <span className="inline-flex items-center gap-1 text-slate-500">
                        <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                        Terkunci (Selesaikan misi sebelumnya)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-orange-700">
                        <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                        {m.status.state}
                      </span>
                    )}
                  </div>
                </div>
                {!isLocked && (
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                      isDone
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-orange-500 text-white'
                    }`}
                  >
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </span>
                )}
              </button>
            );
          })}

          {/* Refleksi Card */}
          <button
            type="button"
            disabled={refStatus === 'Terkunci'}
            onClick={() => {
              onOpenMission('refleksi');
              setRoute('student-lkpd');
            }}
            className={`flex min-h-[92px] w-full items-center justify-between gap-4 rounded-2xl border p-4 text-left transition-all ${
              refStatus === 'Terkunci'
                ? 'cursor-not-allowed border-slate-200 bg-slate-100/80 text-slate-500'
                : refStatus === 'Selesai'
                  ? 'border-emerald-300 bg-gradient-to-br from-emerald-50/90 to-white hover:border-emerald-500'
                  : 'border-orange-300 bg-gradient-to-br from-orange-50/90 to-white shadow-sm hover:border-orange-500'
            }`}
          >
            <div className="min-w-0 space-y-1">
              <div
                className={`font-display text-sm font-bold sm:text-base ${
                  refStatus === 'Terkunci' ? 'text-slate-600' : 'text-emerald-950'
                }`}
              >
                Refleksi Pembelajaran Mutasi
              </div>
              <p className="text-xs text-slate-600">
                Catat hal baru yang dipelajari &amp; pertanyaan yang membuatmu penasaran.
              </p>
              <div className="flex items-center gap-2 pt-1 text-xs font-semibold">
                {refStatus === 'Selesai' ? (
                  <span className="inline-flex items-center gap-1 text-emerald-700">
                    <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                    Selesai
                  </span>
                ) : refStatus === 'Terkunci' ? (
                  <span className="inline-flex items-center gap-1 text-slate-500">
                    <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                    Terkunci (Selesaikan 3 misi terlebih dahulu)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-orange-700">
                    <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                    Siap Diisi
                  </span>
                )}
              </div>
            </div>
            {refStatus !== 'Terkunci' && (
              <span
                className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                  refStatus === 'Selesai'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-orange-500 text-white'
                }`}
              >
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </span>
            )}
          </button>
        </div>
      </section>

      {/* Badge Showcase */}
      <section className="space-y-3">
        <h2 className="font-display text-lg font-bold text-emerald-950">Koleksi Badge Detektif</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {db.badges.map((badge) => {
            const unlocked = activeStudentStats.earnedBadgeIds.includes(badge.id);
            return (
              <div
                key={badge.id}
                className={`flex items-start gap-3.5 rounded-2xl border p-4 ${
                  unlocked
                    ? 'border-amber-300 bg-gradient-to-br from-amber-50/80 via-white to-emerald-50/60 shadow-sm'
                    : 'border-slate-200 bg-slate-100/70 opacity-80'
                }`}
              >
                <div
                  className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl ${
                    unlocked ? 'bg-amber-100 border border-amber-200' : 'bg-slate-200/80'
                  }`}
                >
                  <BadgeIcon iconKey={badge.iconKey} unlocked={unlocked} />
                </div>
                <div className="min-w-0">
                  <div className="font-display text-sm font-bold text-emerald-950">
                    {badge.name}
                  </div>
                  <p className="mt-0.5 text-xs leading-relaxed text-slate-600">
                    {badge.description}
                  </p>
                  <p
                    className={`mt-1.5 text-xs font-semibold ${
                      unlocked ? 'text-emerald-700' : 'text-slate-500'
                    }`}
                  >
                    {unlocked ? 'Terbuka' : `Syarat: ${badge.requirement}`}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <DetectiveGuideModal
        open={guideOpen}
        onClose={() => setGuideOpen(false)}
        materialsCompleted={activeStudentStats.hasCompletedAllMaterials}
        onOpenMaterial={() => setRoute('student-material')}
        onStartLkpd={() => {
          if (m1Status.state !== 'Selesai') {
            onOpenMission('misi-1');
          } else if (m2Status.state !== 'Selesai') {
            onOpenMission('misi-2');
          } else if (m3Status.state !== 'Selesai') {
            onOpenMission('misi-3');
          } else {
            onOpenMission('refleksi');
          }
          setRoute('student-lkpd');
        }}
      />
    </div>
  );
};
