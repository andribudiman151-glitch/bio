import React, { useEffect, useState } from 'react';
import {
  X,
  Compass,
  BookOpen,
  Layers,
  Sparkles,
  Trophy,
  Clock,
  CheckSquare,
  ListChecks,
  ArrowRight,
  HelpCircle,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';

interface DetectiveGuideModalProps {
  open: boolean;
  onClose: () => void;
  onStartLkpd: () => void;
  materialsCompleted: boolean;
  onOpenMaterial: () => void;
}

type GuideTab = 'alur' | 'cara';

const FLOW_STEPS = [
  {
    step: '01',
    title: 'Pelajari Materi Mutasi',
    description:
      'Baca 4 bab ringkas dan jelajahi simulator interaktif DNA, semangka triploid, serta kariotipe di menu Materi.',
    accent: 'bg-emerald-100 text-emerald-900 border-emerald-200',
    icon: BookOpen,
  },
  {
    step: '02',
    title: 'Selesaikan Misi 1 → 2 → 3 Bertahap',
    description:
      'Misi dibuka berurutan. Tuntaskan Misi 1 untuk membuka Misi 2, lalu lanjut ke Misi 3 di halaman LKPD.',
    accent: 'bg-orange-100 text-orange-900 border-orange-200',
    icon: Layers,
  },
  {
    step: '03',
    title: 'Isi Refleksi & Cek Peringkat',
    description:
      'Setelah 3 misi tuntas, tulis refleksi singkat lalu klik Selesai & Lihat Peringkat untuk langsung menuju Leaderboard.',
    accent: 'bg-teal-100 text-teal-900 border-teal-200',
    icon: Sparkles,
  },
  {
    step: '04',
    title: 'Kumpulkan Poin & 6 Badge',
    description:
      'Ketepatan dan penyelesaian misi menghasilkan total maksimal 100 poin, membuka badge detektif, dan menentukan peringkatmu.',
    accent: 'bg-amber-100 text-amber-900 border-amber-200',
    icon: Trophy,
  },
];

const MISSION_TIPS = [
  {
    title: 'Timer 10 Menit Aktif di LKPD',
    detail:
      'Hitung mundur 10 menit mulai berjalan saat kamu masuk ke menu LKPD. Jika waktu habis, jawaban tersimpan otomatis dikirim.',
    icon: Clock,
    iconBg: 'bg-orange-500 text-white',
  },
  {
    title: 'Soal Pilihan Ganda (A–D)',
    detail:
      'Setiap misi berisi 4 soal pilihan ganda. Pilih opsi terbaik lalu tekan Kirim & Periksa untuk melihat nilai dan pembahasan.',
    icon: CheckSquare,
    iconBg: 'bg-emerald-700 text-white',
  },
  {
    title: 'Pengelompokan Konsep Misi 2',
    detail:
      'Pada Misi 2, kelompokkan seluruh 10 kartu ke kategori Mutasi Gen atau Mutasi Kromosom dengan tombol ketuk sebelum mengirim.',
    icon: ListChecks,
    iconBg: 'bg-teal-700 text-white',
  },
  {
    title: 'Simpan Otomatis & Bisa Diperbaiki',
    detail:
      'Pilihan jawaban tersimpan otomatis di perangkat. Selama waktu LKPD masih tersisa, kamu tetap dapat meninjau pembahasan misi.',
    icon: HelpCircle,
    iconBg: 'bg-slate-700 text-white',
  },
];

export const DetectiveGuideModal: React.FC<DetectiveGuideModalProps> = ({
  open,
  onClose,
  onStartLkpd,
  materialsCompleted,
  onOpenMaterial,
}) => {
  const [activeTab, setActiveTab] = useState<GuideTab>('alur');

  useEffect(() => {
    if (!open) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="detective-guide-title"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={onClose}
            className="fixed inset-0 bg-emerald-950/55 backdrop-blur-xs"
            aria-hidden="true"
          />

          {/* Modal Sheet / Dialog */}
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 18, scale: 0.98 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 flex max-h-[88dvh] w-full max-w-xl flex-col overflow-hidden rounded-t-3xl border border-emerald-200/80 bg-white shadow-2xl sm:rounded-3xl"
          >
            {/* Mobile drag handle indicator */}
            <div className="flex justify-center bg-emerald-950 pt-2.5 sm:hidden" aria-hidden="true">
              <span className="h-1 w-10 rounded-full bg-white/30" />
            </div>

            {/* Header */}
            <div className="flex items-start justify-between gap-3 bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-800 px-5 py-4 text-white sm:px-6 sm:py-5">
              <div className="flex items-center gap-3 min-w-0">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-orange-500 text-white shadow-sm">
                  <Compass className="h-5 w-5" aria-hidden="true" />
                </div>
                <div className="min-w-0">
                  <h2
                    id="detective-guide-title"
                    className="font-display text-lg font-extrabold leading-tight sm:text-xl"
                  >
                    Panduan Detektif BIOLEARN
                  </h2>
                  <p className="mt-0.5 text-xs text-emerald-100 sm:text-sm">
                    Alur permainan dan cara mengerjakan misi Mutasi
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Tutup panduan"
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/10 text-white transition-colors hover:bg-white/20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            {/* Segmented Tab Switcher */}
            <div className="border-b border-slate-200 bg-slate-50/90 px-4 py-3 sm:px-6">
              <div
                role="tablist"
                aria-label="Bagian panduan"
                className="grid grid-cols-2 gap-1.5 rounded-2xl bg-slate-200/75 p-1"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'alur'}
                  onClick={() => setActiveTab('alur')}
                  className={`min-h-[44px] rounded-xl px-3 py-2 text-xs font-bold whitespace-nowrap transition-all sm:text-sm ${
                    activeTab === 'alur'
                      ? 'bg-emerald-900 text-white shadow-sm'
                      : 'text-slate-700 hover:bg-white/60 hover:text-emerald-950'
                  }`}
                >
                  Alur Permainan
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'cara'}
                  onClick={() => setActiveTab('cara')}
                  className={`min-h-[44px] rounded-xl px-3 py-2 text-xs font-bold whitespace-nowrap transition-all sm:text-sm ${
                    activeTab === 'cara'
                      ? 'bg-emerald-900 text-white shadow-sm'
                      : 'text-slate-700 hover:bg-white/60 hover:text-emerald-950'
                  }`}
                >
                  Cara Mengerjakan
                </button>
              </div>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto px-4 py-4 sm:px-6 sm:py-5">
              {activeTab === 'alur' ? (
                <ol className="divide-y divide-slate-100">
                  {FLOW_STEPS.map((item) => {
                    const Icon = item.icon;
                    return (
                      <li key={item.step} className="flex items-start gap-3.5 py-3.5 first:pt-0 last:pb-0">
                        <div
                          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border font-mono text-xs font-extrabold tabular-nums ${item.accent}`}
                        >
                          {item.step}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <Icon className="h-4 w-4 shrink-0 text-emerald-800" aria-hidden="true" />
                            <h3 className="font-display text-sm font-bold text-emerald-950 sm:text-base">
                              {item.title}
                            </h3>
                          </div>
                          <p className="mt-1 text-xs leading-relaxed text-slate-600 sm:text-sm">
                            {item.description}
                          </p>
                        </div>
                      </li>
                    );
                  })}
                </ol>
              ) : (
                <div className="space-y-3">
                  {MISSION_TIPS.map((tip) => {
                    const Icon = tip.icon;
                    return (
                      <div
                        key={tip.title}
                        className="flex items-start gap-3.5 rounded-2xl bg-slate-50 p-3.5"
                      >
                        <span
                          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${tip.iconBg}`}
                        >
                          <Icon className="h-4 w-4" aria-hidden="true" />
                        </span>
                        <div className="min-w-0">
                          <h3 className="font-display text-sm font-bold text-emerald-950">
                            {tip.title}
                          </h3>
                          <p className="mt-0.5 text-xs leading-relaxed text-slate-600 sm:text-sm">
                            {tip.detail}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Footer Actions */}
            <div className="flex flex-col-reverse gap-2.5 border-t border-slate-200 bg-slate-50/80 px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
              <button
                type="button"
                onClick={onClose}
                className="flex min-h-[46px] items-center justify-center rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-bold text-slate-700 whitespace-nowrap transition-colors hover:bg-slate-100"
              >
                Tutup
              </button>

              <div className="flex flex-col gap-2 sm:flex-row">
                {!materialsCompleted && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenMaterial();
                    }}
                    className="flex min-h-[46px] items-center justify-center gap-1.5 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-2.5 text-sm font-bold text-emerald-900 whitespace-nowrap transition-colors hover:bg-emerald-100"
                  >
                    <BookOpen className="h-4 w-4 shrink-0" aria-hidden="true" />
                    <span>Baca Materi</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onStartLkpd();
                  }}
                  className="flex min-h-[46px] items-center justify-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-bold text-white whitespace-nowrap shadow-sm transition-colors hover:bg-orange-600"
                >
                  <span>Mulai Misi LKPD</span>
                  <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
