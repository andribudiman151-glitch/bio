import React, { useState } from 'react';
import { ArrowLeft, Dna, GraduationCap, ShieldCheck, AlertCircle } from 'lucide-react';
import { useBiolearn } from '../context/BiolearnContext';

export const StudentLoginView: React.FC = () => {
  const { db, setRoute, loginStudent } = useBiolearn();
  const [fullName, setFullName] = useState('');
  const [nim, setNim] = useState('');
  const [classId, setClassId] = useState(db?.classes[0]?.id ?? '');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const classes = db?.classes ?? [];
  const effectiveClassId = classId || classes[0]?.id || '';

  const handleNimChange = (val: string) => {
    setError(null);
    setNim(val);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const result = await loginStudent({
      fullName,
      nim,
      classId: effectiveClassId,
    });
    setSubmitting(false);
    if (!result.ok) {
      setError(result.error ?? 'Gagal masuk sebagai siswa.');
    }
  };

  return (
    <div className="min-h-[100dvh] w-full overflow-x-hidden bg-gradient-to-br from-emerald-50 via-[#F4FAF6] to-teal-50 px-4 py-6 flex flex-col justify-center">
      <div className="mx-auto w-full max-w-md">
        <button
          type="button"
          onClick={() => setRoute('landing')}
          className="mb-4 inline-flex min-h-[44px] items-center gap-2 rounded-xl px-2 text-sm font-semibold text-emerald-900 hover:text-emerald-700"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Kembali ke Beranda</span>
        </button>

        <div className="overflow-hidden rounded-3xl border border-emerald-200 bg-white shadow-sm">
          <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-700 p-5 text-white sm:px-7">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/15 text-white shrink-0">
                <GraduationCap className="h-6 w-6" aria-hidden="true" />
              </div>
              <div>
                <h1 className="font-display text-xl font-extrabold">
                  Masuk Detektif Siswa
                </h1>
                <p className="text-xs text-emerald-100">
                  BIOLEARN · Biologi Kelas XII (Mutasi)
                </p>
              </div>
            </div>
          </div>

          <div className="p-6 sm:p-7">

          {error && (
            <div
              role="alert"
              className="mb-4 flex items-start gap-2.5 rounded-2xl border border-red-200 bg-red-50 p-3.5 text-sm text-red-800"
            >
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="student-name" className="mb-1.5 block text-sm font-semibold text-slate-800">
                Nama Lengkap
              </label>
              <input
                id="student-name"
                type="text"
                required
                autoComplete="name"
                value={fullName}
                onChange={(e) => {
                  setError(null);
                  setFullName(e.target.value);
                }}
                placeholder="Contoh: Siti Rahmawati"
                className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-base text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="student-nim" className="text-sm font-semibold text-slate-800">
                  NIM / NIS (13 Digit Angka)
                </label>
                <span className="font-mono text-xs font-medium text-slate-500 tabular-nums">
                  {nim.trim().length}/13
                </span>
              </div>
              <input
                id="student-nim"
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={13}
                required
                value={nim}
                onChange={(e) => handleNimChange(e.target.value)}
                placeholder="Masukkan 13 digit angka NIM/NIS"
                className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 font-mono text-base tracking-wider text-slate-900 placeholder:font-sans placeholder:tracking-normal placeholder:text-slate-400 focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
              <p className="mt-1 text-xs text-slate-500">
                NIM/NIS di-hash otomatis (SHA-256) dan digunakan untuk memulihkan progres belajarmu.
              </p>
            </div>

            <div>
              <label htmlFor="student-class" className="mb-1.5 block text-sm font-semibold text-slate-800">
                Kelas
              </label>
              <select
                id="student-class"
                value={effectiveClassId}
                onChange={(e) => {
                  setError(null);
                  setClassId(e.target.value);
                }}
                className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-base text-slate-900 focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              >
                {classes.map((cls) => (
                  <option key={cls.id} value={cls.id}>
                    {cls.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="mt-2 flex min-h-[50px] w-full items-center justify-center gap-2 rounded-2xl bg-emerald-900 px-5 py-3 text-base font-bold text-white transition-colors hover:bg-emerald-800 disabled:opacity-60"
            >
              <Dna className="h-5 w-5" aria-hidden="true" />
              <span>{submitting ? 'Memverifikasi...' : 'Masuk & Mulai Belajar'}</span>
            </button>
          </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export const TeacherLoginView: React.FC = () => {
  const { setRoute, loginTeacher } = useBiolearn();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const res = await loginTeacher({ email, password });
    setSubmitting(false);
    if (!res.ok) {
      setError(res.error ?? 'Gagal masuk sebagai guru.');
    }
  };

  return (
    <div className="min-h-[100dvh] w-full overflow-x-hidden bg-gradient-to-br from-orange-50/80 via-[#FAF9F6] to-amber-50 px-4 py-6 flex flex-col justify-center">
      <div className="mx-auto w-full max-w-md">
        <button
          type="button"
          onClick={() => setRoute('landing')}
          className="mb-4 inline-flex min-h-[44px] items-center gap-2 rounded-xl px-2 text-sm font-semibold text-orange-900 hover:text-orange-700"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          <span>Kembali ke Beranda</span>
        </button>

        <div className="overflow-hidden rounded-3xl border border-orange-200 bg-white shadow-sm">
          <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 p-5 text-white sm:px-7">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/15 text-white shrink-0">
                <ShieldCheck className="h-6 w-6" aria-hidden="true" />
              </div>
              <div>
                <h1 className="font-display text-xl font-extrabold">
                  Portal Admin Guru
                </h1>
                <p className="text-xs text-orange-50">
                  Kelola kelas, koreksi jawaban, timer & ekspor hasil
                </p>
              </div>
            </div>
          </div>

          <div className="p-6 sm:p-7">

          {error && (
            <div
              role="alert"
              className="mb-4 flex items-start gap-2.5 rounded-2xl border border-red-200 bg-red-50 p-3.5 text-sm text-red-800"
            >
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" aria-hidden="true" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="teacher-email" className="mb-1.5 block text-sm font-semibold text-slate-800">
                Username Admin Guru
              </label>
              <input
                id="teacher-email"
                type="text"
                required
                autoComplete="username"
                value={email}
                onChange={(e) => {
                  setError(null);
                  setEmail(e.target.value);
                }}
                placeholder="guru123"
                className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-base text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div>
              <label htmlFor="teacher-password" className="mb-1.5 block text-sm font-semibold text-slate-800">
                Password
              </label>
              <input
                id="teacher-password"
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => {
                  setError(null);
                  setPassword(e.target.value);
                }}
                placeholder="Masukkan password guru"
                className="min-h-[48px] w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-base text-slate-900 placeholder:text-slate-400 focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="mt-2 flex min-h-[50px] w-full items-center justify-center gap-2 rounded-2xl bg-orange-600 px-5 py-3 text-base font-bold text-white transition-colors hover:bg-orange-700 disabled:opacity-60"
            >
              <ShieldCheck className="h-5 w-5" aria-hidden="true" />
              <span>{submitting ? 'Memeriksa...' : 'Masuk Dashboard Guru'}</span>
            </button>
          </form>
          </div>
        </div>
      </div>
    </div>
  );
};
