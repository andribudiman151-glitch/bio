import React, { useEffect, useRef } from 'react';

interface ConfettiBurstProps {
  /** Incrementing key (> 0) triggers a fresh celebratory confetti burst. */
  triggerKey: number;
  onComplete?: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  h: number;
  color: string;
  rotation: number;
  vr: number;
  tilt: number;
  vtilt: number;
  shape: 'rect' | 'circle';
  alpha: number;
}

const CONFETTI_COLORS = [
  '#10b981', // emerald-500
  '#059669', // emerald-600
  '#22c55e', // green-500
  '#f97316', // orange-500
  '#f59e0b', // amber-500
  '#facc15', // yellow-400
  '#14b8a6', // teal-500
];

export const ConfettiBurst: React.FC<ConfettiBurstProps> = ({ triggerKey, onComplete }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    if (triggerKey <= 0) return;

    if (
      typeof window !== 'undefined' &&
      window.matchMedia &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      const timer = window.setTimeout(() => {
        onCompleteRef.current?.();
      }, 400);
      return () => window.clearTimeout(timer);
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let width = window.innerWidth;
    let height = window.innerHeight;

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    window.addEventListener('resize', resize);

    const count = width < 640 ? 75 : 110;
    const particles: Particle[] = [];

    for (let i = 0; i < count; i += 1) {
      // Launch from two side-upper cannons + center fountain
      const originChoice = i % 3;
      const startX =
        originChoice === 0
          ? width * 0.5
          : originChoice === 1
            ? width * 0.22
            : width * 0.78;
      const startY = originChoice === 0 ? height * 0.28 : height * 0.36;

      const angleSpread = (Math.random() - 0.5) * Math.PI * 0.85;
      const baseAngle = -Math.PI / 2 + angleSpread;
      const speed = 6 + Math.random() * 10;

      particles.push({
        x: startX + (Math.random() - 0.5) * 40,
        y: startY + (Math.random() - 0.5) * 20,
        vx: Math.cos(baseAngle) * speed,
        vy: Math.sin(baseAngle) * speed - Math.random() * 2.5,
        w: 7 + Math.random() * 6,
        h: 5 + Math.random() * 5,
        color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
        rotation: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 0.22,
        tilt: Math.random() * Math.PI,
        vtilt: 0.08 + Math.random() * 0.12,
        shape: i % 5 === 0 ? 'circle' : 'rect',
        alpha: 1,
      });
    }

    const durationMs = 3000;
    const startTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = elapsed / durationMs;

      ctx.clearRect(0, 0, width, height);

      let alive = false;
      for (const p of particles) {
        p.vy += 0.28; // gravity
        p.vx *= 0.985; // air drag
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.vr;
        p.tilt += p.vtilt;

        if (progress > 0.65) {
          p.alpha = Math.max(0, 1 - (progress - 0.65) / 0.35);
        }

        if (p.alpha > 0.02 && p.y < height + 40) {
          alive = true;
          ctx.save();
          ctx.globalAlpha = p.alpha;
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.fillStyle = p.color;

          if (p.shape === 'circle') {
            ctx.beginPath();
            ctx.arc(0, 0, p.w * 0.42, 0, Math.PI * 2);
            ctx.fill();
          } else {
            const scaleY = Math.cos(p.tilt);
            ctx.fillRect(-p.w / 2, (-p.h * scaleY) / 2, p.w, p.h * scaleY);
          }
          ctx.restore();
        }
      }

      if (alive && elapsed < durationMs) {
        rafId = window.requestAnimationFrame(tick);
      } else {
        ctx.clearRect(0, 0, width, height);
        onCompleteRef.current?.();
      }
    };

    rafId = window.requestAnimationFrame(tick);

    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
    };
  }, [triggerKey]);

  if (triggerKey <= 0) return null;

  return (
    <canvas
      ref={canvasRef}
      data-testid="confetti-canvas"
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-50"
    />
  );
};
