import React from 'react';
import {
  LayoutDashboard,
  BookOpen,
  ClipboardCheck,
  Trophy,
  LogOut,
  Dna,
} from 'lucide-react';
import { useBiolearn, type AppRoute } from '../context/BiolearnContext';

interface StudentShellProps {
  children: React.ReactNode;
}

export const StudentShell: React.FC<StudentShellProps> = ({ children }) => {
  const { db, activeStudent, activeStudentStats, route, setRoute, logout } = useBiolearn();

  if (!db || !activeStudent) return null;

  const navItems: Array<{ id: AppRoute; label: string; icon: React.ReactNode }> = [
    {
      id: 'student-dashboard',
      label: 'Beranda',
      icon: <LayoutDashboard className="h-5 w-5" aria-hidden="true" />,
    },
    {
      id: 'student-material',
      label: 'Materi',
      icon: <BookOpen className="h-5 w-5" aria-hidden="true" />,
    },
    {
      id: 'student-lkpd',
      label: 'LKPD',
      icon: <ClipboardCheck className="h-5 w-5" aria-hidden="true" />,
    },
    {
      id: 'student-leaderboard',
      label: 'Peringkat',
      icon: <Trophy className="h-5 w-5" aria-hidden="true" />,
    },
  ];

  return (
    <div className="min-h-[100dvh] w-full overflow-x-hidden bg-gradient-to-b from-emerald-50/70 via-[#F4FAF6] to-slate-50 pb-20 md:pb-8">
      {/* Compact Sticky Header: 54px height on mobile */}
      <header className="sticky top-0 z-30 border-b border-emerald-200/80 bg-white/95 backdrop-blur-md">
        <div className="mx-auto flex h-[54px] max-w-6xl items-center justify-between gap-2 px-3 sm:px-6">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-800 to-emerald-600 text-white">
              <Dna className="h-4 w-4" aria-hidden="true" />
            </span>
            <div className="min-w-0">
              <div className="truncate text-sm font-bold text-emerald-950">
                {activeStudent.fullName}
              </div>
              <div className="truncate text-[11px] font-medium text-slate-500">
                {activeStudent.className}
              </div>
            </div>
          </div>

          {/* Desktop Center Nav */}
          <nav className="hidden md:flex items-center gap-2" aria-label="Navigasi Siswa">
            {navItems.map((item) => {
              const active = route === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setRoute(item.id)}
                  className={`flex min-h-[40px] items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold whitespace-nowrap shrink-0 transition-colors ${
                    active
                      ? 'bg-emerald-900 text-white'
                      : 'text-slate-600 hover:bg-emerald-50 hover:text-emerald-900'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Points + Logout */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="rounded-xl border border-emerald-200 bg-emerald-100/80 px-2.5 py-1 text-xs font-bold text-emerald-950 tabular-nums">
              {activeStudentStats?.totalPoints ?? 0} Poin
            </div>

            <button
              type="button"
              onClick={logout}
              aria-label="Keluar dari akun siswa"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-red-700"
            >
              <LogOut className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-3 py-5 sm:px-6">{children}</main>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="Navigasi Bawah Siswa"
        className="fixed bottom-0 left-0 right-0 z-40 border-t border-emerald-200/80 bg-white/95 backdrop-blur-md pb-safe md:hidden"
      >
        <div className="grid h-[60px] grid-cols-4 items-center gap-1 px-1.5">
          {navItems.map((item) => {
            const active = route === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setRoute(item.id)}
                className={`flex min-h-[46px] flex-col items-center justify-center gap-0.5 rounded-xl px-1 transition-colors ${
                  active
                    ? 'bg-emerald-900 text-white font-bold'
                    : 'text-slate-600 font-medium hover:bg-emerald-50'
                }`}
              >
                <span className={active ? 'text-orange-300' : 'text-slate-500'}>{item.icon}</span>
                <span className="text-[11px] leading-tight whitespace-nowrap">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
};
