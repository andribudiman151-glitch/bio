export type MissionId = 'misi-1' | 'misi-2' | 'misi-3';

export type BadgeId =
  | 'detektif_pemula'
  | 'ahli_genetika'
  | 'master_kromosom'
  | 'peneliti_hebat'
  | 'argumentator_terbaik'
  | 'detektif_terbaik';

export interface TeacherRecord {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  createdAt: string;
}

export interface ClassRoom {
  id: string;
  name: string;
  createdAt: string;
}

export interface StudentRecord {
  id: string;
  fullName: string;
  nimHash: string;
  nimDisplay: string;
  classId: string;
  className: string;
  isDemo: boolean;
  readChapters: string[];
  timerStartedAt: string | null;
  timerFinishedAt: string | null;
  timeExpiredLocked: boolean;
  createdAt: string;
  lastActiveAt: string;
}

export interface QuestionOption {
  id: string;
  text: string;
}

export interface QuestionItem {
  id: string;
  missionId: MissionId;
  order: number;
  prompt: string;
  options: QuestionOption[];
  correctOptionId: string;
  explanation: string;
  placeholder?: string;
  expectedConcepts?: string[];
}

export interface SortingCardItem {
  id: string;
  label: string;
  detail: string;
  correctCategory: 'mutasi-gen' | 'mutasi-kromosom';
}

export interface AssignmentMission {
  id: MissionId;
  number: number;
  title: string;
  subtitle: string;
  mainQuestion: string;
  caseSummary: string;
  rubricNotes: string;
  maxAccuracyPoints: number;
  completionPoints: number;
}

export interface StudentAnswerRecord {
  id: string;
  studentId: string;
  missionId: MissionId;
  answers: Record<string, string>;
  sortingAssignments?: Record<string, 'mutasi-gen' | 'mutasi-kromosom'>;
  sortingScore?: number;
  status: 'draft' | 'submitted' | 'graded';
  updatedAt: string;
  submittedAt: string | null;
}

export interface StructuredFeedback {
  score: number;
  correctConcepts: string;
  needsImprovement: string;
  improvementSuggestions: string;
  learningNotes: string;
  source: 'gemini' | 'fallback';
}

export interface GradingResultRecord {
  id: string;
  studentId: string;
  missionId: MissionId;
  aiScore: number;
  aiFeedback: StructuredFeedback;
  teacherScoreOverride: number | null;
  teacherComment: string;
  finalScore: number;
  gradedAt: string;
  overriddenAt: string | null;
}

export interface ReflectionRecord {
  id: string;
  studentId: string;
  newThingLearned: string;
  curiousQuestion: string;
  submittedAt: string;
}

export interface BadgeDefinition {
  id: BadgeId;
  name: string;
  description: string;
  requirement: string;
  iconKey: string;
}

export interface StudentBadgeRecord {
  id: string;
  studentId: string;
  badgeId: BadgeId;
  earnedAt: string;
}

export interface PointWeights {
  mission1Accuracy: number;
  mission1Completion: number;
  mission2Accuracy: number;
  mission2Completion: number;
  mission3Accuracy: number;
  mission3Completion: number;
  activityMax: number;
}

export interface AppSettings {
  timerEnabled: boolean;
  timerDurationMinutes: number;
  lockOnTimeExpired: boolean;
  leaderboardVisible: boolean;
  pointWeights: PointWeights;
  updatedAt: string;
}

export interface DatabaseSchema {
  version: number;
  teachers: TeacherRecord[];
  classes: ClassRoom[];
  students: StudentRecord[];
  assignments: AssignmentMission[];
  questions: QuestionItem[];
  student_answers: StudentAnswerRecord[];
  grading_results: GradingResultRecord[];
  reflections: ReflectionRecord[];
  badges: BadgeDefinition[];
  student_badges: StudentBadgeRecord[];
  settings: AppSettings;
}

export interface StudentComputedStats {
  studentId: string;
  mission1Points: number;
  mission2Points: number;
  mission3Points: number;
  activityPoints: number;
  totalPoints: number;
  averageAccuracyScore: number;
  completedMissionsCount: number;
  hasReflection: boolean;
  hasCompletedAllMaterials: boolean;
  progressPercent: number;
  completionDurationSeconds: number;
  earnedBadgeIds: BadgeId[];
}

export interface LeaderboardEntry {
  rank: number;
  student: StudentRecord;
  stats: StudentComputedStats;
  badges: BadgeDefinition[];
}

export type ActiveSession =
  | { role: 'none' }
  | { role: 'student'; studentId: string }
  | { role: 'teacher'; teacherId: string; email: string; name: string };
