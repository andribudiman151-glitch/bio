import type { DatabaseSchema } from '../types/biolearn';
import { BADGE_DEFINITIONS, DEFAULT_QUESTIONS } from '../data/curriculum';
import {
  createDefaultTeachers,
  createDemoRecords,
  createInitialDatabase,
} from '../data/demoSeed';

const STORAGE_KEY = 'biolearn_db_v1';

/**
 * Repository abstraction layer (Repository Pattern).
 * Implementations can swap between LocalStorage (offline-ready client store),
 * Firebase Firestore, or Supabase PostgreSQL without changing UI components.
 */
export interface IBiolearnRepository {
  loadDatabase(): Promise<DatabaseSchema>;
  saveDatabase(db: DatabaseSchema): Promise<void>;
  loadDemoData(current: DatabaseSchema): Promise<DatabaseSchema>;
  resetDemoData(current: DatabaseSchema): Promise<DatabaseSchema>;
}

export class LocalStorageBiolearnRepository implements IBiolearnRepository {
  async loadDatabase(): Promise<DatabaseSchema> {
    if (typeof window === 'undefined' || !window.localStorage) {
      return createInitialDatabase(false);
    }

    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        const fresh = await createInitialDatabase(false);
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
        return fresh;
      }
      const parsed = JSON.parse(raw) as DatabaseSchema;
      if (!parsed || !Array.isArray(parsed.students) || !Array.isArray(parsed.teachers)) {
        const fresh = await createInitialDatabase(false);
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
        return fresh;
      }
      const currentVersion = parsed.version ?? 1;
      const hasLegacyQuestions =
        !Array.isArray(parsed.questions) ||
        parsed.questions.length === 0 ||
        parsed.questions.some((q) => !Array.isArray(q.options) || q.options.length === 0);

      if (currentVersion < 5 || hasLegacyQuestions) {
        let migrated: DatabaseSchema = {
          ...parsed,
          version: 5,
          teachers: createDefaultTeachers(),
          questions: hasLegacyQuestions ? [...DEFAULT_QUESTIONS] : parsed.questions,
          badges: [...BADGE_DEFINITIONS],
          settings: {
            ...parsed.settings,
            timerDurationMinutes:
              currentVersion < 5 && parsed.settings?.timerDurationMinutes === 45
                ? 10
                : parsed.settings?.timerDurationMinutes ?? 10,
          },
        };
        if (currentVersion < 2) {
          migrated = await this.resetDemoData(migrated);
        } else {
          await this.saveDatabase(migrated);
        }
        return migrated;
      }
      return parsed;
    } catch {
      const fresh = await createInitialDatabase(false);
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
      } catch {
        // Ignore quota errors
      }
      return fresh;
    }
  }

  async saveDatabase(db: DatabaseSchema): Promise<void> {
    if (typeof window === 'undefined' || !window.localStorage) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
    } catch (err) {
      console.error('Failed saving BIOLEARN database:', err);
    }
  }

  /**
   * Loads demo records while keeping all real (non-demo) student records intact.
   */
  async loadDemoData(current: DatabaseSchema): Promise<DatabaseSchema> {
    const demo = await createDemoRecords();
    const realStudents = current.students.filter((s) => !s.isDemo);
    const realStudentIds = new Set(realStudents.map((s) => s.id));

    const next: DatabaseSchema = {
      ...current,
      students: [...realStudents, ...demo.students],
      student_answers: [
        ...current.student_answers.filter((a) => realStudentIds.has(a.studentId)),
        ...demo.student_answers,
      ],
      grading_results: [
        ...current.grading_results.filter((g) => realStudentIds.has(g.studentId)),
        ...demo.grading_results,
      ],
      reflections: [
        ...current.reflections.filter((r) => realStudentIds.has(r.studentId)),
        ...demo.reflections,
      ],
      student_badges: [
        ...current.student_badges.filter((b) => realStudentIds.has(b.studentId)),
        ...demo.student_badges,
      ],
    };
    await this.saveDatabase(next);
    return next;
  }

  /**
   * Removes only demo/test data while preserving real student accounts & submissions.
   */
  async resetDemoData(current: DatabaseSchema): Promise<DatabaseSchema> {
    const realStudents = current.students.filter((s) => !s.isDemo);
    const realStudentIds = new Set(realStudents.map((s) => s.id));

    const next: DatabaseSchema = {
      ...current,
      students: realStudents,
      student_answers: current.student_answers.filter((a) => realStudentIds.has(a.studentId)),
      grading_results: current.grading_results.filter((g) => realStudentIds.has(g.studentId)),
      reflections: current.reflections.filter((r) => realStudentIds.has(r.studentId)),
      student_badges: current.student_badges.filter((b) => realStudentIds.has(b.studentId)),
    };
    await this.saveDatabase(next);
    return next;
  }
}

export const biolearnRepository: IBiolearnRepository = new LocalStorageBiolearnRepository();
