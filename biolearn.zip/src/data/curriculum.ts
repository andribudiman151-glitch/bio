import type {
  AppSettings,
  AssignmentMission,
  BadgeDefinition,
  ClassRoom,
  QuestionItem,
  SortingCardItem,
} from '../types/biolearn';

export interface ConceptFlashCard {
  term: string;
  brief: string;
  tag?: string;
}

export interface MaterialSubSection {
  title: string;
  summary: string;
  cards: ConceptFlashCard[];
}

export interface QuickCheckQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  feedback: string;
}

export interface MaterialChapter {
  id: string;
  order: number;
  title: string;
  shortTitle: string;
  lead: string;
  funFact: string;
  interactiveType: 'mutagen' | 'dna-point' | 'chromosome-aberration' | 'impact-ploidy';
  sections: MaterialSubSection[];
  quickCheck: QuickCheckQuestion;
}

export const MATERIAL_CHAPTERS: MaterialChapter[] = [
  {
    id: 'konsep-dasar',
    order: 1,
    title: 'Konsep Dasar Mutasi',
    shortTitle: 'Konsep Dasar',
    lead: 'Mutasi adalah perubahan materi genetik (DNA atau kromosom) yang memicu variasi sifat baru pada sel atau organisme.',
    funFact:
      'Setiap hari sel tubuh kita mengalami ribuan kerusakan DNA kecil, tetapi sebagian besar langsung diperbaiki enzim sel sebelum menjadi mutasi permanen.',
    interactiveType: 'mutagen',
    sections: [
      {
        title: '3 Istilah Wajib & Lokasi Terjadinya',
        summary: 'Kenali pelaku, proses, dan jenis sel yang terdampak mutasi:',
        cards: [
          { term: 'Mutasi & Mutan', brief: 'Mutasi = peristiwanya; Mutan = sel/individu yang mengalami perubahan genetik.' },
          { term: 'Mutagen', brief: 'Faktor pemicu mutasi (fisika, kimia, atau biologi).' },
          { term: 'Mutasi Gametik', brief: 'Terjadi di sel kelamin (sperma/ovum) → diwariskan ke keturunan.' },
          { term: 'Mutasi Somatik', brief: 'Terjadi di sel tubuh → tidak diwariskan, bisa memicu kanker.' },
        ],
      },
      {
        title: 'Tiga Kelompok Mutagen',
        summary: 'Agen pemicu perubahan genetik di alam maupun laboratorium:',
        cards: [
          { term: 'Fisika', brief: 'Sinar UV, sinar-X, & radiasi gamma (memutus rantai DNA / dimer timin).' },
          { term: 'Kimia', brief: 'Kolkisin (penghambat spindel → semangka tanpa biji), asam nitrit, benzopiren.' },
          { term: 'Biologi', brief: 'Virus (HPV, retrovirus) yang menyisipkan DNA-nya ke genom inang.' },
        ],
      },
    ],
    quickCheck: {
      question: 'Mengapa mutasi pada sel kulit akibat sinar UV tidak diwariskan ke anak?',
      options: [
        'Karena termasuk mutasi somatik pada sel tubuh, bukan sel gamet',
        'Karena sinar UV hanya mengubah struktur protein, bukan DNA',
      ],
      correctIndex: 0,
      feedback: 'Tepat! Hanya mutasi pada sel kelamin (gametik) yang diwariskan ke generasi berikutnya.',
    },
  },
  {
    id: 'mutasi-gen',
    order: 2,
    title: 'Mutasi Gen (Mutasi Titik)',
    shortTitle: 'Mutasi Gen',
    lead: 'Perubahan kecil pada satu atau beberapa basa nitrogen (A, T, G, C) di untai DNA yang dapat mengubah pembacaan kodon protein.',
    funFact:
      'Hanya salah satu huruf basa pada gen hemoglobin (Glu → Val) sudah cukup mengubah bentuk sel darah merah menjadi seperti bulan sabit!',
    interactiveType: 'dna-point',
    sections: [
      {
        title: 'Substitusi (Tukar Pasangan Basa)',
        summary: 'Satu basa digantikan basa lain dengan dua pola:',
        cards: [
          { term: 'Transisi (Sejenis)', brief: 'Purin ↔ Purin (A ↔ G) atau Pirimidin ↔ Pirimidin (C ↔ T).' },
          { term: 'Transversi (Beda Jenis)', brief: 'Purin ↔ Pirimidin (contoh: A ↔ T atau G ↔ C).' },
        ],
      },
      {
        title: '4 Efeknya pada Protein',
        summary: 'Bandingkan efek langsungnya pada Simulator DNA di atas:',
        cards: [
          { term: 'Silent Mutation', brief: 'Kodon berubah, asam amino tetap sama (protein aman).' },
          { term: 'Missense Mutation', brief: 'Satu asam amino berubah (contoh: anemia sel sabit).' },
          { term: 'Nonsense Mutation', brief: 'Muncul kodon STOP (UAA/UAG/UGA) → protein terpotong.' },
          { term: 'Frameshift (Insersi/Delesi)', brief: 'Tambah/hilang 1–2 basa → semua kodon setelahnya bergeser.' },
        ],
      },
    ],
    quickCheck: {
      question: 'Jenis mutasi titik manakah yang menggeser seluruh pembacaan kodon setelah titik mutasi?',
      options: [
        'Silent mutation',
        'Frameshift mutation (insersi atau delesi 1 basa)',
      ],
      correctIndex: 1,
      feedback: 'Benar! Penyisipan atau pengurangan 1–2 basa (bukan kelipatan 3) menggeser kerangka triplet.',
    },
  },
  {
    id: 'mutasi-kromosom',
    order: 3,
    title: 'Mutasi Kromosom (Aberasi)',
    shortTitle: 'Mutasi Kromosom',
    lead: 'Perubahan berskala besar pada struktur patahan segmen kromosom atau jumlah total kromosom akibat gagal berpisah (nondisjunction).',
    funFact:
      'Semangka tanpa biji muncul karena memiliki 3 set kromosom (3n) hasil perkawinan induk 4n dan 2n!',
    interactiveType: 'chromosome-aberration',
    sections: [
      {
        title: '5 Perubahan Struktur Kromosom',
        summary: 'Terjadi saat kromosom patah dan tersusun ulang:',
        cards: [
          { term: 'Delesi', brief: 'Segmen kromosom hilang (contoh: Sindrom Cri du Chat pada kromosom 5).' },
          { term: 'Duplikasi', brief: 'Segmen kromosom mengganda berulang.' },
          { term: 'Inversi', brief: 'Segmen berputar 180° (Parasentrik: tanpa sentromer; Perisentrik: lewat sentromer).' },
          { term: 'Translokasi & Katenasi', brief: 'Pindah segmen ke non-homolog; ujung homolog membentuk lingkaran (katenasi).' },
        ],
      },
      {
        title: 'Perubahan Jumlah: Euploidi vs Aneuploidi',
        summary: 'Beda perubahan seluruh set kromosom dengan kelebihan/kekurangan 1 kromosom:',
        cards: [
          { term: 'Euploidi (Set Genom n)', brief: 'Monoploid (n), Diploid (2n), Triploid (3n, semangka tanpa biji), Poliploid (4n+).' },
          { term: 'Aneuploidi (Nondisjunction)', brief: 'Nulisomi (2n−2), Monosomi (2n−1), Trisomi (2n+1).' },
          { term: 'Sindrom Manusia', brief: 'Turner (45,XO / 2n−1), Down (47,+21 / 2n+1), Klinefelter (47,XXY / 2n+1).' },
        ],
      },
    ],
    quickCheck: {
      question: 'Sindrom Down (47, XY + 21) tergolong mutasi kromosom jenis apa?',
      options: [
        'Aneuploidi (Trisomi 21 akibat nondisjunction)',
        'Euploidi (Triploid 3n seluruh set kromosom)',
      ],
      correctIndex: 0,
      feedback: 'Tepat! Hanya kromosom nomor 21 yang bertambah satu (2n + 1), bukan seluruh set kromosom.',
    },
  },
  {
    id: 'dampak-manfaat',
    order: 4,
    title: 'Dampak & Manfaat Mutasi',
    shortTitle: 'Dampak & Manfaat',
    lead: 'Mutasi adalah bahan bakar evolusi sekaligus pisau bermata dua: bisa merugikan kesehatan, tetapi sangat berguna di pertanian dan medis.',
    funFact:
      'Padi unggul Indonesia seperti varietas Atomita dikembangkan lewat teknik pemuliaan mutasi radiasi terkendali agar cepat panen!',
    interactiveType: 'impact-ploidy',
    sections: [
      {
        title: 'Mutasi Menguntungkan (Pertanian & Bioteknologi)',
        summary: 'Dimanfaatkan manusia untuk menghasilkan varietas unggul:',
        cards: [
          { term: 'Buah Tanpa Biji (3n)', brief: 'Semangka, pisang, dan anggur triploid berdaging tebal & bebas biji.' },
          { term: 'Poliploidi Tanaman', brief: 'Gandum dan stroberi budidaya berukuran lebih besar & produktif.' },
          { term: 'Varietas Unggul & Antibiotik', brief: 'Padi Atomita tahan hama serta jamur Penicillium mutan penghasil antibiotik tinggi.' },
        ],
      },
      {
        title: 'Mutasi Merugikan (Kelainan & Kanker)',
        summary: 'Gangguan fungsi protein penting dan kendali pembelahan sel:',
        cards: [
          { term: 'Kelainan Gen', brief: 'Anemia sel sabit, talasemia, fenilketonuria (PKU), dan albino.' },
          { term: 'Sindrom Kromosom', brief: 'Down (trisomi 21), Edwards (18), Patau (13), Turner (45,XO), Klinefelter (47,XXY).' },
          { term: 'Kanker (Karsinogenesis)', brief: 'Mutasi proto-onkogen & gen penekan tumor (TP53) membuat sel membelah tak terkendali.' },
        ],
      },
    ],
    quickCheck: {
      question: 'Mengapa tanaman triploid (3n) seperti semangka tanpa biji tidak menghasilkan biji?',
      options: [
        'Karena jumlah set kromosom ganjil (3n) gagal berpasangan merata saat meiosis sehingga gamet steril',
        'Karena tanaman triploid tidak pernah melakukan pembelahan mitosis',
      ],
      correctIndex: 0,
      feedback: 'Benar sekali! Konsep inilah yang akan kamu pecahkan lebih dalam di Misi 1 LKPD.',
    },
  },
];

export const DEFAULT_CLASSES: ClassRoom[] = [
  { id: 'class-12-ipa-1', name: 'XII IPA 1', createdAt: '2026-01-10T08:00:00.000Z' },
  { id: 'class-12-ipa-2', name: 'XII IPA 2', createdAt: '2026-01-10T08:00:00.000Z' },
  { id: 'class-12-ipa-3', name: 'XII IPA 3', createdAt: '2026-01-10T08:00:00.000Z' },
];

export const DEFAULT_MISSIONS: AssignmentMission[] = [
  {
    id: 'misi-1',
    number: 1,
    title: 'Misi 1: Rahasia Semangka Tanpa Biji',
    subtitle: 'Investigasi Euploidi & Induksi Kolkisin',
    mainQuestion: 'Mengapa semangka tanpa biji bisa muncul?',
    caseSummary:
      'Laboratorium Agronomi menemukan semangka di pasaran yang memiliki ukuran daging buah besar dan sama sekali tidak menghasilkan biji fertil. Petugas menduga terjadi manipulasi jumlah set kromosom menggunakan senyawa kimia kolkisin sebelum persilangan dilakukan.',
    rubricNotes:
      'Siswa harus mengaitkan pemberian kolkisin dengan gagalnya pembentukan benang spindel (terbentuk tanaman tetraploid 4n), persilangan induk 4n dengan diploid 2n menghasilkan zigot triploid 3n, dan ketidakmampuan kromosom 3n berpasangan secara seimbang saat meiosis sehingga gamet mandul dan tidak terbentuk biji.',
    maxAccuracyPoints: 20,
    completionPoints: 10,
  },
  {
    id: 'misi-2',
    number: 2,
    title: 'Misi 2: Kode Genetik',
    subtitle: 'Membedakan Mutasi Gen dan Mutasi Kromosom',
    mainQuestion: 'Apa perbedaan mutasi gen dan mutasi kromosom?',
    caseSummary:
      'Tim forensik genetika menerima dua sampel berkas mutasi: satu berkas menunjukkan substitusi basa tunggal pada untai DNA hemoglobin, sedangkan berkas lain menunjukkan hilangnya lengan pendek kromosom nomor 5 dan trisomi 21. Kelompokkan kartu konsep dan rumuskan analisis perbandingannya.',
    rubricNotes:
      'Siswa harus membedakan skala perubahan (urutan basa nitrogen pada satu lokus gen vs struktur atau jumlah keseluruhan kromosom), mekanisme (substitusi, insersi, delesi basa vs delesi, duplikasi, inversi, translokasi, euploidi/aneuploidi), dan skala dampaknya terhadap sintesis protein serta fenotipe organisme.',
    maxAccuracyPoints: 20,
    completionPoints: 10,
  },
  {
    id: 'misi-3',
    number: 3,
    title: 'Misi 3: Misteri Jumlah Kromosom',
    subtitle: 'Analisis Aneuploidi, Euploidi & Kariotipe',
    mainQuestion: 'Bagaimana mutasi jumlah kromosom memengaruhi organisme?',
    caseSummary:
      'Analisis kariotipe rumah sakit dan kebun percobaan memperlihatkan perubahan jumlah kromosom: pada manusia ditemukan kasus 47,XY+21 (Sindrom Down) dan 45,XO (Sindrom Turner), sementara pada tanaman ditemukan individu triploid (3n) yang justru subur vegetatif tanpa biji.',
    rubricNotes:
      'Siswa harus menjelaskan bahwa perubahan jumlah kromosom (aneuploidi akibat nondisjunction maupun euploidi/poliploidi) memengaruhi keseimbangan ekspresi gen, tetapi dampaknya berbeda antara hewan/manusia (sering memicu sindrom atau letalitas) dengan tumbuhan (sering lebih toleran, bahkan menghasilkan buah besar/tanpa biji).',
    maxAccuracyPoints: 20,
    completionPoints: 10,
  },
];

export const DEFAULT_QUESTIONS: QuestionItem[] = [
  // Misi 1: Rahasia Semangka Tanpa Biji (4 Soal Pilihan Ganda)
  {
    id: 'm1-q1',
    missionId: 'misi-1',
    order: 1,
    prompt: 'Berdasarkan pengamatan diagram ploidi, perbedaan utama antara semangka tanpa biji dan semangka biasa adalah ...',
    options: [
      { id: 'A', text: 'Semangka tanpa biji bersifat haploid (n), sedangkan semangka biasa diploid (2n).' },
      { id: 'B', text: 'Semangka tanpa biji bersifat triploid (3n) dengan daging buah besar tanpa biji fertil, sedangkan semangka biasa diploid (2n).' },
      { id: 'C', text: 'Semangka tanpa biji mengalami mutasi titik pada gen warna kulit buah.' },
      { id: 'D', text: 'Semangka tanpa biji kehilangan satu kromosom seks sehingga bijinya mengering.' },
    ],
    correctOptionId: 'B',
    explanation: 'Semangka tanpa biji memiliki 3 set kromosom (triploid / 3n), berbeda dengan semangka normal yang diploid (2n).',
  },
  {
    id: 'm1-q2',
    missionId: 'misi-1',
    order: 2,
    prompt: 'Apa fungsi senyawa kimia kolkisin yang diberikan pada tanaman semangka induk sebelum persilangan?',
    options: [
      { id: 'A', text: 'Mempercepat pembuahan serbuk sari di dalam bakal biji.' },
      { id: 'B', text: 'Memotong segmen kromosom sehingga terbentuk mutasi delesi.' },
      { id: 'C', text: 'Menghambat pembentukan benang spindel saat pembelahan sel sehingga kromosom mengganda menjadi tetraploid (4n).' },
      { id: 'D', text: 'Mengubah basa adenin menjadi guanin pada DNA inti sel tumbuhan.' },
    ],
    correctOptionId: 'C',
    explanation: 'Kolkisin adalah mutagen kimia yang menghambat pembentukan benang spindel pada mitosis sehingga kromosom tetap mengganda (2n → 4n) tanpa pemisahan sel.',
  },
  {
    id: 'm1-q3',
    missionId: 'misi-1',
    order: 3,
    prompt: 'Hasil persilangan induk tetraploid (4n) dan diploid (2n) menghasilkan individu triploid (3n). Mengapa tanaman 3n tidak membentuk biji?',
    options: [
      { id: 'A', text: 'Tiga perangkat kromosom (ganjil) tidak dapat berpasangan merata saat meiosis sehingga gamet mandul (steril).' },
      { id: 'B', text: 'Tanaman triploid (3n) tidak memiliki bunga jantan maupun bunga betina.' },
      { id: 'C', text: 'Kolkisin langsung membunuh seluruh bakal biji setelah buah matang.' },
      { id: 'D', text: 'Sel triploid tidak dapat melakukan pembelahan mitosis untuk memperbesar buah.' },
    ],
    correctOptionId: 'A',
    explanation: 'Pada meiosis tanaman triploid (3n), kromosom berjumlah ganjil gagal membentuk pasangan homolog yang seimbang sehingga sel kelamin steril dan biji tidak terbentuk.',
  },
  {
    id: 'm1-q4',
    missionId: 'misi-1',
    order: 4,
    prompt: 'Kesimpulan yang paling tepat mengenai jenis mutasi pada pembuatan semangka tanpa biji adalah ...',
    options: [
      { id: 'A', text: 'Mutasi gen tipe frameshift yang merugikan petani.' },
      { id: 'B', text: 'Mutasi kromosom tipe aneuploidi (monosomi 2n−1).' },
      { id: 'C', text: 'Mutasi somatik alami akibat paparan sinar ultraviolet matahari.' },
      { id: 'D', text: 'Mutasi kromosom tipe euploidi (poliploidi/triploid 3n) buatan yang menguntungkan di bidang pertanian.' },
    ],
    correctOptionId: 'D',
    explanation: 'Perubahan seluruh perangkat set kromosom (2n menjadi 3n/4n) merupakan euploidi/poliploidi buatan yang bernilai ekonomi tinggi.',
  },

  // Misi 2: Kode Genetik (4 Soal Pilihan Ganda)
  {
    id: 'm2-q1',
    missionId: 'misi-2',
    order: 1,
    prompt: 'Manakah pernyataan yang paling akurat membedakan skala perubahan mutasi gen dan mutasi kromosom?',
    options: [
      { id: 'A', text: 'Mutasi gen hanya terjadi pada sel hewan, sedangkan mutasi kromosom hanya pada tumbuhan.' },
      { id: 'B', text: 'Mutasi gen mengubah urutan basa nitrogen pada satu lokus DNA, sedangkan mutasi kromosom mengubah struktur segmen atau jumlah keseluruhan kromosom.' },
      { id: 'C', text: 'Mutasi gen selalu menambah jumlah kromosom, sedangkan mutasi kromosom hanya menukar satu basa.' },
      { id: 'D', text: 'Mutasi gen selalu terlihat di bawah mikroskop cahaya, sedangkan mutasi kromosom tidak terlihat.' },
    ],
    correctOptionId: 'B',
    explanation: 'Mutasi gen (titik) terjadi pada skala basa nitrogen satu lokus gen, sedangkan mutasi kromosom (aberasi) mengubah struktur patahan segmen atau jumlah kromosom.',
  },
  {
    id: 'm2-q2',
    missionId: 'misi-2',
    order: 2,
    prompt: 'Pasangan peristiwa berikut yang keduanya termasuk contoh MUTASI GEN (mutasi titik) adalah ...',
    options: [
      { id: 'A', text: 'Sindrom Down (trisomi 21) dan inversi perisentrik.' },
      { id: 'B', text: 'Semangka triploid (3n) dan translokasi resiprok.' },
      { id: 'C', text: 'Substitusi basa pada anemia sel sabit (Glu → Val) dan frameshift mutation akibat insersi 1 basa.' },
      { id: 'D', text: 'Sindrom Cri du Chat (delesi kromosom 5) dan Sindrom Turner (45,XO).' },
    ],
    correctOptionId: 'C',
    explanation: 'Anemia sel sabit disebabkan substitusi satu basa dan frameshift disebabkan insersi/delesi 1–2 basa nitrogen pada untai DNA.',
  },
  {
    id: 'm2-q3',
    missionId: 'misi-2',
    order: 3,
    prompt: 'Kasus berkas forensik menunjukkan hilangnya sebagian lengan pendek kromosom nomor 5 (Sindrom Cri du Chat). Kelainan ini termasuk ...',
    options: [
      { id: 'A', text: 'Mutasi kromosom tipe delesi struktur segmen kromosom.' },
      { id: 'B', text: 'Mutasi gen tipe silent mutation.' },
      { id: 'C', text: 'Mutasi gen tipe transversi purin–pirimidin.' },
      { id: 'D', text: 'Mutasi kromosom tipe euploidi tetraploid (4n).' },
    ],
    correctOptionId: 'A',
    explanation: 'Sindrom Cri du Chat terjadi karena patahan dan hilangnya sebagian segmen (delesi) pada lengan pendek kromosom nomor 5.',
  },
  {
    id: 'm2-q4',
    missionId: 'misi-2',
    order: 4,
    prompt: 'Bagaimana perbandingan dampak mutasi gen dan mutasi kromosom terhadap sintesis protein serta fenotipe organisme?',
    options: [
      { id: 'A', text: 'Mutasi gen tidak pernah memengaruhi asam amino, sedangkan mutasi kromosom hanya mengubah satu basa.' },
      { id: 'B', text: 'Mutasi gen dan mutasi kromosom sama-sama tidak memengaruhi sintesis protein sama sekali.' },
      { id: 'C', text: 'Mutasi kromosom hanya berdampak ringan pada satu asam amino saja.' },
      { id: 'D', text: 'Mutasi gen mengubah kodon/asam amino pada protein tertentu, sedangkan mutasi kromosom mengubah dosis banyak gen sekaligus dan berpotensi memicu sindrom.' },
    ],
    correctOptionId: 'D',
    explanation: 'Mutasi gen memengaruhi satu produk protein (silent/missense/nonsense/frameshift), sedangkan aberasi kromosom berdampak pada puluhan hingga ratusan gen sekaligus.',
  },

  // Misi 3: Misteri Jumlah Kromosom (4 Soal Pilihan Ganda)
  {
    id: 'm3-q1',
    missionId: 'misi-3',
    order: 1,
    prompt: 'Penyebab utama munculnya kelainan jumlah kromosom aneuploidi seperti 47,XY+21 dan 45,XO pada manusia adalah ...',
    options: [
      { id: 'A', text: 'Substitusi transisi adenin menjadi guanin saat replikasi DNA.' },
      { id: 'B', text: 'Gagal berpisah (nondisjunction) kromosom homolog atau kromatid saudara saat pembelahan meiosis.' },
      { id: 'C', text: 'Terbentuknya kodon STOP UAA sebelum proses translasi selesai.' },
      { id: 'D', text: 'Pemberian pupuk nitrogen berlebih pada fase embrio.' },
    ],
    correctOptionId: 'B',
    explanation: 'Aneuploidi (kelebihan atau kekurangan 1 kromosom) terjadi akibat gagal berpisah (nondisjunction) saat anafase meiosis.',
  },
  {
    id: 'm3-q2',
    missionId: 'misi-3',
    order: 2,
    prompt: 'Berdasarkan analisis kariotipe, pasangan rumus kromosom dan nama sindrom yang tepat adalah ...',
    options: [
      { id: 'A', text: '47,XY+21 = Sindrom Down (Trisomi 21) dan 45,XO = Sindrom Turner (Monosomi X).' },
      { id: 'B', text: '47,XY+21 = Sindrom Turner dan 45,XO = Sindrom Klinefelter.' },
      { id: 'C', text: '47,XY+21 = Sindrom Cri du Chat dan 45,XO = Sindrom Patau.' },
      { id: 'D', text: '47,XY+21 = Euploidi Triploid dan 45,XO = Sindrom Edwards.' },
    ],
    correctOptionId: 'A',
    explanation: '47,XY+21 memiliki kelebihan 1 kromosom autosom nomor 21 (Sindrom Down), sedangkan 45,XO kekurangan 1 kromosom seks X (Sindrom Turner).',
  },
  {
    id: 'm3-q3',
    missionId: 'misi-3',
    order: 3,
    prompt: 'Mengapa perubahan jumlah set kromosom (poliploidi) berdampak berbeda antara manusia/hewan dengan tumbuhan?',
    options: [
      { id: 'A', text: 'Karena tumbuhan tidak memiliki nukleus maupun benang spindel.' },
      { id: 'B', text: 'Karena hewan hanya memiliki kromosom diploid pada sel darah merah saja.' },
      { id: 'C', text: 'Karena manusia/hewan sangat sensitif terhadap ketidakseimbangan dosis gen (umumnya memicu sindrom/letal), sedangkan tumbuhan lebih toleran dan sering menghasilkan buah lebih besar.' },
      { id: 'D', text: 'Karena poliploidi pada manusia selalu membuat tubuh manusia tumbuh jauh lebih tinggi dan subur.' },
    ],
    correctOptionId: 'C',
    explanation: 'Tumbuhan memiliki toleransi tinggi terhadap penggandaan set kromosom (poliploidi), sedangkan pada manusia ketidakseimbangan kromosom memicu sindrom atau keguguran.',
  },
  {
    id: 'm3-q4',
    missionId: 'misi-3',
    order: 4,
    prompt: 'Bagaimana kesimpulan pengaruh perubahan jumlah kromosom terhadap organisme secara menyeluruh?',
    options: [
      { id: 'A', text: 'Mengubah keseimbangan ekspresi gen, ciri morfologi/fenotipe, dan tingkat fertilitas (seperti individu 3n yang mandul).' },
      { id: 'B', text: 'Hanya memengaruhi warna pigmen kulit tanpa mengubah sifat atau fertilitas apa pun.' },
      { id: 'C', text: 'Selalu menguntungkan semua jenis makhluk hidup tanpa kecuali.' },
      { id: 'D', text: 'Hanya terjadi pada bakteri prokariotik yang tidak memiliki kromosom linear.' },
    ],
    correctOptionId: 'A',
    explanation: 'Perubahan jumlah kromosom mengubah dosis gen yang diekspresikan, memengaruhi fenotipe fisik, dan sering menurunkan fertilitas (contohnya semangka 3n atau beberapa sindrom aneuploidi).',
  },
];

export const MISI_1_HINTS = [
  {
    id: 'hint-1',
    title: 'Petunjuk 1: Efek Senyawa Kolkisin',
    content:
      'Kolkisin adalah mutagen kimia yang menghambat pembentukan benang spindel saat pembelahan mitosis. Kromosom tetap mengganda (2n → 4n), tetapi sel gagal membelah sehingga terbentuk semangka tetraploid (4n).',
  },
  {
    id: 'hint-2',
    title: 'Petunjuk 2: Hasil Persilangan 4n × 2n',
    content:
      'Induk tetraploid (4n) menghasilkan gamet 2n, sedangkan induk diploid normal (2n) menghasilkan gamet n. Peleburan keduanya menghasilkan individu anakan dengan 3 set kromosom (3n / triploid).',
  },
  {
    id: 'hint-3',
    title: 'Petunjuk 3: Mengapa Tidak Ada Biji?',
    content:
      'Saat tanaman triploid (3n) melakukan pembelahan meiosis untuk membentuk sel kelamin, 3 perangkat kromosom tidak dapat berpasangan secara seimbang (ganjil). Akibatnya gamet bersifat mandul (steril) sehingga pembuahan bakal biji gagal, namun daging buah tetap berkembang.',
  },
];

export const MISI_2_SORTING_CARDS: SortingCardItem[] = [
  {
    id: 'card-1',
    label: 'Substitusi Basa (Transisi & Transversi)',
    detail: 'Penggantian satu pasang basa purin/pirimidin pada untai DNA.',
    correctCategory: 'mutasi-gen',
  },
  {
    id: 'card-2',
    label: 'Frameshift Mutation (Insersi/Delesi 1 Basa)',
    detail: 'Pergeseran kerangka pembacaan kodon triplet mRNA.',
    correctCategory: 'mutasi-gen',
  },
  {
    id: 'card-3',
    label: 'Silent, Missense & Nonsense Mutation',
    detail: 'Perubahan satu kodon yang mempertahankan, mengubah, atau menghentikan asam amino.',
    correctCategory: 'mutasi-gen',
  },
  {
    id: 'card-4',
    label: 'Anemia Sel Sabit (Sickle Cell)',
    detail: 'Perubahan satu basa pada gen beta-globin (Glu → Val).',
    correctCategory: 'mutasi-gen',
  },
  {
    id: 'card-5',
    label: 'Terjadi pada skala satu lokus gen / DNA',
    detail: 'Tidak tampak mengubah morfologi struktur kromosom di bawah mikroskop.',
    correctCategory: 'mutasi-gen',
  },
  {
    id: 'card-6',
    label: 'Inversi Parasentrik & Perisentrik',
    detail: 'Segmen kromosom patah, berputar 180°, dan menyambung kembali.',
    correctCategory: 'mutasi-kromosom',
  },
  {
    id: 'card-7',
    label: 'Translokasi Resiprok & Katenasi',
    detail: 'Pertukaran segmen antar kromosom yang bukan homolognya.',
    correctCategory: 'mutasi-kromosom',
  },
  {
    id: 'card-8',
    label: 'Euploidi (Triploid 3n / Poliploid 4n)',
    detail: 'Perubahan seluruh perangkat set kromosom pada sel.',
    correctCategory: 'mutasi-kromosom',
  },
  {
    id: 'card-9',
    label: 'Aneuploidi akibat Nondisjunction',
    detail: 'Kelebihan atau kekurangan satu kromosom (2n+1 atau 2n-1).',
    correctCategory: 'mutasi-kromosom',
  },
  {
    id: 'card-10',
    label: 'Sindrom Down (Trisomi 21) & Turner (45,XO)',
    detail: 'Perubahan jumlah kromosom total manusia dari 46 menjadi 47 atau 45.',
    correctCategory: 'mutasi-kromosom',
  },
];

export const BADGE_DEFINITIONS: BadgeDefinition[] = [
  {
    id: 'detektif_pemula',
    name: 'Detektif Pemula',
    description: 'Menyelesaikan investigasi Misi 1: Rahasia Semangka Tanpa Biji.',
    requirement: 'Selesai Misi 1',
    iconKey: 'search',
  },
  {
    id: 'ahli_genetika',
    name: 'Ahli Genetika',
    description: 'Menguasai klasifikasi mutasi gen & kromosom di Misi 2 dengan skor baik.',
    requirement: 'Selesai Misi 2 (Skor ≥ 70)',
    iconKey: 'dna',
  },
  {
    id: 'master_kromosom',
    name: 'Master Kromosom',
    description: 'Berhasil memecahkan analisis kariotipe dan jumlah kromosom pada Misi 3.',
    requirement: 'Selesai Misi 3',
    iconKey: 'layers',
  },
  {
    id: 'peneliti_hebat',
    name: 'Peneliti Hebat',
    description: 'Menuntaskan seluruh 3 Misi Detektif beserta Refleksi Pembelajaran.',
    requirement: 'Selesai 3 Misi + Refleksi',
    iconKey: 'award',
  },
  {
    id: 'argumentator_terbaik',
    name: 'Analis Terbaik',
    description: 'Menjawab soal analisis mutasi dengan rata-rata ketepatan sangat tinggi.',
    requirement: 'Rata-rata Nilai ≥ 85',
    iconKey: 'sparkles',
  },
  {
    id: 'detektif_terbaik',
    name: 'Detektif Terbaik',
    description: 'Meraih puncak prestasi dengan total poin akumulasi unggul.',
    requirement: 'Total Poin ≥ 90',
    iconKey: 'trophy',
  },
];

export const DEFAULT_SETTINGS: AppSettings = {
  timerEnabled: true,
  timerDurationMinutes: 10,
  lockOnTimeExpired: false,
  leaderboardVisible: true,
  pointWeights: {
    mission1Accuracy: 20,
    mission1Completion: 10,
    mission2Accuracy: 20,
    mission2Completion: 10,
    mission3Accuracy: 20,
    mission3Completion: 10,
    activityMax: 10,
  },
  updatedAt: '2026-01-10T08:00:00.000Z',
};
