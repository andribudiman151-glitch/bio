import {
  BADGE_DEFINITIONS,
  DEFAULT_CLASSES,
  DEFAULT_MISSIONS,
  DEFAULT_QUESTIONS,
  DEFAULT_SETTINGS,
  MATERIAL_CHAPTERS,
} from './curriculum';
import { sha256Hex, maskNim } from '../utils/crypto';
import { computeStudentStats } from '../utils/grading';
import type {
  DatabaseSchema,
  GradingResultRecord,
  ReflectionRecord,
  StudentAnswerRecord,
  StudentBadgeRecord,
  StudentRecord,
} from '../types/biolearn';

export async function createDemoRecords(): Promise<{
  students: StudentRecord[];
  student_answers: StudentAnswerRecord[];
  grading_results: GradingResultRecord[];
  reflections: ReflectionRecord[];
  student_badges: StudentBadgeRecord[];
}> {
  const demoSpecs = [
    {
      id: 'demo-s1',
      fullName: 'Aulia Putri Maharani',
      nimRaw: '2026120100001',
      classId: 'class-12-ipa-1',
      className: 'XII IPA 1',
      scores: [94, 92, 95],
      durationMin: 18,
      completedAll: true,
    },
    {
      id: 'demo-s2',
      fullName: 'Bagas Pratama Wijaya',
      nimRaw: '2026120100002',
      classId: 'class-12-ipa-2',
      className: 'XII IPA 2',
      scores: [90, 88, 91],
      durationMin: 21,
      completedAll: true,
    },
    {
      id: 'demo-s3',
      fullName: 'Citra Dewi Lestari',
      nimRaw: '2026120200003',
      classId: 'class-12-ipa-3',
      className: 'XII IPA 3',
      scores: [86, 89, 84],
      durationMin: 24,
      completedAll: true,
    },
    {
      id: 'demo-s4',
      fullName: 'Dimas Aditya Saputra',
      nimRaw: '2026120100004',
      classId: 'class-12-ipa-1',
      className: 'XII IPA 1',
      scores: [82, 85, 80],
      durationMin: 27,
      completedAll: true,
    },
    {
      id: 'demo-s5',
      fullName: 'Elena Kusuma Wardani',
      nimRaw: '2026120200005',
      classId: 'class-12-ipa-2',
      className: 'XII IPA 2',
      scores: [78, 76, 82],
      durationMin: 30,
      completedAll: true,
    },
    {
      id: 'demo-s6',
      fullName: 'Fajar Ramadhan',
      nimRaw: '2026120300006',
      classId: 'class-12-ipa-3',
      className: 'XII IPA 3',
      scores: [75, 72, null],
      durationMin: 33,
      completedAll: false,
    },
  ];

  const students: StudentRecord[] = [];
  const student_answers: StudentAnswerRecord[] = [];
  const grading_results: GradingResultRecord[] = [];
  const reflections: ReflectionRecord[] = [];
  const student_badges: StudentBadgeRecord[] = [];

  for (let i = 0; i < demoSpecs.length; i++) {
    const spec = demoSpecs[i];
    const startMs = Date.parse('2026-02-12T08:00:00.000Z') + i * 120000;
    const endMs = startMs + spec.durationMin * 60000;
    const startIso = new Date(startMs).toISOString();
    const endIso = new Date(endMs).toISOString();

    const student: StudentRecord = {
      id: spec.id,
      fullName: spec.fullName,
      nimHash: await sha256Hex(spec.nimRaw),
      nimDisplay: maskNim(spec.nimRaw),
      classId: spec.classId,
      className: spec.className,
      isDemo: true,
      readChapters: spec.completedAll
        ? MATERIAL_CHAPTERS.map((c) => c.id)
        : ['konsep-dasar', 'mutasi-gen'],
      timerStartedAt: startIso,
      timerFinishedAt: spec.completedAll ? endIso : null,
      timeExpiredLocked: false,
      createdAt: startIso,
      lastActiveAt: endIso,
    };
    students.push(student);

    const missions: Array<{ id: 'misi-1' | 'misi-2' | 'misi-3'; score: number | null }> = [
      { id: 'misi-1', score: spec.scores[0] },
      { id: 'misi-2', score: spec.scores[1] },
      { id: 'misi-3', score: spec.scores[2] },
    ];

    const stuAnswers: StudentAnswerRecord[] = [];
    const stuGrades: GradingResultRecord[] = [];

    for (const m of missions) {
      if (m.score === null) continue;
      const ansRecord: StudentAnswerRecord = {
        id: `${spec.id}-${m.id}`,
        studentId: spec.id,
        missionId: m.id,
        answers:
          m.id === 'misi-1'
            ? {
                'm1-q1': 'B',
                'm1-q2': 'C',
                'm1-q3': 'A',
                'm1-q4': m.score >= 85 ? 'D' : 'B',
              }
            : m.id === 'misi-2'
              ? {
                  'm2-q1': 'B',
                  'm2-q2': 'C',
                  'm2-q3': 'A',
                  'm2-q4': m.score >= 85 ? 'D' : 'C',
                }
              : {
                  'm3-q1': 'B',
                  'm3-q2': 'A',
                  'm3-q3': 'C',
                  'm3-q4': m.score >= 85 ? 'A' : 'B',
                },
        sortingAssignments:
          m.id === 'misi-2'
            ? {
                'card-1': 'mutasi-gen',
                'card-2': 'mutasi-gen',
                'card-3': 'mutasi-gen',
                'card-4': 'mutasi-gen',
                'card-5': 'mutasi-gen',
                'card-6': 'mutasi-kromosom',
                'card-7': 'mutasi-kromosom',
                'card-8': 'mutasi-kromosom',
                'card-9': 'mutasi-kromosom',
                'card-10': 'mutasi-kromosom',
              }
            : undefined,
        sortingScore: m.id === 'misi-2' ? 100 : undefined,
        status: 'graded',
        updatedAt: endIso,
        submittedAt: endIso,
      };
      stuAnswers.push(ansRecord);
      student_answers.push(ansRecord);

      const gradeRecord: GradingResultRecord = {
        id: `${spec.id}-grade-${m.id}`,
        studentId: spec.id,
        missionId: m.id,
        aiScore: m.score,
        aiFeedback: {
          score: m.score,
          correctConcepts:
            'Penjelasan sudah memuat konsep inti mutasi, keterkaitan sebab-akibat genetik, dan istilah Biologi kelas XII yang tepat.',
          needsImprovement:
            m.score >= 90
              ? 'Sudah sangat baik; tambahkan variasi contoh lain untuk memperkaya analisis.'
              : 'Perjelas mekanisme pembelahan sel saat pemisahan kromosom berlangsung.',
          improvementSuggestions:
            'Pertahankan penulisan argumentasi ilmiah dengan alur sebab-akibat yang runtut.',
          learningNotes: 'Data demonstrasi awal untuk simulasi kelas Biologi XII.',
          source: 'gemini',
        },
        teacherScoreOverride: null,
        teacherComment: '',
        finalScore: m.score,
        gradedAt: endIso,
        overriddenAt: null,
      };
      stuGrades.push(gradeRecord);
      grading_results.push(gradeRecord);
    }

    let reflection: ReflectionRecord | undefined;
    if (spec.completedAll) {
      reflection = {
        id: `${spec.id}-ref`,
        studentId: spec.id,
        newThingLearned:
          'Saya baru memahami bahwa semangka tanpa biji adalah hasil persilangan 4n dan 2n menjadi triploid 3n yang mandul saat meiosis.',
        curiousQuestion:
          'Apakah teknik induksi kolkisin juga bisa diterapkan pada tanaman pangan lain selain semangka?',
        submittedAt: endIso,
      };
      reflections.push(reflection);
    }

    const stats = computeStudentStats({
      student,
      answers: stuAnswers,
      gradings: stuGrades,
      reflection,
      weights: DEFAULT_SETTINGS.pointWeights,
      totalMaterialChapters: MATERIAL_CHAPTERS.length,
    });

    for (const badgeId of stats.earnedBadgeIds) {
      student_badges.push({
        id: `${spec.id}-${badgeId}`,
        studentId: spec.id,
        badgeId,
        earnedAt: endIso,
      });
    }
  }

  return {
    students,
    student_answers,
    grading_results,
    reflections,
    student_badges,
  };
}

// SHA-256 digest of the configured teacher password
const DEFAULT_TEACHER_PASSWORD_HASH =
  '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8';

export function createDefaultTeachers(): DatabaseSchema['teachers'] {
  return [
    {
      id: 'teacher-1',
      email: 'guru123',
      name: 'Guru Biologi SMA',
      passwordHash: DEFAULT_TEACHER_PASSWORD_HASH,
      createdAt: '2026-01-10T08:00:00.000Z',
    },
  ];
}

export async function createInitialDatabase(includeDemo = false): Promise<DatabaseSchema> {
  const demo = includeDemo
    ? await createDemoRecords()
    : {
        students: [],
        student_answers: [],
        grading_results: [],
        reflections: [],
        student_badges: [],
      };

  return {
    version: 5,
    teachers: createDefaultTeachers(),
    classes: [...DEFAULT_CLASSES],
    students: demo.students,
    assignments: [...DEFAULT_MISSIONS],
    questions: [...DEFAULT_QUESTIONS],
    student_answers: demo.student_answers,
    grading_results: demo.grading_results,
    reflections: demo.reflections,
    badges: [...BADGE_DEFINITIONS],
    student_badges: demo.student_badges,
    settings: { ...DEFAULT_SETTINGS },
  };
}
