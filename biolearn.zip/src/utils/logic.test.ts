import test from 'node:test';
import assert from 'node:assert/strict';
import { sha256Hex, maskNim } from './crypto';
import { validateNim, validateStudentLoginFields, calculateRemainingSeconds } from './validation';
import {
  evaluateFallbackGrading,
  computeMissionPoints,
  computeStudentStats,
  sortLeaderboardEntries,
  filterRealLeaderboardEntries,
  evaluateEarnedBadges,
  formatStructuredFeedbackText,
} from './grading';
import { DEFAULT_QUESTIONS, DEFAULT_SETTINGS, BADGE_DEFINITIONS } from '../data/curriculum';
import { createInitialDatabase } from '../data/demoSeed';
import type {
  StudentRecord,
  StudentAnswerRecord,
  GradingResultRecord,
  ReflectionRecord,
} from '../types/biolearn';

test('NIM validation enforces strictly 13 numeric digits', () => {
  assert.equal(validateNim('2510130210011').valid, true);
  assert.equal(validateNim('202612010099').valid, false); // 12 digits rejected
  assert.equal(validateNim('12345').valid, false);
  assert.equal(validateNim('251013021001A').valid, false);
  assert.equal(validateNim('25101302100111').valid, false); // 14 digits rejected
  assert.equal(validateNim('').valid, false);
  assert.equal(
    validateStudentLoginFields({
      fullName: 'Siti Rahma',
      nim: '2510130210011',
      classId: 'class-12-ipa-1',
    }).valid,
    true,
  );
});

test('SHA-256 hashing is deterministic and masks 13-digit NIM cleanly', async () => {
  const hashA = await sha256Hex('2510130210011');
  const hashB = await sha256Hex('2510130210011');
  const hashC = await sha256Hex('2510130210012');
  assert.equal(hashA.length, 64);
  assert.equal(hashA, hashB);
  assert.notEqual(hashA, hashC);
  assert.equal(maskNim('2510130210011'), '2510•••••0011');
});

test('Multiple-choice grading computes exact scores, sorting blends, and feedback', () => {
  const m1Questions = DEFAULT_QUESTIONS.filter((q) => q.missionId === 'misi-1');
  const perfectFeedback = evaluateFallbackGrading({
    missionTitle: 'Misi 1',
    questions: m1Questions,
    answers: {
      'm1-q1': 'B',
      'm1-q2': 'C',
      'm1-q3': 'A',
      'm1-q4': 'D',
    },
  });

  const halfFeedback = evaluateFallbackGrading({
    missionTitle: 'Misi 1',
    questions: m1Questions,
    answers: {
      'm1-q1': 'B',
      'm1-q2': 'C',
      'm1-q3': 'D',
      'm1-q4': 'A',
    },
  });

  const m2Questions = DEFAULT_QUESTIONS.filter((q) => q.missionId === 'misi-2');
  const m2Blended = evaluateFallbackGrading({
    missionTitle: 'Misi 2',
    questions: m2Questions,
    answers: {
      'm2-q1': 'B',
      'm2-q2': 'C',
      'm2-q3': 'A',
      'm2-q4': 'D',
    },
    sortingScore: 80,
  });

  const emptyFeedback = evaluateFallbackGrading({
    missionTitle: 'Misi 1',
    questions: m1Questions,
    answers: {},
  });

  assert.equal(perfectFeedback.score, 100);
  assert.equal(halfFeedback.score, 50);
  assert.equal(m2Blended.score, 94); // 100*0.7 + 80*0.3 = 94
  assert.equal(emptyFeedback.score, 0);
  const formatted = formatStructuredFeedbackText(perfectFeedback);
  assert.ok(formatted.includes('[Evaluasi Otomatis Pilihan Ganda]'));
  assert.ok(formatted.includes('KONSEP YANG SUDAH BENAR:'));
});

test('Point calculation prevents double points and applies weights accurately', () => {
  const ans: StudentAnswerRecord = {
    id: 'a1',
    studentId: 's1',
    missionId: 'misi-1',
    answers: { 'm1-q1': 'ok' },
    status: 'graded',
    updatedAt: '2026-01-10T08:10:00.000Z',
    submittedAt: '2026-01-10T08:10:00.000Z',
  };
  const grade: GradingResultRecord = {
    id: 'g1',
    studentId: 's1',
    missionId: 'misi-1',
    aiScore: 90,
    aiFeedback: {
      score: 90,
      correctConcepts: 'ok',
      needsImprovement: '-',
      improvementSuggestions: '-',
      learningNotes: '-',
      source: 'gemini',
    },
    teacherScoreOverride: null,
    teacherComment: '',
    finalScore: 90,
    gradedAt: '2026-01-10T08:10:00.000Z',
    overriddenAt: null,
  };

  const pts = computeMissionPoints({
    grading: grade,
    answerRecord: ans,
    maxAccuracyPoints: 20,
    completionPoints: 10,
  });
  // 10 completion + (0.9 * 20 = 18) = 28
  assert.equal(pts, 28);
});

test('Leaderboard tie-breaker orders by totalPoints DESC, averageAccuracyScore DESC, completionDurationSeconds ASC', () => {
  const makeStudent = (id: string, name: string, start: string, end: string): StudentRecord => ({
    id,
    fullName: name,
    nimHash: id,
    nimDisplay: '2026••••0001',
    classId: 'class-12-ipa-1',
    className: 'XII IPA 1',
    isDemo: true,
    readChapters: ['konsep-dasar', 'mutasi-gen', 'mutasi-kromosom', 'dampak-manfaat'],
    timerStartedAt: start,
    timerFinishedAt: end,
    timeExpiredLocked: false,
    createdAt: start,
    lastActiveAt: end,
  });

  const sFast = makeStudent('s-fast', 'Andi', '2026-01-10T08:00:00.000Z', '2026-01-10T08:15:00.000Z');
  const sSlow = makeStudent('s-slow', 'Budi', '2026-01-10T08:00:00.000Z', '2026-01-10T08:30:00.000Z');

  const mkStats = (student: StudentRecord, totalPoints: number, avgAcc: number) =>
    computeStudentStats({
      student,
      answers: [
        {
          id: `${student.id}-1`,
          studentId: student.id,
          missionId: 'misi-1',
          answers: {},
          status: 'graded',
          updatedAt: student.lastActiveAt,
          submittedAt: student.lastActiveAt,
        },
      ],
      gradings: [
        {
          id: `${student.id}-g1`,
          studentId: student.id,
          missionId: 'misi-1',
          aiScore: avgAcc,
          aiFeedback: {
            score: avgAcc,
            correctConcepts: '',
            needsImprovement: '',
            improvementSuggestions: '',
            learningNotes: '',
            source: 'gemini',
          },
          teacherScoreOverride: null,
          teacherComment: '',
          finalScore: avgAcc,
          gradedAt: student.lastActiveAt,
          overriddenAt: null,
        },
      ],
      reflection: undefined,
      weights: DEFAULT_SETTINGS.pointWeights,
      totalMaterialChapters: 4,
    });

  const statsFast = { ...mkStats(sFast, 85, 85), totalPoints: 85, averageAccuracyScore: 85 };
  const statsSlow = { ...mkStats(sSlow, 85, 85), totalPoints: 85, averageAccuracyScore: 85 };

  const ranked = sortLeaderboardEntries([
    { student: sSlow, stats: statsSlow, badges: [BADGE_DEFINITIONS[0]] },
    { student: sFast, stats: statsFast, badges: [BADGE_DEFINITIONS[0]] },
  ]);

  assert.equal(ranked[0].student.id, 's-fast');
  assert.equal(ranked[0].rank, 1);
  assert.equal(ranked[1].student.id, 's-slow');
  assert.equal(ranked[1].rank, 2);
});

test('Badges and timer calculations evaluate accurately', () => {
  const badges = evaluateEarnedBadges({
    mission1Completed: true,
    mission2Completed: true,
    mission2Score: 88,
    mission3Completed: true,
    hasReflection: true,
    averageAccuracyScore: 88,
    totalPoints: 92,
  });
  assert.equal(badges.length, 6);

  assert.equal(DEFAULT_SETTINGS.timerDurationMinutes, 10);

  const rem = calculateRemainingSeconds({
    timerEnabled: true,
    timerDurationMinutes: 10,
    timerStartedAt: '2026-01-10T08:00:00.000Z',
    nowMs: Date.parse('2026-01-10T08:08:00.000Z'),
  });
  assert.equal(rem, 120);
});

test('Real leaderboard excludes demo students and real students with 0 completed missions', () => {
  const baseStudent = (id: string, name: string, isDemo: boolean): StudentRecord => ({
    id,
    fullName: name,
    nimHash: id,
    nimDisplay: '2026••••0001',
    classId: 'class-12-ipa-1',
    className: 'XII IPA 1',
    isDemo,
    readChapters: [],
    timerStartedAt: '2026-01-10T08:00:00.000Z',
    timerFinishedAt: null,
    timeExpiredLocked: false,
    createdAt: '2026-01-10T08:00:00.000Z',
    lastActiveAt: '2026-01-10T08:10:00.000Z',
  });

  const demoDone = baseStudent('demo-1', 'Demo Student', true);
  const realIdle = baseStudent('real-0', 'Belum Kerja', false);
  const realDone = baseStudent('real-1', 'Siswa Nyata', false);

  const emptyStats = computeStudentStats({
    student: realIdle,
    answers: [],
    gradings: [],
    reflection: undefined,
    weights: DEFAULT_SETTINGS.pointWeights,
    totalMaterialChapters: 4,
  });

  const doneStats = {
    ...emptyStats,
    studentId: realDone.id,
    totalPoints: 26,
    averageAccuracyScore: 80,
    completedMissionsCount: 1,
  };

  const demoStats = {
    ...emptyStats,
    studentId: demoDone.id,
    totalPoints: 95,
    averageAccuracyScore: 95,
    completedMissionsCount: 3,
  };

  const ranked = sortLeaderboardEntries([
    { student: demoDone, stats: demoStats, badges: [] },
    { student: realIdle, stats: emptyStats, badges: [] },
    { student: realDone, stats: doneStats, badges: [] },
  ]);

  const realOnly = filterRealLeaderboardEntries(ranked);
  assert.equal(realOnly.length, 1);
  assert.equal(realOnly[0].student.id, 'real-1');
  assert.equal(realOnly[0].rank, 1);
});

test('Default teacher credentials match guru123 with hashed password', async () => {
  const initialDb = await createInitialDatabase(false);
  assert.equal(initialDb.teachers[0].email, 'guru123');
  assert.equal(initialDb.teachers[0].passwordHash, await sha256Hex('password'));
});
