import type {
  BadgeDefinition,
  BadgeId,
  GradingResultRecord,
  LeaderboardEntry,
  MissionId,
  PointWeights,
  QuestionItem,
  ReflectionRecord,
  StudentAnswerRecord,
  StudentComputedStats,
  StudentRecord,
  StructuredFeedback,
} from '../types/biolearn';

export function formatStructuredFeedbackText(feedback: StructuredFeedback): string {
  const tag =
    feedback.source === 'fallback'
      ? ' [Evaluasi Otomatis Pilihan Ganda]'
      : ' [Penilaian AI Gemini]';

  return [
    `NILAI: ${feedback.score}/100${tag}`,
    `KONSEP YANG SUDAH BENAR: ${feedback.correctConcepts}`,
    `BAGIAN YANG PERLU DIPERBAIKI: ${feedback.needsImprovement}`,
    `SARAN PERBAIKAN: ${feedback.improvementSuggestions}`,
    `CATATAN PEMBELAJARAN: ${feedback.learningNotes}`,
  ].join('\n');
}

/**
 * Deterministic Multiple-Choice (Pilihan Ganda) evaluator.
 * Scores directly against each question's correctOptionId (and blends in
 * sortingScore 30% for Misi 2 when provided), returning structured feedback.
 */
export function evaluateMultipleChoiceGrading(params: {
  missionTitle: string;
  questions: QuestionItem[];
  answers: Record<string, string>;
  sortingScore?: number;
}): StructuredFeedback {
  const { missionTitle, questions, answers, sortingScore } = params;
  const sortedQuestions = [...questions].sort((a, b) => a.order - b.order);
  const totalQuestions = Math.max(1, sortedQuestions.length);

  let correctCount = 0;
  const correctNumbers: number[] = [];
  const wrongDetails: string[] = [];

  for (const q of sortedQuestions) {
    const selected = (answers[q.id] ?? '').trim().toUpperCase();
    const correctId = (q.correctOptionId ?? '').trim().toUpperCase();
    if (selected && selected === correctId) {
      correctCount += 1;
      correctNumbers.push(q.order);
    } else {
      wrongDetails.push(
        `Soal ${q.order} (Kunci: ${correctId}${q.explanation ? ` — ${q.explanation}` : ''})`,
      );
    }
  }

  const mcScore = (correctCount / totalQuestions) * 100;
  let finalRaw = mcScore;
  if (typeof sortingScore === 'number' && !Number.isNaN(sortingScore)) {
    finalRaw = mcScore * 0.7 + Math.max(0, Math.min(100, sortingScore)) * 0.3;
  }

  const finalScore = Math.max(0, Math.min(100, Math.round(finalRaw)));

  const correctConcepts =
    correctCount === sortedQuestions.length
      ? `Luar biasa! Seluruh ${sortedQuestions.length} soal pilihan ganda pada ${missionTitle} dijawab benar (${correctCount}/${sortedQuestions.length}).`
      : correctCount > 0
        ? `Siswa menjawab tepat pada ${correctCount} dari ${sortedQuestions.length} soal pilihan ganda (Nomor ${correctNumbers.join(', ')}).`
        : 'Belum ada jawaban pilihan ganda yang sesuai dengan kunci jawaban.';

  const needsImprovement =
    wrongDetails.length > 0
      ? `Perlu meninjau ulang: ${wrongDetails.join('; ')}.`
      : typeof sortingScore === 'number' && sortingScore < 100
        ? `Skor pengelompokan kartu konsep baru ${sortingScore}%; periksa kembali klasifikasi Mutasi Gen vs Mutasi Kromosom.`
        : 'Semua soal pilihan ganda telah dijawab akurat tanpa kekeliruan.';

  const improvementSuggestions =
    finalScore >= 85
      ? 'Pemahaman konsep sangat kuat! Lanjutkan ke misi berikutnya atau lihat pembahasan tiap soal untuk memperkuat ingatan.'
      : 'Pelajari kembali bagian pembahasan di bawah setiap soal dan buka ulang Materi / Simulator Mutasi sebelum melanjutkan.';

  const learningNotes =
    typeof sortingScore === 'number'
      ? `Penilaian otomatis menggabungkan ketepatan Pilihan Ganda (${Math.round(mcScore)}%) dan Pengelompokan Kartu (${Math.round(sortingScore)}%).`
      : `Penilaian otomatis berdasarkan ketepatan ${correctCount} dari ${sortedQuestions.length} soal Pilihan Ganda.`;

  return {
    score: finalScore,
    correctConcepts,
    needsImprovement,
    improvementSuggestions,
    learningNotes,
    source: 'fallback',
  };
}

/**
 * Deterministic scorer supporting both Multiple-Choice (Pilihan Ganda) and
 * legacy keyword-based fallback grading.
 */
export function evaluateFallbackGrading(params: {
  missionTitle: string;
  questions: QuestionItem[];
  answers: Record<string, string>;
  sortingScore?: number;
}): StructuredFeedback {
  const isMultipleChoice =
    params.questions.length > 0 &&
    params.questions.every((q) => Array.isArray(q.options) && q.options.length > 0);
  if (isMultipleChoice) {
    return evaluateMultipleChoiceGrading(params);
  }

  const { questions, answers, sortingScore } = params;
  const totalQuestions = Math.max(1, questions.length);

  let answeredCount = 0;
  let conceptHits = 0;
  let conceptTotal = 0;
  let argumentationScoreAccum = 0;
  let relevanceAccum = 0;

  const matchedConceptsList: string[] = [];
  const missingConceptsList: string[] = [];

  for (const q of questions) {
    const raw = (answers[q.id] ?? '').trim();
    const lower = raw.toLowerCase();
    const wordCount = raw ? raw.split(/\s+/).filter(Boolean).length : 0;

    if (wordCount >= 3) {
      answeredCount += 1;
    }

    const expected = q.expectedConcepts ?? [];
    conceptTotal += Math.max(1, expected.length);

    let qHits = 0;
    for (const kw of expected) {
      const kwLower = kw.toLowerCase();
      if (lower.includes(kwLower)) {
        qHits += 1;
        if (!matchedConceptsList.includes(kw)) {
          matchedConceptsList.push(kw);
        }
      } else if (!missingConceptsList.includes(kw)) {
        missingConceptsList.push(kw);
      }
    }
    conceptHits += qHits;

    const hasCausal = /(karena|sehingga|akibatnya|menyebabkan|berdampak|oleh sebab itu|terjadi ketika|berbeda dengan)/i.test(
      raw,
    );
    const lengthFactor = Math.min(1, wordCount / 22);
    const qArg = Math.min(1, lengthFactor * 0.7 + (hasCausal ? 0.35 : 0));
    argumentationScoreAccum += qArg;

    const qRel = wordCount >= 5 ? (qHits > 0 ? 1 : 0.65) : wordCount > 0 ? 0.35 : 0;
    relevanceAccum += qRel;
  }

  const conceptRatio = conceptTotal > 0 ? Math.min(1, conceptHits / Math.max(1, conceptTotal * 0.65)) : 0.5;
  const completenessRatio = answeredCount / totalQuestions;
  const argumentRatio = argumentationScoreAccum / totalQuestions;
  const relevanceRatio = relevanceAccum / totalQuestions;

  let rawScore =
    conceptRatio * 40 +
    completenessRatio * 25 +
    argumentRatio * 25 +
    relevanceRatio * 10;

  if (typeof sortingScore === 'number' && !Number.isNaN(sortingScore)) {
    rawScore = rawScore * 0.7 + Math.max(0, Math.min(100, sortingScore)) * 0.3;
  }

  if (answeredCount === 0 && (sortingScore === undefined || sortingScore === 0)) {
    rawScore = 0;
  }

  const finalScore = Math.max(0, Math.min(100, Math.round(rawScore)));

  const correctConcepts =
    matchedConceptsList.length > 0
      ? `Siswa telah menyebutkan dan mengaitkan konsep kunci seperti ${matchedConceptsList
          .slice(0, 6)
          .join(', ')}.`
      : answeredCount > 0
        ? 'Siswa telah berupaya merespons pertanyaan pemantik, namun istilah kunci Biologi mutasi masih perlu diperjelas.'
        : 'Belum ada konsep Biologi yang teridentifikasi karena jawaban masih kosong.';

  const needsImprovement =
    missingConceptsList.length > 0
      ? `Perlu menambahkan penjelasan mengenai: ${missingConceptsList.slice(0, 5).join(', ')}.`
      : 'Struktur penjelasan sudah memuat konsep inti; tingkatkan ketajaman hubungan sebab-akibat antarproses genetik.';

  const improvementSuggestions =
    finalScore >= 85
      ? 'Pertahankan analisis berbasis mekanisme seluler/molekuler dan sertakan contoh konkret pada organisme.'
      : 'Gunakan kalimat sebab-akibat (misalnya: penyebab -> perubahan kromosom/basa nitrogen -> dampak fenotipe) dan lengkapi istilah Biologi kelas XII yang relevan.';

  const learningNotes =
    'Evaluasi dilakukan dengan mesin rubrik otomatis. Guru tetap dapat meninjau dan menyesuaikan nilai secara manual.';

  return {
    score: finalScore,
    correctConcepts,
    needsImprovement,
    improvementSuggestions,
    learningNotes,
    source: 'fallback',
  };
}

export function computeMissionPoints(params: {
  grading: GradingResultRecord | undefined;
  answerRecord: StudentAnswerRecord | undefined;
  maxAccuracyPoints: number;
  completionPoints: number;
}): number {
  const isCompleted =
    params.answerRecord?.status === 'submitted' || params.answerRecord?.status === 'graded';
  if (!isCompleted && !params.grading) {
    return 0;
  }
  const completionEarned = isCompleted ? params.completionPoints : 0;
  const scorePercent = params.grading ? Math.max(0, Math.min(100, params.grading.finalScore)) : 0;
  const accuracyEarned = Math.round(((scorePercent / 100) * params.maxAccuracyPoints) * 10) / 10;
  return Math.round((completionEarned + accuracyEarned) * 10) / 10;
}

export function computeActivityPoints(params: {
  readChaptersCount: number;
  totalChaptersCount: number;
  hasReflection: boolean;
  maxActivityPoints: number;
}): number {
  const readingShare = params.maxActivityPoints * 0.5;
  const reflectionShare = params.maxActivityPoints * 0.5;
  const readingRatio =
    params.totalChaptersCount > 0
      ? Math.min(1, params.readChaptersCount / params.totalChaptersCount)
      : 0;
  const readingPts = readingRatio * readingShare;
  const reflectionPts = params.hasReflection ? reflectionShare : 0;
  return Math.round((readingPts + reflectionPts) * 10) / 10;
}

export function evaluateEarnedBadges(params: {
  mission1Completed: boolean;
  mission2Completed: boolean;
  mission2Score: number;
  mission3Completed: boolean;
  hasReflection: boolean;
  averageAccuracyScore: number;
  totalPoints: number;
}): BadgeId[] {
  const earned: BadgeId[] = [];
  if (params.mission1Completed) earned.push('detektif_pemula');
  if (params.mission2Completed && params.mission2Score >= 70) earned.push('ahli_genetika');
  if (params.mission3Completed) earned.push('master_kromosom');
  if (
    params.mission1Completed &&
    params.mission2Completed &&
    params.mission3Completed &&
    params.hasReflection
  ) {
    earned.push('peneliti_hebat');
  }
  if (
    params.mission1Completed &&
    params.mission2Completed &&
    params.mission3Completed &&
    params.averageAccuracyScore >= 85
  ) {
    earned.push('argumentator_terbaik');
  }
  if (params.totalPoints >= 90) {
    earned.push('detektif_terbaik');
  }
  return earned;
}

export function computeStudentStats(params: {
  student: StudentRecord;
  answers: StudentAnswerRecord[];
  gradings: GradingResultRecord[];
  reflection: ReflectionRecord | undefined;
  weights: PointWeights;
  totalMaterialChapters: number;
}): StudentComputedStats {
  const getAns = (m: MissionId) =>
    params.answers.find((a) => a.studentId === params.student.id && a.missionId === m);
  const getGrade = (m: MissionId) =>
    params.gradings.find((g) => g.studentId === params.student.id && g.missionId === m);

  const a1 = getAns('misi-1');
  const a2 = getAns('misi-2');
  const a3 = getAns('misi-3');
  const g1 = getGrade('misi-1');
  const g2 = getGrade('misi-2');
  const g3 = getGrade('misi-3');

  const mission1Points = computeMissionPoints({
    grading: g1,
    answerRecord: a1,
    maxAccuracyPoints: params.weights.mission1Accuracy,
    completionPoints: params.weights.mission1Completion,
  });
  const mission2Points = computeMissionPoints({
    grading: g2,
    answerRecord: a2,
    maxAccuracyPoints: params.weights.mission2Accuracy,
    completionPoints: params.weights.mission2Completion,
  });
  const mission3Points = computeMissionPoints({
    grading: g3,
    answerRecord: a3,
    maxAccuracyPoints: params.weights.mission3Accuracy,
    completionPoints: params.weights.mission3Completion,
  });

  const hasReflection = Boolean(
    params.reflection &&
      params.reflection.newThingLearned.trim().length > 0 &&
      params.reflection.curiousQuestion.trim().length > 0,
  );

  const activityPoints = computeActivityPoints({
    readChaptersCount: params.student.readChapters.length,
    totalChaptersCount: params.totalMaterialChapters,
    hasReflection,
    maxActivityPoints: params.weights.activityMax,
  });

  const totalPoints =
    Math.round((mission1Points + mission2Points + mission3Points + activityPoints) * 10) / 10;

  const gradedScores = [g1?.finalScore, g2?.finalScore, g3?.finalScore].filter(
    (s): s is number => typeof s === 'number',
  );
  const averageAccuracyScore =
    gradedScores.length > 0
      ? Math.round((gradedScores.reduce((acc, s) => acc + s, 0) / gradedScores.length) * 10) / 10
      : 0;

  const m1Done = a1?.status === 'submitted' || a1?.status === 'graded';
  const m2Done = a2?.status === 'submitted' || a2?.status === 'graded';
  const m3Done = a3?.status === 'submitted' || a3?.status === 'graded';

  const completedMissionsCount = [m1Done, m2Done, m3Done].filter(Boolean).length;
  const totalSteps = 4; // 3 missions + 1 reflection
  const doneSteps = completedMissionsCount + (hasReflection ? 1 : 0);
  const progressPercent = Math.round((doneSteps / totalSteps) * 100);

  // Completion duration in seconds for tie-breaker (lower is faster)
  let completionDurationSeconds = Number.MAX_SAFE_INTEGER;
  if (params.student.timerStartedAt && params.student.timerFinishedAt) {
    const start = Date.parse(params.student.timerStartedAt);
    const end = Date.parse(params.student.timerFinishedAt);
    if (!Number.isNaN(start) && !Number.isNaN(end) && end >= start) {
      completionDurationSeconds = Math.round((end - start) / 1000);
    }
  } else if (params.student.timerStartedAt) {
    const timestamps = [a1?.submittedAt, a2?.submittedAt, a3?.submittedAt, params.reflection?.submittedAt]
      .filter((t): t is string => Boolean(t))
      .map((t) => Date.parse(t))
      .filter((n) => !Number.isNaN(n));
    const start = Date.parse(params.student.timerStartedAt);
    if (timestamps.length > 0 && !Number.isNaN(start)) {
      const latest = Math.max(...timestamps);
      completionDurationSeconds = Math.max(1, Math.round((latest - start) / 1000));
    }
  }

  const earnedBadgeIds = evaluateEarnedBadges({
    mission1Completed: m1Done,
    mission2Completed: m2Done,
    mission2Score: g2?.finalScore ?? 0,
    mission3Completed: m3Done,
    hasReflection,
    averageAccuracyScore,
    totalPoints,
  });

  return {
    studentId: params.student.id,
    mission1Points,
    mission2Points,
    mission3Points,
    activityPoints,
    totalPoints,
    averageAccuracyScore,
    completedMissionsCount,
    hasReflection,
    hasCompletedAllMaterials: params.student.readChapters.length >= params.totalMaterialChapters,
    progressPercent,
    completionDurationSeconds,
    earnedBadgeIds,
  };
}

/**
 * Tie-breaker order:
 * 1. Total Poin tertinggi
 * 2. Nilai Ketepatan Jawaban tertinggi
 * 3. Waktu penyelesaian tercepat
 */
export function sortLeaderboardEntries(
  items: Array<{
    student: StudentRecord;
    stats: StudentComputedStats;
    badges: BadgeDefinition[];
  }>,
): LeaderboardEntry[] {
  const sorted = [...items].sort((a, b) => {
    if (b.stats.totalPoints !== a.stats.totalPoints) {
      return b.stats.totalPoints - a.stats.totalPoints;
    }
    if (b.stats.averageAccuracyScore !== a.stats.averageAccuracyScore) {
      return b.stats.averageAccuracyScore - a.stats.averageAccuracyScore;
    }
    if (a.stats.completionDurationSeconds !== b.stats.completionDurationSeconds) {
      return a.stats.completionDurationSeconds - b.stats.completionDurationSeconds;
    }
    return a.student.fullName.localeCompare(b.student.fullName);
  });

  return sorted.map((item, idx) => ({
    rank: idx + 1,
    student: item.student,
    stats: item.stats,
    badges: item.badges,
  }));
}

/**
 * Filters leaderboard strictly to real (non-demo) field students who have
 * submitted at least one mission or reflection.
 */
export function filterRealLeaderboardEntries(
  entries: LeaderboardEntry[],
): LeaderboardEntry[] {
  return sortLeaderboardEntries(
    entries.filter(
      (entry) =>
        !entry.student.isDemo &&
        (entry.stats.completedMissionsCount > 0 || entry.stats.hasReflection),
    ),
  );
}
