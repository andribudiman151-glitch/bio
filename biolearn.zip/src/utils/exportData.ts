import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { DatabaseSchema, LeaderboardEntry, MissionId } from '../types/biolearn';
import { formatStructuredFeedbackText } from './grading';

export interface ExportFilterOptions {
  mode: 'all' | 'class' | 'student' | 'status';
  classId?: string;
  studentId?: string;
  statusFilter?: 'completed' | 'in-progress' | 'not-started';
}

export interface ExportRow {
  No: number;
  Nama: string;
  NIM: string;
  Kelas: string;
  'Jawaban & Nilai Misi 1': string;
  'Jawaban & Nilai Misi 2': string;
  'Jawaban & Nilai Misi 3': string;
  'Jawaban Refleksi': string;
  'Total Nilai (Rata-rata)': number;
  'Total Poin': number;
  Peringkat: number;
  Badge: string;
  'Waktu Pengumpulan': string;
  'Umpan Balik AI': string;
  'Komentar Guru': string;
}

export function buildExportRows(
  db: DatabaseSchema,
  leaderboard: LeaderboardEntry[],
  filter: ExportFilterOptions,
): ExportRow[] {
  let entries = [...leaderboard];

  if (filter.mode === 'class' && filter.classId) {
    entries = entries.filter((e) => e.student.classId === filter.classId);
  } else if (filter.mode === 'student' && filter.studentId) {
    entries = entries.filter((e) => e.student.id === filter.studentId);
  } else if (filter.mode === 'status' && filter.statusFilter) {
    entries = entries.filter((e) => {
      if (filter.statusFilter === 'completed') {
        return e.stats.completedMissionsCount === 3 && e.stats.hasReflection;
      }
      if (filter.statusFilter === 'in-progress') {
        return (
          (e.stats.completedMissionsCount > 0 || e.stats.hasReflection) &&
          !(e.stats.completedMissionsCount === 3 && e.stats.hasReflection)
        );
      }
      return e.stats.completedMissionsCount === 0 && !e.stats.hasReflection;
    });
  }

  const formatMissionCell = (studentId: string, missionId: MissionId): string => {
    const ans = db.student_answers.find(
      (a) => a.studentId === studentId && a.missionId === missionId,
    );
    const grade = db.grading_results.find(
      (g) => g.studentId === studentId && g.missionId === missionId,
    );
    if (!ans && !grade) return 'Belum dikerjakan';
    const missionQs = db.questions
      .filter((q) => q.missionId === missionId)
      .sort((a, b) => a.order - b.order);
    const ansTexts = ans
      ? missionQs.length > 0
        ? missionQs
            .map((q) => {
              const sel = ans.answers[q.id] ?? '-';
              const mark =
                q.correctOptionId && sel !== '-'
                  ? sel.toUpperCase() === q.correctOptionId.toUpperCase()
                    ? '✓'
                    : '✕'
                  : '';
              return `${q.order}:${sel}${mark}`;
            })
            .join(' | ')
        : Object.entries(ans.answers)
            .map(([k, v]) => `[${k}] ${v}`)
            .join(' | ')
      : '-';
    const scoreText = grade ? `Nilai: ${grade.finalScore}/100` : 'Belum dinilai';
    return `${scoreText} — ${ansTexts}`;
  };

  return entries.map((entry, idx) => {
    const stuId = entry.student.id;
    const ref = db.reflections.find((r) => r.studentId === stuId);
    const grades = (['misi-1', 'misi-2', 'misi-3'] as MissionId[])
      .map((m) => db.grading_results.find((g) => g.studentId === stuId && g.missionId === m))
      .filter((g): g is NonNullable<typeof g> => Boolean(g));

    const aiFeedbackSummary =
      grades.length > 0
        ? grades
            .map((g) => `[${g.missionId.toUpperCase()}] ${formatStructuredFeedbackText(g.aiFeedback)}`)
            .join('\n\n')
        : 'Belum ada umpan balik AI';

    const teacherComments = grades
      .filter((g) => g.teacherComment.trim().length > 0)
      .map((g) => `[${g.missionId.toUpperCase()}] ${g.teacherComment}`)
      .join(' | ');

    const reflectionText = ref
      ? `Hal Baru: ${ref.newThingLearned} | Pertanyaan: ${ref.curiousQuestion}`
      : 'Belum mengisi refleksi';

    const submittedAt =
      entry.student.timerFinishedAt ||
      ref?.submittedAt ||
      entry.student.lastActiveAt;

    return {
      No: idx + 1,
      Nama: entry.student.fullName,
      NIM: entry.student.nimDisplay,
      Kelas: entry.student.className,
      'Jawaban & Nilai Misi 1': formatMissionCell(stuId, 'misi-1'),
      'Jawaban & Nilai Misi 2': formatMissionCell(stuId, 'misi-2'),
      'Jawaban & Nilai Misi 3': formatMissionCell(stuId, 'misi-3'),
      'Jawaban Refleksi': reflectionText,
      'Total Nilai (Rata-rata)': entry.stats.averageAccuracyScore,
      'Total Poin': entry.stats.totalPoints,
      Peringkat: entry.rank,
      Badge: entry.badges.map((b) => b.name).join(', ') || '-',
      'Waktu Pengumpulan': new Date(submittedAt).toLocaleString('id-ID'),
      'Umpan Balik AI': aiFeedbackSummary,
      'Komentar Guru': teacherComments || '-',
    };
  });
}

export function exportRowsToCsv(rows: ExportRow[], filename = 'BIOLEARN_Hasil_Mutasi.csv'): void {
  if (rows.length === 0) return;
  const headers = Object.keys(rows[0]) as Array<keyof ExportRow>;
  const escapeCell = (val: string | number) => {
    const str = String(val ?? '').replace(/\r?\n/g, ' ');
    return `"${str.replace(/"/g, '""')}"`;
  };
  const csvLines = [
    headers.map((h) => escapeCell(h)).join(','),
    ...rows.map((r) => headers.map((h) => escapeCell(r[h])).join(',')),
  ];
  const blob = new Blob(['\uFEFF' + csvLines.join('\n')], {
    type: 'text/csv;charset=utf-8;',
  });
  triggerDownload(blob, filename);
}

export function exportRowsToExcel(rows: ExportRow[], filename = 'BIOLEARN_Hasil_Mutasi.xlsx'): void {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Hasil LKPD Mutasi');
  XLSX.writeFile(workbook, filename);
}

export function exportRowsToPdf(rows: ExportRow[], filename = 'BIOLEARN_Hasil_Mutasi.pdf'): void {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
  doc.setFontSize(14);
  doc.text('BIOLEARN — Laporan Hasil Pembelajaran & LKPD Mutasi Kelas XII', 40, 38);
  doc.setFontSize(9);
  doc.text(`Diekspor pada: ${new Date().toLocaleString('id-ID')}`, 40, 54);

  autoTable(doc, {
    startY: 66,
    styles: { fontSize: 7, cellPadding: 4, overflow: 'linebreak' },
    headStyles: { fillColor: [20, 83, 45], textColor: 255 },
    head: [
      [
        'No',
        'Nama',
        'NIM',
        'Kelas',
        'Misi 1',
        'Misi 2',
        'Misi 3',
        'Refleksi',
        'Nilai',
        'Poin',
        'Rank',
        'Badge',
        'Waktu',
        'Umpan Balik AI',
        'Komentar Guru',
      ],
    ],
    body: rows.map((r) => [
      r.No,
      r.Nama,
      r.NIM,
      r.Kelas,
      r['Jawaban & Nilai Misi 1'].slice(0, 120),
      r['Jawaban & Nilai Misi 2'].slice(0, 120),
      r['Jawaban & Nilai Misi 3'].slice(0, 120),
      r['Jawaban Refleksi'].slice(0, 100),
      r['Total Nilai (Rata-rata)'],
      r['Total Poin'],
      r.Peringkat,
      r.Badge,
      r['Waktu Pengumpulan'],
      r['Umpan Balik AI'].slice(0, 140),
      r['Komentar Guru'],
    ]),
  });

  doc.save(filename);
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
