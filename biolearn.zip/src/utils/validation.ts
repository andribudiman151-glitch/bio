export interface NimValidationResult {
  valid: boolean;
  cleaned: string;
  error?: string;
}

export function validateNim(raw: string): NimValidationResult {
  const trimmed = raw.trim();
  if (!trimmed) {
    return {
      valid: false,
      cleaned: '',
      error: 'NIM/NIS wajib diisi dengan 13 digit angka.',
    };
  }

  if (!/^\d+$/.test(trimmed)) {
    return {
      valid: false,
      cleaned: trimmed,
      error: 'NIM/NIS hanya boleh berisi angka (tanpa huruf, spasi, atau simbol).',
    };
  }

  if (trimmed.length !== 13) {
    return {
      valid: false,
      cleaned: trimmed,
      error: `NIM/NIS harus tepat 13 digit angka (saat ini ${trimmed.length} digit).`,
    };
  }

  return { valid: true, cleaned: trimmed };
}

export function normalizeStudentName(name: string): string {
  return name.trim().replace(/\s+/g, ' ').toLowerCase();
}

export function validateStudentLoginFields(params: {
  fullName: string;
  nim: string;
  classId: string;
}): { valid: boolean; error?: string } {
  const cleanName = params.fullName.trim();
  if (cleanName.length < 3) {
    return {
      valid: false,
      error: 'Nama lengkap minimal terdiri dari 3 karakter.',
    };
  }

  const nimCheck = validateNim(params.nim);
  if (!nimCheck.valid) {
    return { valid: false, error: nimCheck.error };
  }

  if (!params.classId) {
    return {
      valid: false,
      error: 'Silakan pilih kelas terlebih dahulu.',
    };
  }

  return { valid: true };
}

export function calculateRemainingSeconds(params: {
  timerEnabled: boolean;
  timerDurationMinutes: number;
  timerStartedAt: string | null;
  nowMs?: number;
}): number {
  if (!params.timerEnabled) {
    return params.timerDurationMinutes * 60;
  }
  const totalSeconds = Math.max(1, params.timerDurationMinutes) * 60;
  if (!params.timerStartedAt) {
    return totalSeconds;
  }
  const startMs = Date.parse(params.timerStartedAt);
  if (Number.isNaN(startMs)) {
    return totalSeconds;
  }
  const currentMs = params.nowMs ?? Date.now();
  const elapsedSeconds = Math.max(0, Math.floor((currentMs - startMs) / 1000));
  return Math.max(0, totalSeconds - elapsedSeconds);
}

export function formatCountdown(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}
