/**
 * Cryptographic helpers using Web Crypto API (SHA-256).
 * Works across modern browsers and Node.js 20+ test environments.
 */
export async function sha256Hex(input: string): Promise<string> {
  const normalized = input.trim();
  const encoder = new TextEncoder();
  const data = encoder.encode(normalized);

  if (typeof globalThis !== 'undefined' && globalThis.crypto?.subtle) {
    const hashBuffer = await globalThis.crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  // Node.js fallback if globalThis.crypto.subtle is unavailable
  const nodeCrypto = await import('crypto');
  return nodeCrypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Masks a 13-digit NIM/NIS so raw plain-text credentials are never persisted.
 * Example: "2510130210011" -> "2510•••••0011"
 */
export function maskNim(nim: string): string {
  const digits = nim.replace(/\D/g, '');
  if (digits.length !== 13) {
    return '•••••••••••••';
  }
  return `${digits.slice(0, 4)}•••••${digits.slice(9, 13)}`;
}
